package ctl.efim;

import java.util.ArrayList;

public class Arrlist {
	ArrayList<Integer> arrList;

	public Arrlist(){
		arrList = new ArrayList<Integer>();
	}
	public ArrayList<Integer> getArrList() {
		return arrList;
	}

	public void setArrList(ArrayList <Integer> arrList1) {
		this.arrList = arrList1;
	}

}
