package ctl.HuiLen;

import ctl.HuiLen.util.*;

import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;

import org.apache.commons.collections15.BidiMap;
import org.apache.commons.collections15.MapIterator;
import org.apache.commons.collections15.bidimap.TreeBidiMap;

import ca.pfv.spmf.tools.MemoryLogger;

public class HuiGrowthTwu {

	private Dataset dataset;
//	private Vector profitset;
	public long minuti;
//	private Vector<Float> profittb;
	private HuiTree tree;
	private ArrayList<HUItemset> huitemsets = new ArrayList<HUItemset>();
	private Vector<String> baseitemset = new Vector<String>();
	// private Vector<UtiItemset> utiItemsets;
//	private TreeBidiMap<String, Integer> itemIndex; // ˫��ͷ��������ͨ��index��itemname,Ҳ����ͨ��itemname��index
//	private Vector<HuiHeadTbValue> itemValue;
//	private ArrayList<String> itemName;
	private int subtreecount = 1;
	private int nodecount = 0;
	private int maxItem;
	private int maxLen = 0;
	/** an array that map an old item name to its new name */
	int[] oldNameToNewNames;
	/** an array that map a new item name to its old name */
	int[] newNamesToOldNames;
	private int[] NodeRtwu;
	private int[] NodeNu;
//	private int[] NodeBu;
	private int[] tempSu;
	private Arrlist[] Nodelink;
	private int maxHUILen;
	private double startMemory;
//	private int testFlag=0;

	public HuiGrowthTwu(float minuti1, String inputPath, int maximumTransactionCount) throws IOException {
		MemoryLogger.getInstance().reset();
		MemoryLogger.getInstance().checkMemory();
		startMemory = MemoryLogger.getInstance().getMaxMemory();
//System.out.println("0startMemory"+startMemory);
		this.tree = new HuiTree();

//		this.maxLen = maxlen;
		dataset = new Dataset(inputPath, maximumTransactionCount); //,start,width
		this.minuti = (long) (dataset.getTotalUtility() * minuti1);
//		System.out.println(dataset.getTotalUtility() +"/"+minuti1+"/"+this.minuti);
		maxItem = dataset.getMaxItem();
//		tempSu = new int[maxlen];
		maxHUILen=0;

	}



	public int getMaxHUILen() {
		return maxHUILen;
	}



	public void setMaxHUILen(int maxHUILen) {
		this.maxHUILen = maxHUILen;
	}



	public String Mining() {
		String str = "";
		if(this.minuti==0) return "";
//		System.out.println("trs:"+dataset.transactions.size());
//		����ͷ��
		int promisingItemcount = createHeader(dataset);
//		����ȫ����
		creatTH(dataset, promisingItemcount);

		ProcessHtbGTree();
//		�����Ǵ���ȫ����,GT��ͬʱ��ִ������1-4������3-4��ѭ��ִ��
//		1����������subT:creatSubTH1
//		2����������subT: ProcessHtbSubTree
//		3����������������sSubT: creatSubTH2
//		4����������sSubT��ProcessHtbSubTree		

//		str = str + ":" + huitemsets.size();
//		System.out.println(str);
		int[] patternlen = new int[maxHUILen];
		
//		for(int i=0;i<huitemsets.size();i++)
//		{
//			System.out.println(huitemsets.get(i).getName()+":"+huitemsets.get(i).getUtility());
//		}
		str = " Max memory/" + (MemoryLogger.getInstance().getMaxMemory()-startMemory)+ "/ patternCount/" + huitemsets.size()+"/ Len/"+maxHUILen;

		return str;
	}

	private void ProcessHtbGTree() {
//		System.out.println("/"+this.minuti+" 2: ");

		for (int itemI = 1; itemI < Nodelink.length; itemI++) {

			ArrayList<HuiTreeNode> link = Nodelink[itemI].getArrList();
			int nu = NodeNu[itemI], rtwu = NodeRtwu[itemI];
			
//			System.out.println(itemI+" "+newNamesToOldNames[itemI]+" "+rtwu);
			
//			bu = NodeBu[itemI];
			if (rtwu  >= this.minuti) {
				// String itemname = itemIndex.getKey(hc.getIndex());
				// ���������ӵ�����

				baseitemset.add("" + newNamesToOldNames[itemI]);
				

				// �жϻ��Ƿ��Ǹ���Ч�

				if ( nu >= this.minuti) {
					Vector<String> baseitemclone = (Vector<String>) baseitemset.clone();
					huitemsets.add(new HUItemset(baseitemclone,  nu));
					if(baseitemset.size()>this.maxHUILen) this.maxHUILen = baseitemset.size();
				}
				// �����������Ҵ�������
				
								
				creatSubTH1(link); // ���ȫ������ÿ���ڵ㴴������

				// ��������Ӧ�ðѸ���ӻ���ɾ��
				baseitemset.remove(baseitemset.size() - 1);
			}
			for (int i = 0; i < link.size(); i++) {
				HuiTreeNode htn1 = link.get(i);

				HuiTreeNodeInfo htni = htn1.getInfo();
				if(htni==null) 
					System.out.println(i+"  error  "+link.size());
				Vector<Integer> utility = htni.getPathUtility();

				utility.remove(utility.size() - 1);

				if (htn1.getParent() != this.tree.getRoot()) {
					HuiTreeNode ph = htn1.getParent();
					HuiTreeNodeInfo phi = ph.getInfo();
					if (phi == null) {
						ph.setInfo(htni);
					} else {
						phi.setBu(phi.getBu() + htni.getBu());
						phi.addPathUtility(htni.getPathUtility());
						htn1.setInfo(null);
					}
				}

			}

		}
	}

	private void creatSubTH1(ArrayList<HuiTreeNode> link) {
		int nodeItem = link.get(0).getItemIndex();
		long t4 = System.currentTimeMillis();

		HuiTree subTree = new HuiTree();
		TreeBidiMap<Integer, HeaderCount> Header = new TreeBidiMap<Integer, HeaderCount>();
		Iterator<HuiTreeNode> it = link.iterator();
		TreeMap<Integer, HuiHeadTbValue> subHtb = new TreeMap<Integer, HuiHeadTbValue>();

		Vector<Vector<PathNode>> paths = new Vector<Vector<PathNode>>();
//		long nodecount = 0;
		Vector<HuiTreeNodeInfo> vhni = new Vector<HuiTreeNodeInfo>();
//		int testM = 0;
		while (it.hasNext()) {
			HuiTreeNode hn = it.next();
			Vector<PathNode> path = this.tree.getPath1(hn, subHtb);
//			if (path.size() > testM)
//				testM = path.size();
			if (path.size() > 0) {
				vhni.add(hn.getInfo());
				paths.add(path);
//				if (nodeItem == 22) {
//					System.out.println("249---- " + path.size() + " " + hn.getInfo().getSu());
//				}
			}
		}

		long t5 = System.currentTimeMillis() - t4;
		Vector<Integer> keyarr = new Vector<Integer>(subHtb.keySet());
		for (int i = 0; i < keyarr.size(); i++) {
			int key = keyarr.get(i);
			if (subHtb.get(key).getTwu() < this.minuti) {
				subHtb.remove(key);
			} else {
				HuiHeadTbValue htv = subHtb.get(key);
				Header.put(new Integer(key), new HeaderCount(key, htv.getTwu(), 0));
//				ͷ���л���Ҫ����rtwu

			}
		}

		long t6 = System.currentTimeMillis() - t4;
		if (Header.isEmpty())
			return;
		subtreecount++;
//System.out.println("have 2 itemset...................................");
//		if (paths.size() == 1) { // ֻ��һ������һ����֦��
//				
//				int pathSum = vhni.get(0).getBu() ;
//				for(int i=0;i<vhni.get(0).getPathUtility().size();i++)
//				{
//					pathSum = pathSum + vhni.get(0).getPathUtility().get(i);
//				}
//				
////				int pathSum = vhni.get(0).getBu() + vhni.get(0).getSu();
//				if (pathSum > this.minuti) {
//					
//					Vector<PathNode> path = paths.get(0);
//					System.out.println(pathSum+":");
//					for(int tk=0;tk<path.size();tk++)
//					{System.out.print(path.get(tk)+" ");}
//					System.out.println();
//					
//					createHUIbyOneTrans(0,paths.get(0), pathSum);
//					if(this.maxHUILen < paths.get(0).size()+1) this.maxHUILen =  paths.get(0).size()+1;
//				}
//				// ���أ�����Ҫ����ִ����
//				return;
//			}
		for (int i = 0; i < paths.size(); i++) {
			HuiTreeNodeInfo hni = new HuiTreeNodeInfo(vhni.get(i));
			hni.setBu(hni.getBu() + hni.getPathUtility().get(hni.getPathUtility().size() - 1));

//			//ɾ���Ǻ�ѡ�Ȼ��������. ����ɾ����������2020.6.21������Ҳ���ԣ�ɾ����������Ҫ��ͷ���м���.�����Ƕ���ģ�֮ǰ�������Ѿ������Ǻ�ѡ������
//			int k2 = paths.get(i).size();
//			for(int k1=0;k1<k2;k1++)
//			{
//				int item1 = paths.get(i).get(k1).getIndex();
//				if(Header.get(item1)==null)
//				{
//					while(k2>k1)
//					{
//						k2--;
//						int item2 = paths.get(i).get(k2).getIndex();
//						if(Header.get(item1)!=null)
//						{
//							paths.get(i).set(k1, paths.get(i).get(k2));
//							paths.remove(k2);
//							break;
//						}
//						else
//						{
//							paths.remove(k2);
//						}
//					}
//				}
//			}

			Collections.sort(paths.get(i), new HuiItemCompByCount(subHtb));// path����??��֪��������������

			// path����??��֪��������������
			subTree.addInstance1(paths.get(i), Header, hni);// add link
//			if(nodeItem == 22)
//			{
////				System.out.println();
//				int tsum = 0;
//				for(int tk=0;tk<paths.get(i).size();tk++)
//				{
//					System.out.print(newNamesToOldNames[paths.get(i).get(tk).getIndex()]+"��");
//					tsum =tsum + hni.getPathUtility().get(tk);
//				}
//				System.out.println();
//				System.out.println(" sum: "+tsum);
//			}

		}
		MemoryLogger.getInstance().checkMemory();
//	long tt0 = System.currentTimeMillis() - tt;

		// 4.����������ͬ"ProcessHtbSubTree"�����ǣ�������Եݹ������
		ProcessHtbSubTree(subTree, Header);
	}

	
	private void ProcessHtbSubTree(HuiTree tTree, TreeBidiMap<Integer, HeaderCount> Header) {

		BidiMap<HeaderCount, Integer> nHeader = Header.inverseBidiMap();

		MapIterator<HeaderCount, Integer> nm = nHeader.mapIterator();
		int ct = 0;
		while (nm.hasNext()) {

			ct++;
			HeaderCount hc = nm.next();
						
			Vector<HuiTreeNode> link = hc.getLink();
			
			if (hc.getCount() >= this.minuti) {
//				System.out.println("have 2 itemset...................................");
				int nu = 0, bu = 0;
				for (int i = 0; i < link.size(); i++) {
					// HuiTreeNode htn1 = link.get(i);
					HuiTreeNodeInfo hni = link.get(i).getInfo();
					if (hni == null)
						continue;
					nu += hni.getPathUtility().get(hni.getPathUtility().size() - 1);
					bu += hni.getBu();

				}
				
				baseitemset.add("" + newNamesToOldNames[hc.getIndex()]);

				// �жϻ��Ƿ��Ǹ���Ч�

				if (bu + nu >= this.minuti) {
					Vector<String> baseitemclone = (Vector<String>) baseitemset.clone();
					huitemsets.add(new HUItemset(baseitemclone, (bu + nu)));
					if (baseitemset.size() > this.maxHUILen)
						this.maxHUILen = baseitemset.size();

				}
				// �����������Ҵ�������
				creatSubTH2(link, hc.getIndex());

				// ��������Ӧ�ðѸ���ӻ���ɾ��
				baseitemset.remove(baseitemset.size() - 1);
			}
			// ��β�ڵ����Ϣ����һλ��������Ӧ�޸�

			for (int i = 0; i < link.size(); i++) {
				HuiTreeNode htn1 = link.get(i);

				HuiTreeNodeInfo htni = htn1.getInfo();
				
				
				Vector<Integer> utility = htni.getPathUtility();
				utility.remove(utility.size() - 1);
				if (htn1.getParent() != tTree.getRoot()) {
					HuiTreeNode ph = htn1.getParent();
					HuiTreeNodeInfo phi = ph.getInfo();
					if (phi == null) {
						ph.setInfo(htni);
					} else {
						phi.setBu(phi.getBu() + htni.getBu());
						phi.addPathUtility(htni.getPathUtility());
						htn1.setInfo(null);
					}
				}

			}

		}

	}

	private void creatSubTH2(Vector<HuiTreeNode> link, int itindex) {
		long t4 = System.currentTimeMillis();

		HuiTree subTree = new HuiTree();
		TreeBidiMap<Integer, HeaderCount> Header = new TreeBidiMap<Integer, HeaderCount>();
		Iterator<HuiTreeNode> it = link.iterator();
		TreeMap<Integer, HuiHeadTbValue> subHtb = new TreeMap<Integer, HuiHeadTbValue>();

		Vector<Vector<PathNode>> paths = new Vector<Vector<PathNode>>();
		long nodecount = 0;
		Vector<HuiTreeNodeInfo> vhni = new Vector<HuiTreeNodeInfo>();
		while (it.hasNext()) {
			HuiTreeNode hn = it.next();
//			Vector<PathNode> path = this.tree.getPath(hn, subHtb);//�������û�н���ǰ�ڵ��Ч��ֵ�ۼ���
			Vector<PathNode> path = this.tree.getPathWithoutPathSu(hn, subHtb);//�������û�н���ǰ�ڵ��Ч��ֵ�ۼ���

			vhni.add(hn.getInfo());
			paths.add(path);
		}

//	long t5 = System.currentTimeMillis() - t4;
		Vector<Integer> keyarr = new Vector<Integer>(subHtb.keySet());
		for (int i = 0; i < keyarr.size(); i++) {
			int key = keyarr.get(i);
//			if(item==39695)System.out.println("39695 items:"+newNamesToOldNames[key]+"//"+subHtb.get(key).getTwu());
			if (subHtb.get(key).getTwu() < this.minuti) {
				subHtb.remove(key);
			} else {
				HuiHeadTbValue htv = subHtb.get(key);
				Header.put(new Integer(key), new HeaderCount(key, htv.getTwu(), htv.getCount()));
				
			}
		}

//	t4 = System.currentTimeMillis() - t4;

		if (Header.isEmpty())
			return;
//	System.out.println("TNT   || name : itemindex == "+itindex+"  header.size:"+Header.size());
		subtreecount++;
//	long tt = System.currentTimeMillis();
//		if (paths.size() == 1) {
////			int pathSum = vhni.get(0).getBu() + vhni.get(0).getSu();
//			int pathSum = vhni.get(0).getBu() ;
//			for(int i=0;i<vhni.get(0).getPathUtility().size();i++)
//			{
//				pathSum = pathSum + vhni.get(0).getPathUtility().get(i);
//			}
//			if (pathSum > this.minuti) {
//				
//				
//				Vector<PathNode> path = paths.get(0);
//				System.out.println(pathSum+"/"+this.minuti+" 2: ");
//				for(int tk=0;tk<path.size();tk++)
//				{System.out.print(path.get(tk)+" ");}
//				System.out.println();
//				
//				
//				
//				createHUIbyOneTrans(0,paths.get(0), pathSum);
//				if(this.maxHUILen < paths.get(0).size()+this.baseitemset.size()) this.maxHUILen =  paths.get(0).size()+this.baseitemset.size();
//			}
//			// ���أ�����Ҫ����ִ����
//			return;
//		}		
		
		for (int i = 0; i < paths.size(); i++) {
			HuiTreeNodeInfo hni = new HuiTreeNodeInfo(vhni.get(i));
			hni.setBu(hni.getBu() + hni.getPathUtility().get(hni.getPathUtility().size() - 1));
			Collections.sort(paths.get(i), new HuiItemCompByCount(subHtb));// path����??��֪��������������
			// Collections.sort(paths.get(i), new HuiItemCompByCount(subHtb));//
			// path����??��֪��������������

			subTree.addInstance1(paths.get(i), Header, hni);// add link
		}
//	long tt0 = System.currentTimeMillis() - tt;

		// 4.����������ͬ"ProcessHtbSubTree"�����ǣ�������Եݹ������
		
		MemoryLogger.getInstance().checkMemory();
		ProcessHtbSubTree(subTree, Header);

//	tt = System.currentTimeMillis() - tt;
		// System.out.println(" create tree: "+tt0+" create tree and process sub tree:
		// "+tt);
	}

	private void createHUIbyOneTrans(int start, Vector<PathNode> path, int sum) {
		// ����һ����ѡ�
		Vector<String> baseitemclone = (Vector<String>) baseitemset.clone();
		for (int j = 0; j < path.size(); j++) {
			baseitemclone.add("" + newNamesToOldNames[path.get(j).getIndex()]);
		}
		huitemsets.add(new HUItemset(baseitemclone, sum));
		// �жϻ��Ƿ��Ǹ���Ч�
		
		//�������жϳ��ȼ�1���Ӽ��Ƿ��Ч��
		//�Ƚ����һ���ڵ�ȥ���ж�

		int utility;
//���ȥ��������ȥ��һ���µģ��ͽ�֮ǰȥ�����滻�£����⾭��ɾ���ƶ�Ԫ�أ�
		for (int i = start; i < path.size(); i++) {
			utility = sum - path.get(i).getUtility();
			if (utility > this.minuti) {
				Vector<PathNode> subPath = new Vector<PathNode>();
				for(int j=0;j<path.size();j++)
				{
					if (j==i) continue;
					subPath.add(path.get(j));
				}
				createHUIbyOneTrans(i,subPath, utility);
			}
		}
	}


	private Vector<Integer> findMaxSu(Vector<PathNode> Nodes, int len) {
		int sum = 0;
		int minInd = 0;
		Vector<Integer> pathSU = new Vector<Integer>();
		int utility;
		if (Nodes.size() < len + 1) {
			for (int i = 0; i < Nodes.size() && Nodes.get(i).getUtility()>0; i++) {
				utility = Nodes.get(i).getUtility();
				sum += utility;
				pathSU.add(sum);
			}

		} else {
			for (int i = 0; i < len  && Nodes.get(i).getUtility()>0; i++) {
				utility = Nodes.get(i).getUtility();
				sum += utility;
				tempSu[i] = utility;
				pathSU.add(sum);
				if (Nodes.get(minInd).getUtility() > utility)
					minInd = i;
			}
			int i=len;
//			System.out.println("0i:"+i+" / size:"+Nodes.size()+"");
			for ( i = len; i < Nodes.size() && Nodes.get(i).getUtility()>0; i++) {
				utility = Nodes.get(i).getUtility();
				if (Nodes.get(minInd).getUtility() < utility) // ���ĺ�
				{
					sum += (utility - Nodes.get(minInd).getUtility());
					tempSu[minInd] = utility;
					minInd = 0;
					for (int j = 1; j < len; j++) {
						if (tempSu[minInd] > tempSu[j])
							minInd = j;
					}
				}
				pathSU.add(sum);
			}

		}

		return pathSU;
	}


	private int createHeader(Dataset dataset1) {
		// rename item
//		create header table
		List<Integer> itemsToKeep = new ArrayList<Integer>();
		for (int j = 1; j < dataset1.getMaxItem() + 1; j++) {
//	   		System.out.println(this.minuti+"------------/// "+j+" /"+dataset1.getTWU()[j]);
			if (dataset1.getTWU()[j] >= this.minuti) {
				itemsToKeep.add(j);
			}
		}
		// Sort promising items according to the increasing order of TWU
		insertionSort(itemsToKeep, dataset1.getTWU()); // ��twuֵ��������
		oldNameToNewNames = new int[dataset1.getMaxItem() + 1];
		// This structure will store the old name corresponding to each new name
		newNamesToOldNames = new int[itemsToKeep.size() + 1];

		// For each item in increasing order of TWU
		int currentName = 1;
		for (int j = 0; j < itemsToKeep.size(); j++) {
			// get the item old name
			int item = itemsToKeep.get(j);
			// give it the new name
			oldNameToNewNames[item] = currentName;
			// remember its old name
			newNamesToOldNames[currentName] = item;
			// replace its old name by the new name in the list of promising items
			itemsToKeep.set(j, currentName);
			// increment by one the current name so that
			currentName++;
		}
//		   System.out.println(newNamesToOldNames[currentName-1]+" / "+currentName+" / "+dataset1.getTWU()[newNamesToOldNames[currentName-1]]+"/"+dataset1.getMaxItem());
		return itemsToKeep.size();
	}

	// �������ݼ�������ͷ���ͽ���
	private int creatTH(Dataset dataset1, int promisingItemCount) {
//		ÿ����������µ���������
		NodeRtwu = new int[promisingItemCount + 1];
		NodeNu = new int[promisingItemCount + 1];
//		NodeBu = new int[promisingItemCount + 1];
		Nodelink = new Arrlist[promisingItemCount + 1];

		for (int i = 0; i < dataset1.getTransactions().size(); i++)
//        	for(int i=0; i< 3;i++)
		{
			// Get the transaction
			Transaction transaction = dataset1.getTransactions().get(i);

			// Remove unpromising items from the transaction and at the same time
			// rename the items in the transaction according to their new names
			// and sort the transaction by increasing TWU order
			transaction.removeUnpromisingItems(oldNameToNewNames);

//    		tree.addInstance(path, Header);
			tree.addtransactionGlobalNoLen(transaction, NodeRtwu, NodeNu, Nodelink);

//    		�����������ˣ�Ŀǰ�ǵ������е�
//    		System.out.println(i);
//    		for(int k=0;k<transaction.len;k++)
//    		{
//    			System.out.print(transaction.getItems()[k]+" / "+dataset1.getTWU()[newNamesToOldNames[transaction.getItems()[k]]]+" / "+transaction.getUtilities()[k]+" / "+transaction.tempUtilities[k]+"----");
//    			
//    		}
//    		System.out.println();
//    		break;
//    		transaction.
		}

		return 0;
	}

	private static void insertionSort(List<Integer> items, int[] utilityBinArrayTWU) {
		// the following lines are simply a modified an insertion sort

		for (int j = 1; j < items.size(); j++) {
			Integer itemJ = items.get(j);
			int i = j - 1;
			Integer itemI = items.get(i);

			// we compare the twu of items i and j
			int comparison = utilityBinArrayTWU[itemI] - utilityBinArrayTWU[itemJ];
			// if the twu is equal, we use the lexicographical order to decide whether i is
			// greater
			// than j or not.
			if (comparison == 0) {
				comparison = itemI - itemJ;
			}

			while (comparison > 0) {
				items.set(i + 1, itemI);

				i--;
				if (i < 0) {
					break;
				}

				itemI = items.get(i);
				comparison = utilityBinArrayTWU[itemI] - utilityBinArrayTWU[itemJ];
				// if the twu is equal, we use the lexicographical order to decide whether i is
				// greater
				// than j or not.
				if (comparison == 0) {
					comparison = itemI - itemJ;
				}
			}
			items.set(i + 1, itemJ);
		}
	}



	// ����ͷ�����������ʹ����µ�����
	// ����һ��ͷ����baseitemset���ú����Ϳ��Եݹ����

	private void subConstruct(Vector<HuiTreeNode> link, HuiTree tTree) {

		HuiTree subTree = new HuiTree();
		TreeMap<Integer, HuiHeadTbValue> subHtb = new TreeMap<Integer, HuiHeadTbValue>();
		TreeBidiMap<Integer, HeaderCount> Header = new TreeBidiMap<Integer, HeaderCount>();

		// 1.��������ͷ����β�ڵ��
		// creatSubTH(link, tTree, subHtb, subTree0, tailnode);
		// creatSubTH1(link, tTree, Header, subTree); //

		// // 4.����������ͬ"ProcessHtbSubTree"�����ǣ�������Եݹ������
		// ProcessHtbSubTree(subTree, Header);
	}


}