package   ctl.HuiLen;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


/**
 * This is the parser class for the dataset.
 * It has actions related to parse a txt based file to a Dataset class.
 *
 *
 */
public class Dataset {

	/** the list of transactions in this dataset */
	List<Transaction> transactions;

	public int[] getNU() {
		return NU;
	}

	public void setNU(int[] nU) {
		NU = nU;
	}

	public int[] getTWU() {
		return TWU;
	}

	public void setTWU(int[] tWU) {
		TWU = tWU;
	}

	/** the largest item name */
	private int maxItem = 0;

	 private int[]NU = new int[50000];
	 private int[]TWU = new int[50000];
	 
	 public long getTotalUtility() {
		return totalUtility;
	}

	public void setTotalUtility(long totalUtility) {
		this.totalUtility = totalUtility;
	}

	private long totalUtility;
	 
	/**
	 * Constructor
	 * @param datasetPath the path of the file containing the dataset
	 * @param maximumTransactionCount the number of transaction to be read from the input file
	 * @throws IOException exception if error reading the file
	 */
    public Dataset(String datasetPath, int maximumTransactionCount,int k1,int k2,int k3) throws IOException {

    	// Initialize a list to store transactions in memory
    	totalUtility=0;
        transactions = new ArrayList<Transaction>();
        
        // Create a buffered reader to read the input file
        BufferedReader br = new BufferedReader(new FileReader(datasetPath));
        String line;
        int i=0;
        // iterate over the lines to build the transaction
        while((line = br.readLine()) != null) { 
			// if the line is  a comment, is  empty or is  metadata
			if (line.isEmpty() == true || line.charAt(0) == '#' 
					|| line.charAt(0) == '%' || line.charAt(0) == '@') {
				continue;
			}
			i++;
			// read the transaction
//			System.out.println(i+":"+line);
//			transactions.add(createTransactionWithNUTWU(line,k));
			transactions.add(createTransactionWithNUTWU(line,k1));
			transactions.add(createTransactionWithNUTWU(line,k1,k2));
			// if the number of transaction to be read is reached, we stop
        	if(i==maximumTransactionCount) {
        		break;
        	}
			
        }
        //****** Show the number of transactions in this dataset**************************//
//        System.out.println("Transaction count :" +  transactions.size());
        br.close();
    }
	/**
	 * Constructor
	 * @param datasetPath the path of the file containing the dataset
	 * @param maximumTransactionCount the number of transaction to be read from the input file
	 * @throws IOException exception if error reading the file
	 */
    public Dataset(String datasetPath, int maximumTransactionCount,int k) throws IOException {

    	// Initialize a list to store transactions in memory
    	totalUtility=0;
        transactions = new ArrayList<Transaction>();
        
        // Create a buffered reader to read the input file
        BufferedReader br = new BufferedReader(new FileReader(datasetPath));
        String line;
        int i=0;
        // iterate over the lines to build the transaction
        while((line = br.readLine()) != null) { 
			// if the line is  a comment, is  empty or is  metadata
			if (line.isEmpty() == true || line.charAt(0) == '#' 
					|| line.charAt(0) == '%' || line.charAt(0) == '@') {
				continue;
			}
			i++;
			// read the transaction
//			System.out.println(i+":"+line);
//			transactions.add(createTransactionWithNUTWU(line,k));
			transactions.add(createTransactionWithNUTWU(line,k));
			// if the number of transaction to be read is reached, we stop
        	if(i==maximumTransactionCount) {
        		break;
        	}
			
        }
        //****** Show the number of transactions in this dataset**************************//
//        System.out.println("Transaction count :" +  transactions.size());
        br.close();
    }
    
    //ֻҪ������k��ģʽ
    public Dataset(String datasetPath, int maximumTransactionCount,int k, boolean OnlyK) throws IOException {

    	// Initialize a list to store transactions in memory
    	totalUtility=0;
        transactions = new ArrayList<Transaction>();
        
        // Create a buffered reader to read the input file
        BufferedReader br = new BufferedReader(new FileReader(datasetPath));
        String line;
        int i=0;
        // iterate over the lines to build the transaction
        while((line = br.readLine()) != null) { 
			// if the line is  a comment, is  empty or is  metadata
			if (line.isEmpty() == true || line.charAt(0) == '#' 
					|| line.charAt(0) == '%' || line.charAt(0) == '@') {
				continue;
			}
			i++;
			// read the transaction
//			System.out.println(i+":"+line);
			Transaction tr = createTransactionWithK(line,k);
			if(tr!=null) transactions.add(tr);
			// if the number of transaction to be read is reached, we stop
        	if(i==maximumTransactionCount) {
        		break;
        	}
			
        }
        //****** Show the number of transactions in this dataset**************************//
//        System.out.println("Transaction count :" +  transactions.size());
        br.close();
    }
    public Dataset(String datasetPath, int maximumTransactionCount) throws IOException {

    	// Initialize a list to store transactions in memory
    	totalUtility=0;
        transactions = new ArrayList<Transaction>();
        
        // Create a buffered reader to read the input file
        BufferedReader br = new BufferedReader(new FileReader(datasetPath));
        String line;
        int i=0;
        // iterate over the lines to build the transaction
        while((line = br.readLine()) != null) { 
			// if the line is  a comment, is  empty or is  metadata
			if (line.isEmpty() == true || line.charAt(0) == '#' 
					|| line.charAt(0) == '%' || line.charAt(0) == '@') {
				continue;
			}
			i++;
			// read the transaction
			transactions.add(createTransactionWithNUTWU(line));
			// if the number of transaction to be read is reached, we stop
        	if(i==maximumTransactionCount) {
        		break;
        	}
			
        }
        //****** Show the number of transactions in this dataset**************************//
//        System.out.println("Transaction count :" +  transactions.size());
        br.close();
    }

    public Dataset(String datasetPath, int maximumTransactionCount,int start,int width) throws IOException {

    	// Initialize a list to store transactions in memory
    	totalUtility=0;
        transactions = new ArrayList<Transaction>();
        
        // Create a buffered reader to read the input file
        BufferedReader br = new BufferedReader(new FileReader(datasetPath));
        String line;
        int i=0;
//        int readLines=0;
        // iterate over the lines to build the transaction
        while((line = br.readLine()) != null) { 
			// if the line is  a comment, is  empty or is  metadata
			if (line.isEmpty() == true || line.charAt(0) == '#' 
					|| line.charAt(0) == '%' || line.charAt(0) == '@') {
				continue;
			}
			i++;
			if(i<start) continue;
			if(i>start+width) break;
//			readLines++;
			// read the transaction
			transactions.add(createTransactionWithNUTWU(line));
			// if the number of transaction to be read is reached, we stop
        	if(i==maximumTransactionCount) {
        		break;
        	}
			
        }     
        
        //****** Show the number of transactions in this dataset**************************//
//        System.out.println(totalUtility+"Transaction count :" +  transactions.size());
        br.close();
    }

    public Dataset(String datasetPath, int maximumTransactionCount,int start,int width,float minU) throws IOException {

    	// Initialize a list to store transactions in memory
    	totalUtility=0;
        transactions = new ArrayList<Transaction>();
        
        // Create a buffered reader to read the input file
        BufferedReader br = new BufferedReader(new FileReader(datasetPath));
        String line;
        int i=0;
//        int readLines=0;
        // iterate over the lines to build the transaction
        while((line = br.readLine()) != null) { 
			// if the line is  a comment, is  empty or is  metadata
			if (line.isEmpty() == true || line.charAt(0) == '#' 
					|| line.charAt(0) == '%' || line.charAt(0) == '@') {
				continue;
			}
			i++;
			if(i<start) continue;
			if(i>start+width) break;
//			readLines++;
			// read the transaction
			transactions.add(createTransactionWithNUTWU(line));
			// if the number of transaction to be read is reached, we stop
        	if(i==maximumTransactionCount) {
        		break;
        	}
			
        }
        int delU=0;
        for(i=0;i<transactions.size();i++)
        {
        	if((transactions.get(i).transactionUtility*1.0/totalUtility)>minU*0.8)
        	{
//        		System.out.println((transactions.get(i).transactionUtility*1.0/totalUtility) +"  "+ minU);
        		delU +=  transactions.get(i).transactionUtility;       
        		transactions.set(i, null);
        			}
        }
        totalUtility = totalUtility-delU;
        
        //****** Show the number of transactions in this dataset**************************//
//        System.out.println(totalUtility+"Transaction count :" +  transactions.size());
        br.close();
    }


	/**
	 * Create a transaction object from a line from the input file
	 * 
	 * @param line a line from input file
	 * @return a transaction
	 */
	private Transaction createTransactionWithNUTWU(String line) {
		// split the line into tokens according to the ":" separator
		String[] split = line.split(":");

		// Get the transaction utility
		int transactionUtility = Integer.parseInt(split[1]);
		totalUtility = totalUtility + transactionUtility;
		// Get the list of items
		String[] itemsString = split[0].split(" ");

		// Get the list of item utilities
		String[] itemsUtilitiesString = split[2].split(" ");

		// Create array to store the items and their utilities
		int[] items = new int[itemsString.length];
		int[] utilities = new int[itemsString.length];

//		int[] MaxUtilities = new int[k];
		int ind = 0;
		// for each item
		for (int i = 0; i < items.length; i++) {
			// store the item
			items[i] = (int) Integer.parseInt(itemsString[i]);

			// store its utility in that transaction
			utilities[i] = (int) Integer.parseInt(itemsUtilitiesString[i]);

			// NU: itemUtility
			this.NU[items[i]] = this.NU[items[i]] + utilities[i];

			// if the item name is larger than the largest item read from the database until
			// now, we remember
			// its name
			if (items[i] > maxItem) {
				maxItem = items[i];
			}
		}

		for (int i = 0; i < items.length; i++) {
			this.TWU[items[i]] = this.TWU[items[i]] + transactionUtility;
		}
//		System.out.println("ttttttttttttttttt+   "+this.TWU[items[0]]);
		// create the transaction object for this transaction and return it
		return new Transaction(items, utilities, transactionUtility);
	}

	private Transaction createTransactionWithNUTWU(String line, int k) {
		// split the line into tokens according to the ":" separator
		String[] split = line.split(":");

		// Get the transaction utility
		int transactionUtility = Integer.parseInt(split[1]);
		totalUtility = totalUtility + transactionUtility;
		// Get the list of items
		String[] itemsString = split[0].split(" ");

		// Get the list of item utilities
		String[] itemsUtilitiesString = split[2].split(" ");

		// Create array to store the items and their utilities
		int[] items = new int[itemsString.length];
		int[] utilities = new int[itemsString.length];

		int[] MaxUtilities = new int[k];
		int ind = 0;
		// for each item
		for (int i = 0; i < items.length; i++) {
//			System.out.println(k+"////"+items.length);
			// store the item
			items[i] = (int) Integer.parseInt(itemsString[i]);

			// store its utility in that transaction
			utilities[i] = (int) Integer.parseInt(itemsUtilitiesString[i]);

			// NU: itemUtility
			this.NU[items[i]] = this.NU[items[i]] + utilities[i];

			// find max k utilities
			if (i < k) {
				MaxUtilities[i] = utilities[i];
			} else if (i == k) {
				ind = findMiniUtility(MaxUtilities);
				
				if (MaxUtilities[ind] < utilities[i]) {
					MaxUtilities[ind] = utilities[i];
					ind = findMiniUtility(MaxUtilities);
				}
			} else {
				if (MaxUtilities[ind] < utilities[i]) {
					MaxUtilities[ind] = utilities[i];
					ind = findMiniUtility(MaxUtilities);
				}
			}
			// if the item name is larger than the largest item read from the database until
			// now, we remember
			// its name
			if (items[i] > maxItem) {
				maxItem = items[i];
			}
		}
		int transSu = 0;
		if (items.length >= k) {
			for (int i = 0; i < k; i++)
				transSu += MaxUtilities[i];
		} else {
			for (int i = 0; i < items.length; i++)
				transSu += MaxUtilities[i];

		}
		for (int i = 0; i < items.length; i++) {
			this.TWU[items[i]] = this.TWU[items[i]] + transSu;
		}
//		System.out.println("ttttttttttttttttt+   "+this.TWU[items[0]]);
		// create the transaction object for this transaction and return it
		return new Transaction(items, utilities, transactionUtility);
	}
	
	//����ģʽ�ǳ�����k1-k2֮���
	private Transaction createTransactionWithNUTWU(String line, int k1,int k2) {
		// split the line into tokens according to the ":" separator
		String[] split = line.split(":");

		// Get the transaction utility
		int transactionUtility = Integer.parseInt(split[1]);
		totalUtility = totalUtility + transactionUtility;
		// Get the list of items
		String[] itemsString = split[0].split(" ");

		// Get the list of item utilities
		String[] itemsUtilitiesString = split[2].split(" ");

		// Create array to store the items and their utilities
		int[] items = new int[itemsString.length];
		int[] utilities = new int[itemsString.length];

		int[] MaxUtilities = new int[k2];
		int ind = 0;
		// for each item
		for (int i = 0; i < items.length; i++) {
//			System.out.println(k+"////"+items.length);
			// store the item
			items[i] = (int) Integer.parseInt(itemsString[i]);

			// store its utility in that transaction
			utilities[i] = (int) Integer.parseInt(itemsUtilitiesString[i]);

			// NU: itemUtility
			this.NU[items[i]] = this.NU[items[i]] + utilities[i];

			// find max k utilities
			if (i < k1) {
				MaxUtilities[i] = utilities[i];
			} else if (i == k1) {
				ind = findMiniUtility(MaxUtilities);
				
				if (MaxUtilities[ind] < utilities[i]) {
					MaxUtilities[ind] = utilities[i];
					ind = findMiniUtility(MaxUtilities);
				}
			} else {
				if (MaxUtilities[ind] < utilities[i]) {
					MaxUtilities[ind] = utilities[i];
					ind = findMiniUtility(MaxUtilities);
				}
			}
			// if the item name is larger than the largest item read from the database until
			// now, we remember
			// its name
			if (items[i] > maxItem) {
				maxItem = items[i];
			}
		}
		int transSu = 0;
		if (items.length >= k1) {
			for (int i = 0; i < k1; i++)
				transSu += MaxUtilities[i];
		} else {
			for (int i = 0; i < items.length; i++)
				transSu += MaxUtilities[i];

		}
		for (int i = 0; i < items.length; i++) {
			this.TWU[items[i]] = this.TWU[items[i]] + transSu;
		}
//		System.out.println("ttttttttttttttttt+   "+this.TWU[items[0]]);
		// create the transaction object for this transaction and return it
		return new Transaction(items, utilities, transactionUtility);
	}
	
	//ֻҪK���ȵ�ģʽ
	private Transaction createTransactionWithK(String line, int k) {
		// split the line into tokens according to the ":" separator
		String[] split = line.split(":");

		// Get the transaction utility
		int transactionUtility = Integer.parseInt(split[1]);
		totalUtility = totalUtility + transactionUtility;
		// Get the list of items
		String[] itemsString = split[0].split(" ");
		
		if (itemsString.length<k ) return null;
		
		// Get the list of item utilities
		String[] itemsUtilitiesString = split[2].split(" ");

		// Create array to store the items and their utilities
		int[] items = new int[itemsString.length];
		int[] utilities = new int[itemsString.length];

		int[] MaxUtilities = new int[k];
		int ind = 0;
		// for each item
		for (int i = 0; i < items.length; i++) {
//			System.out.println(k+"////"+items.length);
			// store the item
			items[i] = (int) Integer.parseInt(itemsString[i]);

			// store its utility in that transaction
			utilities[i] = (int) Integer.parseInt(itemsUtilitiesString[i]);

			// NU: itemUtility
			this.NU[items[i]] = this.NU[items[i]] + utilities[i];

			// find max k utilities
			if (i < k) {
				MaxUtilities[i] = utilities[i];
			} else if (i == k) {
				ind = findMiniUtility(MaxUtilities);
				
				if (MaxUtilities[ind] < utilities[i]) {
					MaxUtilities[ind] = utilities[i];
					ind = findMiniUtility(MaxUtilities);
				}
			} else {
				if (MaxUtilities[ind] < utilities[i]) {
					MaxUtilities[ind] = utilities[i];
					ind = findMiniUtility(MaxUtilities);
				}
			}
			// if the item name is larger than the largest item read from the database until
			// now, we remember
			// its name
			if (items[i] > maxItem) {
				maxItem = items[i];
			}
		}
		int transSu = 0;
		if (items.length >= k) {
			for (int i = 0; i < k; i++)
				transSu += MaxUtilities[i];
		} else {
			for (int i = 0; i < items.length; i++)
				transSu += MaxUtilities[i];

		}
		for (int i = 0; i < items.length; i++) {
			this.TWU[items[i]] = this.TWU[items[i]] + transSu;
		}
//		System.out.println("ttttttttttttttttt+   "+this.TWU[items[0]]);
		// create the transaction object for this transaction and return it
		return new Transaction(items, utilities, transactionUtility);
	}

	private int findMiniUtility(int[] arr) {
		int indf=0;
		for(int i=1;i<arr.length;i++)
		{
			if(arr[i]<arr[indf])
				indf =i;
		}
		return indf;
	}
	
    /**
     * Create a transaction object from a line from the input file
     * @param line a line from input file
     * @return a transaction
     */
    private Transaction createTransaction(String line) {
    	// split the line into tokens according to the ":" separator
    	String[] split = line.split(":");
    	
    	// Get the transaction utility
    	int transactionUtility = Integer.parseInt(split[1]);
    	
    	// Get the list of items 
        String[] itemsString = split[0].split(" ");
    	
        // Get the list of item utilities
        String[] itemsUtilitiesString = split[2].split(" ");
    	
        //Create array to store the items and their utilities
        int[] items = new  int[itemsString.length];
        int[] utilities = new  int[itemsString.length];

        // for each item
        for (int i = 0; i < items.length; i++) {
        	//store the item
        	items[i] = (int)Integer.parseInt(itemsString[i]);
        	
        	// store its utility in that transaction
        	utilities[i] = (int)Integer.parseInt(itemsUtilitiesString[i]);
            
            // if the item name is larger than the largest item read from the database until now, we remember
        	// its name
            if(items[i] > maxItem) {
                maxItem = items[i];
            }
        }

		// create the transaction object for this transaction and return it
		return new Transaction(items, utilities, transactionUtility);
    }

    /**
     * Get the list of transactions in this database
     * @return the list of transactions
     */
    public List<Transaction> getTransactions() {
        return transactions;
    }


    /**
     * Get the largest item  in this database.
     * @return the largest item
     */
    public int getMaxItem() {
        return maxItem;
    }

   /**
    * Get a string representation of this database
    * @return a string
    */
    public String toString() {
    	// Create a stringbuilder for storing the string
        StringBuilder datasetContent = new StringBuilder();

        // We will append each transaction to this string builder
        for(Transaction transaction : transactions) {
            datasetContent.append(transaction.toString());
            datasetContent.append("\n");
        }
        // Return the string
        return datasetContent.toString();
    }

}
