package ctl.HuiLen;

import java.util.ArrayList;

import ctl.HuiLen.util.HuiTreeNode;

public class Arrlist {
	ArrayList<HuiTreeNode> arrList;

	public Arrlist(){
		arrList = new ArrayList<HuiTreeNode>();
	}

	public ArrayList<HuiTreeNode> getArrList() {
		return arrList;
	}

	public void setArrList(ArrayList <HuiTreeNode> arrList1) {
		this.arrList = arrList1;
	}

}
