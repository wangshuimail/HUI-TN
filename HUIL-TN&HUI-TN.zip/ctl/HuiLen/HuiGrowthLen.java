package ctl.HuiLen;

import ctl.HuiLen.util.*;

import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;

import org.apache.commons.collections15.BidiMap;
import org.apache.commons.collections15.MapIterator;
import org.apache.commons.collections15.bidimap.TreeBidiMap;

import ca.pfv.spmf.tools.MemoryLogger;

/**
 * @author Administrator
 *
 */
/**
 * @author Administrator
 *
 */
public class HuiGrowthLen {

	private Dataset dataset;
//	private Vector profitset;
	private long minuti;
//	private Vector<Float> profittb;
	private HuiTree tree;
	private ArrayList<HUItemset> huitemsets = new ArrayList<HUItemset>();
	private Vector<String> baseitemset = new Vector<String>();
	private int subtreecount = 1;
	private int nodecount = 0;
	private int maxItem;
	private int maxLen = 0;
	/** an array that map an old item name to its new name */
	int[] oldNameToNewNames;
	/** an array that map a new item name to its old name */
	int[] newNamesToOldNames;
	private int[] NodeRtwu;
	private int[] NodeNu;
//	private int[] NodeBu;
	private int[] tempSu;
	private Arrlist[] Nodelink;
	private int maxHUILen;
	private double startMemory;
	public HuiGrowthLen(float minuti1, String inputPath, int maximumTransactionCount, int maxlen) throws IOException {
//		System.out.println("------------");
		// reset the memory usage checking utility
		MemoryLogger.getInstance().reset();
		MemoryLogger.getInstance().checkMemory();
		startMemory = MemoryLogger.getInstance().getMaxMemory();
//System.out.println("0startMemory"+startMemory);
//System.gc();
//
//
//MemoryLogger.getInstance().reset();
//MemoryLogger.getInstance().checkMemory();
//startMemory = MemoryLogger.getInstance().getMaxMemory();
//System.out.println("1startMemory"+startMemory);
//Runtime.getRuntime().gc();
//
//MemoryLogger.getInstance().reset();
//MemoryLogger.getInstance().checkMemory();
//startMemory = MemoryLogger.getInstance().getMaxMemory();
//System.out.println("2startMemory"+startMemory);

		this.tree = new HuiTree();
		this.maxLen = maxlen;
		dataset = new Dataset(inputPath, maximumTransactionCount, maxlen);
//		this.minuti = (long) (dataset.getTotalUtility() * minuti1);
		this.minuti = (long) minuti1;
//		System.out.println(dataset.getTotalUtility() + "/" + minuti + "/" + this.minuti);
		maxItem = dataset.getMaxItem();
		tempSu = new int[maxlen];
		maxHUILen = 0;
		
	}

	public String Mining() {
		String str = "";
//		����ͷ��
		MemoryLogger.getInstance().reset();
		int promisingItemcount = createHeader(dataset);
//		System.out.println("promisingItemcount"+promisingItemcount);
//		����ȫ����
		creatTH(dataset, promisingItemcount);
		// reset the memory usage checking utility

		ProcessHtbGTree(this.maxLen);
//		�����Ǵ���ȫ����,GT��ͬʱ��ִ������1-4��3-4��ѭ��ִ��
//		1����������subT:creatSubTH1
//		2����������subT: ProcessHtbSubTree
//		3����������������sSubT: creatSubTH2
//		4����������sSubT��ProcessHtbSubTree	
		
		
		// check the maximum memory usage
		MemoryLogger.getInstance().checkMemory();

//		str = " Max memory/" + (MemoryLogger.getInstance().getMaxMemory()-startMemory)+ "patternCount/" + huitemsets.size();
		str = (MemoryLogger.getInstance().getMaxMemory()-startMemory)+ "/" + huitemsets.size();
//		System.out.println(str);

//		for(int i=0;i<huitemsets.size();i++)
//		{
//			System.out.println(huitemsets.get(i).getName()+":"+huitemsets.get(i).getUtility());
//		}
		return str;
	}
	private int createHeader(Dataset dataset1) {
		List<Integer> itemsToKeep = new ArrayList<Integer>();
		for (int j = 1; j < dataset1.getMaxItem() + 1; j++) {
			if (dataset1.getTWU()[j] >= this.minuti) {
				itemsToKeep.add(j);
			}
		}
		// Sort promising items according to the increasing order of TWU
		insertionSort(itemsToKeep, dataset1.getTWU()); // ��twuֵ��������
		oldNameToNewNames = new int[dataset1.getMaxItem() + 1];
		for(int j=0;j<dataset1.getMaxItem() + 1;j++)
		{
			oldNameToNewNames[j]=0;
		}
		// This structure will store the old name corresponding to each new name
		newNamesToOldNames = new int[itemsToKeep.size() + 1];

		// For each item in increasing order of TWU
		int currentName = 1;
		for (int j = 0; j < itemsToKeep.size(); j++) {
			// get the item old name
			int item = itemsToKeep.get(j);
			// give it the new name
			oldNameToNewNames[item] = currentName;
			// remember its old name
			newNamesToOldNames[currentName] = item;
//			if(item == 40)
//				System.out.println("currentName "+currentName);
			// replace its old name by the new name in the list of promising items
			itemsToKeep.set(j, currentName);
			// increment by one the current name so that
			currentName++;
		}
		return itemsToKeep.size();
	}

	// �������ݼ�������ͷ���ͽ���
	private int creatTH(Dataset dataset1, int promisingItemCount) {
//		ÿ����������µ���������
		NodeRtwu = new int[promisingItemCount + 1];
		NodeNu = new int[promisingItemCount + 1];
		Nodelink = new Arrlist[promisingItemCount + 1];
		Transaction transaction;
		for (int i = 0; i < dataset1.getTransactions().size(); i++)
		{
			// Get the transaction
			transaction = dataset1.getTransactions().get(i);
			
			// Remove unpromising items from the transaction and at the same time
			// rename the items in the transaction according to their new names
			// and sort the transaction by increasing TWU order
			transaction.removeUnpromisingItems1(oldNameToNewNames, this.maxLen);
			
			tree.addtransactionGlobal(transaction, NodeRtwu, NodeNu, Nodelink);
		}
		// check the maximum memory usage
		MemoryLogger.getInstance().checkMemory();

		return 0;
	}

	private void ProcessHtbGTree(int mlen) {

		for (int itemI = 1; itemI < Nodelink.length; itemI++) {
//			System.out.print(itemI+", ");
			ArrayList<HuiTreeNode> link = Nodelink[itemI].getArrList();

			int nu = NodeNu[itemI], rtwu = NodeRtwu[itemI];

			if (rtwu  >= this.minuti) {
				// String itemname = itemIndex.getKey(hc.getIndex());
				// ���������ӵ�����
				baseitemset.add("" + newNamesToOldNames[itemI]);

				// �жϻ��Ƿ��Ǹ���Ч�

				if ( nu >= this.minuti) {
					Vector<String> baseitemclone = (Vector<String>) baseitemset.clone();
					huitemsets.add(new HUItemset(baseitemclone,  nu));
					if (baseitemset.size() > this.maxHUILen)
						this.maxHUILen = baseitemset.size();
				}
				// �����������Ҵ�������
//				if (baseitemset.size()<2)
				if (mlen > 1) {
					creatSubTH1(link, mlen - 1); // ���ȫ������ÿ���ڵ㴴������
				}
				// ��������Ӧ�ðѸ���ӻ���ɾ��
				baseitemset.remove(baseitemset.size() - 1);
			}
			for (int i = 0; i < link.size(); i++) {
				HuiTreeNode htn1 = link.get(i);

				HuiTreeNodeInfo htni = htn1.getInfo();
//				if( htni==null) {System.out.println(itemI+"/"+Nodelink.length+"  nulllllllllllll   "+i+"/"+htn1.getItemIndex());}
				Vector<Integer> utility = htni.getPathUtility();
				utility.remove(utility.size() - 1);
				htni.getPathSU().remove(htni.getPathSU().size() - 1);
				if (htn1.getParent() != this.tree.getRoot()) {
					HuiTreeNode ph = htn1.getParent();
					HuiTreeNodeInfo phi = ph.getInfo();
					if (phi == null) {
						ph.setInfo(htni);
					} else {
						phi.setBu(phi.getBu() + htni.getBu());
						phi.addPathUtility(htni.getPathUtility());
						phi.addPathSU(htni.getPathSU());
						htn1.setInfo(null);
					}
				}

			}

		}
	}

	private void creatSubTH1(ArrayList<HuiTreeNode> link, int mlen) {
		long t4 = System.currentTimeMillis();
//��������ʱ����Ҫ����rtwu
		
		HuiTree subTree = new HuiTree();
//	TreeBidiMap<Integer, HeaderCount> Header0 = new TreeBidiMap<Integer, HeaderCount>();
		TreeBidiMap<Integer, HeaderCount> Header = new TreeBidiMap<Integer, HeaderCount>();
//		int[] subTreeSu = new int[promisingItemCount + 1];
		Iterator<HuiTreeNode> it = link.iterator();
//	float ut = 0;
		TreeMap<Integer, HuiHeadTbValue> subHtb = new TreeMap<Integer, HuiHeadTbValue>();

		Vector<Vector<PathNode>> paths = new Vector<Vector<PathNode>>();
		long nodecount = 0;
		Vector<HuiTreeNodeInfo> vhni = new Vector<HuiTreeNodeInfo>();

		while (it.hasNext()) {
			HuiTreeNode hn = it.next();
			Vector<PathNode> path = this.tree.getPath(hn, subHtb);
			vhni.add(hn.getInfo());
			paths.add(path);
		}

//	long t5 = System.currentTimeMillis() - t4;
		Vector<Integer> keyarr = new Vector<Integer>(subHtb.keySet());
		for (int i = 0; i < keyarr.size(); i++) {
			int key = keyarr.get(i);
			if (subHtb.get(key).getTwu() < this.minuti) {
				subHtb.remove(key);
			} else {
				HuiHeadTbValue htv = subHtb.get(key);
				Header.put(new Integer(key), new HeaderCount(key, htv.getTwu(), 0));
			}
		}

//	t4 = System.currentTimeMillis() - t4;
		if (Header.isEmpty())
			return;
		subtreecount++;
//	long tt = System.currentTimeMillis();
//		if (paths.size() == 1) {
//			
//			int pathSum = vhni.get(0).getBu() ;
//			for(int i=0;i<vhni.get(0).getPathUtility().size();i++)
//			{
//				pathSum = pathSum + vhni.get(0).getPathUtility().get(i);
//			}
//			
////			int pathSum = vhni.get(0).getBu() + vhni.get(0).getSu();
//			if (pathSum > this.minuti) {
//				createHUIbyOneTrans(0,paths.get(0), pathSum);
//				if(this.maxHUILen < paths.get(0).size()+1) this.maxHUILen =  paths.get(0).size()+1;
//			}
//			// ���أ�����Ҫ����ִ����
//			return;
//		}
		for (int i = 0; i < paths.size(); i++) {
			HuiTreeNodeInfo hni = new HuiTreeNodeInfo(vhni.get(i));
			hni.setBu(hni.getBu() + hni.getPathUtility().get(hni.getPathUtility().size() - 1));
			Collections.sort(paths.get(i), new HuiItemCompByCount(subHtb));// path����??��֪��������������
			Vector<Integer> pathSU = findMaxSu(paths.get(i), mlen);
			if(pathSU.size()>0)
			subTree.addInstance1(paths.get(i), Header, hni, pathSU);// add link

		}
//		Iterator<HeaderCount> Hvs = Header.values().iterator();
//	long tt0 = System.currentTimeMillis() - tt;

		
		// check the maximum memory usage
		MemoryLogger.getInstance().checkMemory();

		// 4.����������ͬ"ProcessHtbSubTree"�����ǣ�������Եݹ������
		ProcessHtbSubTree(subTree, Header, mlen);
//	tt = System.currentTimeMillis() - tt;
	}

	private void ProcessHtbSubTree(HuiTree tTree, TreeBidiMap<Integer, HeaderCount> Header, int mlen) {

		BidiMap<HeaderCount, Integer> nHeader = Header.inverseBidiMap();

		MapIterator<HeaderCount, Integer> nm = nHeader.mapIterator();

		while (nm.hasNext()) {
			// ct++;
			HeaderCount hc = nm.next();
			Vector<HuiTreeNode> link = hc.getLink();
			
//			if(hc.getIndex() == 26 || hc.getIndex() == 31)
//			System.out.println(baseitemset.size()+" currentName "+hc.getCount());

			if (hc.getTwu() >= this.minuti) {
				// String itemname = itemIndex.getKey(hc.getIndex());
				// ���������ӵ�����
				// baseitemset.add(itemname);
				baseitemset.add("" + newNamesToOldNames[hc.getIndex()]);

				// �жϻ��Ƿ��Ǹ���Ч�
//				int nu = 0, bu = 0;
//				for (int i = 0; i < link.size(); i++) {
//					// HuiTreeNode htn1 = link.get(i);
//					HuiTreeNodeInfo hni = link.get(i).getInfo();
//					if (hni == null)
//						continue;
//					nu += hni.getPathUtility().get(hni.getPathUtility().size() - 1);
//					bu += hni.getBu();
//
//					// count += hni.getCount();
//				}
//				if (bu + nu >= this.minuti) {
				if (hc.getCount()  >= this.minuti) {
					Vector<String> baseitemclone = (Vector<String>) baseitemset.clone();
					huitemsets.add(new HUItemset(baseitemclone, (hc.getCount())));
//					if (baseitemset.size() > this.maxHUILen)
//						this.maxHUILen = baseitemset.size();

				}
				// �����������Ҵ�������
				if(mlen>1)
				creatSubTH2(link, hc.getIndex(), mlen - 1);
				// ��������Ӧ�ðѸ���ӻ���ɾ��
				baseitemset.remove(baseitemset.size() - 1);
			}
			// ��β�ڵ����Ϣ����һλ��������Ӧ�޸�
//			for (int i = 0; i < link.size(); i++) {
//				HuiTreeNode htn1 = link.get(i);
//
//				HuiTreeNodeInfo htni = htn1.getInfo();
//			}
			for (int i = 0; i < link.size(); i++) {
				HuiTreeNode htn1 = link.get(i);

				HuiTreeNodeInfo htni = htn1.getInfo();
				if (htni == null)
					System.out.println(i + "  error  " + link.size());
				Vector<Integer> utility = htni.getPathUtility();
				Vector<Integer> pathSU = htni.getPathSU();
				utility.remove(utility.size() - 1);
				pathSU.remove(pathSU.size() - 1);
				if (htn1.getParent() != tTree.getRoot()) {
					HuiTreeNode ph = htn1.getParent();
					HuiTreeNodeInfo phi = ph.getInfo();
					if (phi == null) {
						ph.setInfo(htni);
					} else {
						phi.setBu(phi.getBu() + htni.getBu());
						phi.addPathUtility(htni.getPathUtility());
						phi.addPathSU(pathSU);
						htn1.setInfo(null);
					}
				}

			}

		}
		// System.out.println(" gctime: " + gctime);
	}

	private void creatSubTH2(Vector<HuiTreeNode> link, int itindex, int mlen) {
		long t4 = System.currentTimeMillis();

		HuiTree subTree = new HuiTree();
		TreeBidiMap<Integer, HeaderCount> Header = new TreeBidiMap<Integer, HeaderCount>();
		Iterator<HuiTreeNode> it = link.iterator();
		TreeMap<Integer, HuiHeadTbValue> subHtb = new TreeMap<Integer, HuiHeadTbValue>();

		Vector<Vector<PathNode>> paths = new Vector<Vector<PathNode>>();
		long nodecount = 0;
		Vector<HuiTreeNodeInfo> vhni = new Vector<HuiTreeNodeInfo>();

		while (it.hasNext()) {
			HuiTreeNode hn = it.next();
			Vector<PathNode> path = this.tree.getPath(hn, subHtb);// �������û�н���ǰ�ڵ��Ч��ֵ�ۼ���
			vhni.add(hn.getInfo());
			paths.add(path);
		}

//	long t5 = System.currentTimeMillis() - t4;
		Vector<Integer> keyarr = new Vector<Integer>(subHtb.keySet());
		for (int i = 0; i < keyarr.size(); i++) {
			int key = keyarr.get(i);
			if (subHtb.get(key).getTwu() < this.minuti) {
				subHtb.remove(key);
			} else {
				HuiHeadTbValue htv = subHtb.get(key);
				Header.put(new Integer(key), new HeaderCount(key, htv.getTwu(), 0));

			}
		}

//	t4 = System.currentTimeMillis() - t4;
		if (Header.isEmpty())
			return;
		subtreecount++;
		
		
//		if (paths.size() == 1) {
////			int pathSum = vhni.get(0).getBu() + vhni.get(0).getSu();
//			int pathSum = vhni.get(0).getBu() ;
//			for(int i=0;i<vhni.get(0).getPathUtility().size();i++)
//			{
//				pathSum = pathSum + vhni.get(0).getPathUtility().get(i);
//			}
//			if (pathSum > this.minuti) {
//				createHUIbyOneTrans(0,paths.get(0), pathSum);
//				if(this.maxHUILen < paths.get(0).size()+this.baseitemset.size()) this.maxHUILen =  paths.get(0).size()+this.baseitemset.size();
//			}
//			// ���أ�����Ҫ����ִ����
//			return;
//		}
		
//	long tt = System.currentTimeMillis();

		for (int i = 0; i < paths.size(); i++) {
			HuiTreeNodeInfo hni = new HuiTreeNodeInfo(vhni.get(i));
			hni.setBu(hni.getBu() + hni.getPathUtility().get(hni.getPathUtility().size() - 1));
			Collections.sort(paths.get(i), new HuiItemCompByCount(subHtb));// path����??��֪��������������
			// path����??��֪��������������
			Vector<Integer> pathSU = findMaxSu(paths.get(i), mlen);
			if(pathSU.size()>0)
			subTree.addInstance1(paths.get(i), Header, hni, pathSU);// add link
		}
//	long tt0 = System.currentTimeMillis() - tt;
		// check the maximum memory usage
		MemoryLogger.getInstance().checkMemory();

		// 4.����������ͬ"ProcessHtbSubTree"�����ǣ�������Եݹ������
		if (mlen > 1) {
			ProcessHtbSubTree(subTree, Header, mlen);
		}
//		System.out.println("mlen: " + mlen);
	}
	
	
//һ���������HUI
	private void createHUIbyOneTr1(int[] items1, int[] utilities1, int sum) {
		for (int i = 0; i < items1.length; i++) {
			if ((sum - utilities1[i]) > this.minuti) {
				// ����һ����ѡ�
				Vector<String> baseitemclone = (Vector<String>) baseitemset.clone();
				int[] items2 = new int[items1.length - 1];
				int[] utilities2 = new int[items1.length - 1];
				int k = 0;
				for (int j = 0; j < items1.length; j++) {
					if (j == i)
						continue;
					baseitemclone.add("" + newNamesToOldNames[items1[j]]);
					items2[k] = items1[j];
					utilities2[k] = utilities1[j];
					k++;
				}
				huitemsets.add(new HUItemset(baseitemclone, (sum - utilities1[i])));
				// �жϻ��Ƿ��Ǹ���Ч�

				createHUIbyOneTr1(items2, utilities2, (sum - utilities1[i]));

			}
		}
	}

	private void createHUIbyOneTr2(Vector<PathNode> path, int sum) {
//		int item;int utility;
		PathNode node = path.get(path.size() - 1);
		PathNode tempNode;
		int utility = sum - node.getUtility();
		path.remove(path.size() - 1);
		if (utility > this.minuti) {
			// ����һ����ѡ�
			Vector<String> baseitemclone = (Vector<String>) baseitemset.clone();
			for (int j = 0; j < path.size(); j++) {
				baseitemclone.add("" + newNamesToOldNames[path.get(j).getIndex()]);
			}
			huitemsets.add(new HUItemset(baseitemclone, utility));
			// �жϻ��Ƿ��Ǹ���Ч�

			createHUIbyOneTr2(path, utility);
		}
		for (int i = 0; i < path.size(); i++) {
			utility = sum - path.get(i).getUtility();
			if (utility > this.minuti) {
				tempNode = node;
				node = path.get(i);
				path.set(i, tempNode);

				Vector<String> baseitemclone = (Vector<String>) baseitemset.clone();
				for (int j = 0; j < path.size(); j++) {
					baseitemclone.add("" + newNamesToOldNames[path.get(j).getIndex()]);
				}
				huitemsets.add(new HUItemset(baseitemclone, utility));
				// �жϻ��Ƿ��Ǹ���Ч�

				createHUIbyOneTr2(path, utility);
			}
		}

	}
	
	private void createHUIbyOneTr(Vector<PathNode> path, int sum) {
		// ����һ����ѡ�
		Vector<String> baseitemclone = (Vector<String>) baseitemset.clone();
		for (int j = 0; j < path.size(); j++) {
			baseitemclone.add("" + newNamesToOldNames[path.get(j).getIndex()]);
		}
		huitemsets.add(new HUItemset(baseitemclone, sum));
		// �жϻ��Ƿ��Ǹ���Ч�
		
		int utility;
		//���ȥ��������ȥ��һ���µģ��ͽ�֮ǰȥ�����滻�£����⾭��ɾ���ƶ�Ԫ�أ�
		for (int i = 0; i < path.size(); i++) {
			utility = sum - path.get(i).getUtility();
			if(sum == 16963313 )
			{
				System.out.println(i+"/"+ path.size()+" /"+newNamesToOldNames[path.get(i).getIndex()]+"/................."+utility+"......................");
			}
			if (utility > this.minuti) {
				Vector<PathNode> subPath = new Vector<PathNode>();
				for(int j=0;j<path.size();j++)
				{
					if (j==i) continue;
					subPath.add(path.get(j));
				}
				createHUIbyOneTr(subPath, utility);
			}
		}
	}

	private void createHUIbyOneTrans(int start, Vector<PathNode> path, int sum) {
		// ����һ����ѡ�
		Vector<String> baseitemclone = (Vector<String>) baseitemset.clone();
		for (int j = 0; j < path.size(); j++) {
			baseitemclone.add("" + newNamesToOldNames[path.get(j).getIndex()]);
		}
		huitemsets.add(new HUItemset(baseitemclone, sum));
		// �жϻ��Ƿ��Ǹ���Ч�
		
		//�������жϳ��ȼ�1���Ӽ��Ƿ��Ч��
		//�Ƚ����һ���ڵ�ȥ���ж�

		int utility;
//���ȥ��������ȥ��һ���µģ��ͽ�֮ǰȥ�����滻�£����⾭��ɾ���ƶ�Ԫ�أ�
		for (int i = start; i < path.size(); i++) {
			utility = sum - path.get(i).getUtility();
			if (utility > this.minuti) {
				Vector<PathNode> subPath = new Vector<PathNode>();
				for(int j=0;j<path.size();j++)
				{
					if (j==i) continue;
					subPath.add(path.get(j));
				}
				createHUIbyOneTrans(i,subPath, utility);
			}
		}
	}


	private Vector<Integer> findMaxSu(Vector<PathNode> Nodes, int len) {
		int sum = 0;
		int minInd = 0;
		Vector<Integer> pathSU = new Vector<Integer>();
		int utility;
		if (Nodes.size() < len + 1) {
			for (int i = 0; i < Nodes.size() && Nodes.get(i).getUtility() > 0; i++) {
				utility = Nodes.get(i).getUtility();
				sum += utility;
				pathSU.add(sum);
			}

		} else {
			for (int i = 0; i < len && Nodes.get(i).getUtility() > 0; i++) {
				utility = Nodes.get(i).getUtility();
				sum += utility;
				tempSu[i] = utility;
				pathSU.add(sum);
				if (Nodes.get(minInd).getUtility() > utility)
					minInd = i;
			}
			int i = len;
//			System.out.println("0i:"+i+" / size:"+Nodes.size()+"");
			for (i = len; i < Nodes.size() && Nodes.get(i).getUtility() > 0; i++) {
				utility = Nodes.get(i).getUtility();
				if (Nodes.get(minInd).getUtility() < utility) // ���ĺ�
				{
					sum += (utility - Nodes.get(minInd).getUtility());
					tempSu[minInd] = utility;
					minInd = 0;
					for (int j = 1; j < len; j++) {
						if (tempSu[minInd] > tempSu[j])
							minInd = j;
					}
				}
				pathSU.add(sum);
			}

		}

		return pathSU;
	}

//	private void creatSubTH2(Vector<HuiTreeNode> link, HuiTree tTree,int itindex,int promisingItemCount,int mlen) {
//		long t4 = System.currentTimeMillis();
//
//		HuiTree subTree = new HuiTree();
//		TreeBidiMap<Integer, HeaderCount> Header0 = new TreeBidiMap<Integer, HeaderCount>();
//		TreeBidiMap<Integer, HeaderCount> Header = new TreeBidiMap<Integer, HeaderCount>();
//
//		Iterator <HuiTreeNode> it = link.iterator();
//		int ut = 0;
//		TreeMap<Integer, HuiHeadTbValue> subHtb = new TreeMap<Integer, HuiHeadTbValue>();
//		int [] subTreeSu = new int[promisingItemCount + 1];
//
//		Vector<Vector<PathNode>> paths = new Vector<Vector<PathNode>>();
//		long nodecount = 0;
//		Vector<HuiTreeNodeInfo> vhni = new Vector<HuiTreeNodeInfo> ();
//
//		while (it.hasNext()) {
//			HuiTreeNode hn= it.next();
//			Vector<PathNode> path = this.tree.getPath(hn,subTreeSu,subHtb);
//			vhni.add(hn.getInfo());
//			paths.add(path);
//		}
//
////		long t5 = System.currentTimeMillis() - t4;
//		Vector<Integer> keyarr = new Vector<Integer>(subHtb.keySet());
//		for (int i = 0; i < keyarr.size(); i++) {
//			int key = keyarr.get(i);
//			if (subHtb.get(key).getTwu() < this.minuti) {
//				subHtb.remove(key);
//			} else {
//				HuiHeadTbValue htv = subHtb.get(key);
//				Header.put(new Integer(key), new HeaderCount(key, htv.getTwu(),
//						htv.getCount()));
//			}
//		}
//
////		t4 = System.currentTimeMillis() - t4;
//		// System.out.println("    get path"+t5+" and header table :  "+t4+"  ct:"+cit+"  nodecount:"+nodecount);
//		if (Header.isEmpty())
//			return;
////		System.out.println("TNT   || name : itemindex == "+itindex+"  header.size:"+Header.size());
//		subtreecount++;
////		long tt = System.currentTimeMillis();
//
//		for (int i = 0; i < paths.size(); i++) {
//			HuiTreeNodeInfo hni = new HuiTreeNodeInfo(vhni.get(i));
//			hni
//					.setBu(hni.getBu()
//							+ hni.getPathUtility().get(
//									hni.getPathUtility().size() - 1));
//			Collections.sort(paths.get(i), new HuiItemCompByCount(subHtb));// path����??��֪��������������
//			// Collections.sort(paths.get(i), new HuiItemCompByCount(subHtb));//
//			// path����??��֪��������������
//			subTree.addInstance(paths.get(i), Header, hni);// add link
//
//		}
////		long tt0 = System.currentTimeMillis() - tt;
//
//		// 4.����������ͬ"ProcessHtbSubTree"�����ǣ�������Եݹ������
////		ProcessHtbSubTree(subTree, Header);
////		tt = System.currentTimeMillis() - tt;
//		// System.out.println("    create tree:  "+tt0+"  create tree and process sub tree:  "+tt);
//	}	
//	


	private static void insertionSort(List<Integer> items, int[] utilityBinArrayTWU) {
		// the following lines are simply a modified an insertion sort

		for (int j = 1; j < items.size(); j++) {
			Integer itemJ = items.get(j);
			int i = j - 1;
			Integer itemI = items.get(i);

			// we compare the twu of items i and j
			int comparison = utilityBinArrayTWU[itemI] - utilityBinArrayTWU[itemJ];
			// if the twu is equal, we use the lexicographical order to decide whether i is
			// greater
			// than j or not.
			if (comparison == 0) {
				comparison = itemI - itemJ;
			}

			while (comparison > 0) {
				items.set(i + 1, itemI);

				i--;
				if (i < 0) {
					break;
				}

				itemI = items.get(i);
				comparison = utilityBinArrayTWU[itemI] - utilityBinArrayTWU[itemJ];
				// if the twu is equal, we use the lexicographical order to decide whether i is
				// greater
				// than j or not.
				if (comparison == 0) {
					comparison = itemI - itemJ;
				}
			}
			items.set(i + 1, itemJ);
		}
	}

//	public String Mining() {
//		
//		long t = System.currentTimeMillis();
//		this.createItemIndex();
//		TreeBidiMap<Integer, HeaderCount> Header = new TreeBidiMap<Integer, HeaderCount>();
////		int state = this.creatTH(Header);
//		int state = -1;
//
//		if (state != -1)
//		{
//			ProcessHtbSubTree(tree, Header);
//		} else {
//			System.out.println("min-uti is too small!");
//		}
//		t = System.currentTimeMillis() - t;
////		int itemlen =0;
//		for(int i=0;i<this.huitemsets.size();i++)
//		{
////			this.huitemsets.get(i).g
//			System.out.println(this.huitemsets.get(i).getName()+"  :  "+this.huitemsets.get(i).getUtility());}
//		String rs = "number of trees=" + subtreecount
//		+ "; size of the HUIs= " + huitemsets.size() + ";  min_uti= "
//		+ this.minuti + ";  runtime: " + t;
//		System.out.println(rs);
//		return rs;
//	}

	// profitset->(profittb)index item->htb.
	// profitset��������������������ʱ�򣬰�����������˳���ÿ��һ��index��Ȼ��ͷ����ֻ��item,index����Ϣ
//	private void createItemIndex() {
//
//		int size = profitset.size();
//		for (int i = 0; i < size; i++) {
//			Vector<String> item = (Vector<String>) profitset.get(i);
//			Integer index = new Integer(i);
//			itemIndex.put(item.get(0), index);
//			profittb.add(Float.valueOf(item.get(1)));
//			itemValue.add(new HuiHeadTbValue());
//			itemName.add(item.get(0));
//		}
//	}

	// return -1, all are less than min_utility
	// return 1, all are more than min_utility
	// return 0, others.
	// you should be sure that the head table is not empty.
//	private int stateOfHTb(Vector<HuiHeadTbValue> itemVal) {
//		int num = 0;
//		int bnum = 0;
//		for (int i = 0; i < itemVal.size(); i++) {
//			if (this.itemValue.get(i).getTwu() < this.minuti
//					&& this.itemValue.get(i).getTwu() != 0.0f)
//				num++;
//			else if (this.itemValue.get(i).getTwu() >= this.minuti)
//				bnum++;
//
//			// System.out.println("this.itemValue.get(i).getTwu()  "+this.itemValue.get(i).getTwu()+"   "+this.minuti);
//			if (num > 0 && bnum > 0)
//				return 0;
//
//		}
//		// System.out.println("--------");
//
//		if (num > 1)
//			return -1;
//		else
//			return 1;
//	}

	// ͨ��ͷ����reduce tree
//	private int reduceTree(Vector<HuiHeadTbValue> itemVal, HuiTree tree0) {
//		int state = this.stateOfHTb(itemVal);
//		while (state == 0) {
//			Iterator it = itemVal.iterator();
//			while (it.hasNext()) {
//				HuiHeadTbValue value = (HuiHeadTbValue) it.next();
//				if ((value.getTwu() < this.minuti) && (value.getTwu() > 0.001)) {
//					Vector<HuiTreeNode> link = value.getLink();
//					Vector<HuiTreeNode> tails = new Vector<HuiTreeNode>();
//					Vector<Integer> diss = new Vector<Integer>();
//
//					Iterator tt = link.iterator();
//					while (tt.hasNext()) {
//						HuiTreeNode nod = (HuiTreeNode) tt.next();
//						tree0.getSubTails(nod, tails, diss, 0);
//					}
//					//
//					int size = tails.size();
//
//					for (int i = 0; i < size; i++) {
//						// update tail node's su and path_utility.
//						HuiTreeNodeInfo info = tails.get(i).getInfo();
//						int index = info.getPathUtility().size() - diss.get(i)
//								- 1;
//						float utility = info.getPathUtility().get(index);
//
//						info.setSu(info.getSu() - utility);
//						info.getPathUtility().set(index, 0.0f);
//
//						// update all the node's head table's twu in the path.
//						Vector<HuiTreeNode> path = tree0.getPath(tails.get(i));
//						tt = path.iterator();
//						while (tt.hasNext()) {
//							HuiTreeNode nod = (HuiTreeNode) tt.next();
//							HuiHeadTbValue hv = itemVal.get(nod.getItemIndex());
//							if (hv.getTwu() < 0.001)
//								continue;
//							hv.setTwu(hv.getTwu() - utility);
//						}
//						value.setTwu(0);
//					}
//				}
//
//			}
//			state = this.stateOfHTb(itemVal);
//			if (state == -1) {
//				// System.out
//				// .println("The lowest support utility may be set too big!");
//				return -1;
//			}
//			if (state == 1) {
//				// System.out.println("You can re-construct the tree.");
//				return 1;
//			}
//		}
//		if (state == -1) {
//			// System.out
//			// .println("The lowest support utility may be set too big!");
//			return -1;
//		} else {
//			// System.out.println("You can re-construct the tree.");
//			return 1;
//		}
//
//		// this.reduceTree();
//	}

	// ����ͷ�����������ʹ����µ�����
	// ����һ��ͷ����baseitemset���ú����Ϳ��Եݹ����

	private void subConstruct(Vector<HuiTreeNode> link, HuiTree tTree) {

		HuiTree subTree = new HuiTree();
		TreeMap<Integer, HuiHeadTbValue> subHtb = new TreeMap<Integer, HuiHeadTbValue>();
		TreeBidiMap<Integer, HeaderCount> Header = new TreeBidiMap<Integer, HeaderCount>();

		// 1.��������ͷ����β�ڵ��
		// creatSubTH(link, tTree, subHtb, subTree0, tailnode);
		// creatSubTH1(link, tTree, Header, subTree); //

		// // 4.����������ͬ"ProcessHtbSubTree"�����ǣ�������Եݹ������
		// ProcessHtbSubTree(subTree, Header);
	}

	// ����������ͷ��,β�ڵ��
//	private void creatSubTH(Vector<HuiTreeNode> link, HuiTree tTree,
//			TreeMap<Integer, HuiHeadTbValue> subHtb, HuiTree subTree,
//			Vector<HuiTreeNode> tailnode) {
//		Iterator it = link.iterator();
//		float ut = 0;
//		while (it.hasNext()) {
//			Vector<HuiTreeNode> path = tTree.getPath((HuiTreeNode) it.next());
//			subTree.addInstance(path, subHtb, tailnode);
//		}
//	}

	// ���������еĲ�������
//	private int reduceSubTree(HuiTree subTree,
//			TreeMap<Integer, HuiHeadTbValue> subHtb) {
//		int state = this.stateOfSubHTb(subHtb);
//		while (state == 0) {
//
//			// Iterator it = itemVal.iterator();
//			Iterator it = subHtb.keySet().iterator();
//			while (it.hasNext()) {
//				Integer key = (Integer) it.next();
//				HuiHeadTbValue value = subHtb.get(key);
//				// for (int vi = 0; vi < itemVal.size(); vi++) {
//				// HuiHeadTbValue value = itemVal.get(vi);
//				if ((value.getTwu() < this.minuti) && (value.getTwu() > 0.001)) {
//					Vector<HuiTreeNode> link = value.getLink();
//					Vector<HuiTreeNode> tails = new Vector<HuiTreeNode>();
//					Vector<Integer> diss = new Vector<Integer>();
//
//					Iterator tt = link.iterator();
//					while (tt.hasNext()) {
//						HuiTreeNode nod = (HuiTreeNode) tt.next();
//						subTree.getSubTails(nod, tails, diss, 0);
//					}
//					//
//					int size = tails.size();
//
//					for (int i = 0; i < size; i++) {
//						// update tail node's su and path_utility.
//						HuiTreeNodeInfo info = tails.get(i).getInfo();
//						int index = info.getPathUtility().size() - diss.get(i)
//								- 1;
//						float utility = info.getPathUtility().get(index);
//
//						info.setSu(info.getSu() - utility);
//						info.getPathUtility().set(index, 0.0f);
//
//						// update all the node's head table's twu in the path.
//						Vector<HuiTreeNode> path = subTree
//								.getPath(tails.get(i));
//						tt = path.iterator();
//						while (tt.hasNext()) {
//							HuiTreeNode nod = (HuiTreeNode) tt.next();
//							HuiHeadTbValue hv = subHtb.get(nod.getItemIndex());
//
//							if (hv.getTwu() < 0.001)
//								continue;
//							hv.setTwu(hv.getTwu() - utility);
//						}
//						value.setTwu(0);
//					}
//				}
//
//			}
//			state = this.stateOfSubHTb(subHtb);
//			if (state == -1) {
//				return -1;
//			}
//			if (state == 1) {
//				return 1;
//			}
//		}
//		if (state == -1) {
//			return -1;
//		} else {
//			return 1;
//		}
//	}

//	private int stateOfSubHTb(TreeMap<Integer, HuiHeadTbValue> subHtb) {
//		int num = 0;
//		int bnum = 0;
//		Iterator it = subHtb.keySet().iterator();
//		while (it.hasNext()) {
//			int key = (Integer) it.next();
//			if (subHtb.get(key).getTwu() < this.minuti
//					&& subHtb.get(key).getTwu() > 0.0f)
//				num++;
//			else if (subHtb.get(key).getTwu() >= this.minuti)
//				bnum++;
//
//			// System.out.println("this.itemValue.get(i).getTwu()  "+this.itemValue.get(i).getTwu()+"   "+this.minuti);
//			if (num > 0 && bnum > 0)
//				return 0;
//		}
//		if (num > 1)
//			return -1;
//		else
//			return 1;
//	}

	// ������������ͷ���е�link��Ϣ
//	private void updateHeader(HuiTreeNode htn,
//			TreeBidiMap<Integer, HeaderCount> Header) {
//
//		if (htn != null) {
//			int index = htn.getItemIndex();
//			if (Header.get(index) != null) {
//				Header.get(index).getLink().add(htn);
//			}
//			// else
//			// {
//			// System.out.println("htn.getChildren().size: "+htn.getChildren().size());
//			// }
//			for (int i = 0; i < htn.getChildren().size(); i++) {
//				updateHeader(htn.getChildren().get(i), Header);
//			}
//
//		}
//	}

	// �ع�����

//	private void ReConstructSubTree(HuiTree subTree,
//			TreeMap<Integer, HuiHeadTbValue> subheadtlb) {
//
//		Vector<Integer> keyarr = new Vector<Integer>(subheadtlb.keySet());
//		for (int i = 0; i < keyarr.size(); i++) {
//			int key = keyarr.get(i);
//			if (subheadtlb.get(key).getTwu() < this.minuti)
//				subheadtlb.remove(key);
//		}
//
//		ReConstructTree rct = new ReConstructTree(subTree, subheadtlb,
//				baseitemset);
//		rct.fpConstruct(subTree.getRoot(), subTree.getRoot());
//
//		for (int i = 0; i < subTree.getRoot().getChildren().size(); i++) {
//			HuiTreeNode child = subTree.getRoot().getChildren().get(i);
//			if (child.getChildren().size() == 0 && child.getInfo() == null) {
//				subTree.getRoot().getChildren().remove(child);
//				i--;
//			}
//
//		}
//	}

	// private void ReConstruct() {
	// // Integer key = new Integer(0);
	// for (int i = 0; i < itemValue.size(); i++) {
	// if (itemValue.get(i).getTwu() >= this.minuti) {
	// Integer hkey = new Integer(i);
	// HuiHeadTbValue hvaule = new HuiHeadTbValue(itemValue.get(i));
	// headtlb.put(hkey, hvaule);
	// }
	// }
	// ReConstructTree rct = new ReConstructTree(this.tree, headtlb,
	// baseitemset);
	// rct.fpConstruct(this.tree.getRoot(), this.tree.getRoot());
	// for (int i = 0; i < this.tree.getRoot().getChildren().size(); i++) {
	// HuiTreeNode child = this.tree.getRoot().getChildren().get(i);
	// if (child.getChildren().size() == 0 && child.getInfo() == null) {
	// this.tree.getRoot().getChildren().remove(child);
	// i--;
	// }
	//
	// }
	// }

}