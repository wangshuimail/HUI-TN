package ctl.HuiLen.util;

import java.util.Vector;


public class HuiTreeNode {

	
	private int itemIndex;
	
	private HuiTreeNode parent;
	private Vector<HuiTreeNode> children;
	
	//index, utility, supcount;
	private HuiTreeNodeInfo info;
	
	
	public HuiTreeNode(int index){
		this.itemIndex = index;
		this.parent = null;
		this.children = new Vector<HuiTreeNode>();
		this.info = null;
	}
	
	public HuiTreeNode(int index, HuiTreeNode parent){
		this(index);
		if (parent != null){
			this.parent = parent;
			this.parent.children.add(this);
		}
	}
	
	public HuiTreeNode(HuiTreeNode parent) {
		// TODO Auto-generated constructor stub
		this.parent = null;
		this.itemIndex = -1;
		this.children = new Vector<HuiTreeNode>();
		this.info = null;
	}

	public void setItemIndex(int itemIndex) {
		this.itemIndex = itemIndex;
	}

	public void setParent(HuiTreeNode parent) {
		this.parent = parent;
		parent.getChildren().add(this);
	}

	public void setChildren(Vector<HuiTreeNode> children) {
		this.children = children;
	}

	public HuiTreeNode() {
		this.parent = null;
		this.itemIndex = -1;
		this.children = new Vector<HuiTreeNode>();
		this.info = null;

		// TODO Auto-generated constructor stub
	}

	public Integer getItemName() {
		return itemIndex;
	}

	public void addChild(HuiTreeNode child){
		this.children.add(child);
	}
	
	public boolean isRoot(){
		return (null == this.parent);
	}
	
	public boolean isLeaf(){
		return (this.children.size() == 0);
	}

	public HuiTreeNodeInfo getInfo() {
		return info;
	}

	public void setInfo(HuiTreeNodeInfo info) {
		this.info = info;
	}

	public HuiTreeNode getParent() {
		return parent;
	}

	public Vector<HuiTreeNode> getChildren() {
		return children;
	}

	public int getItemIndex() {
		return itemIndex;
	}

//	public Vector<PathNode> getSubPath(HuiTreeNode root) {
//		Vector<PathNode> path = new Vector<PathNode>();
//		Vector<Float> utility = this.getInfo().getPathUtility();
//		HuiTreeNode node =this;
//		int i=1;
//		int len=utility.size();
//		while(node!=root)
//		{ PathNode pn= new PathNode();
////		pn.setInf(node.getInfo());
//		pn.setUtility(utility.get(len - i));
//		i++;
//			path.add(pn);
//			node=node.parent;
//		}
//		// TODO Auto-generated method stub
//		return path;
//		
//	}
	
//	public Vector<PathNode> getSubPath() {
//		Vector<PathNode> path = new Vector<PathNode>();
//		Vector<Float> utility = this.getInfo().getPathUtility();
//		HuiTreeNode node =this;
//		int i=1;
//		int len=utility.size();
////		System.out.println();
//		while(node.getItemIndex()!=-1)
//		{ PathNode pn= new PathNode();
//		pn.setIndex(node.getItemIndex());
////		pn.setInf(node.getInfo());
//		pn.setUtility(utility.get(len - i));
//		
//		i++;
//			path.add(pn);
//			node=node.parent;
//		}
////		System.out.println(path.size()+ "get path "+utility.size());
//		// TODO Auto-generated method stub
//		return path;
//		
//	}
	

}
