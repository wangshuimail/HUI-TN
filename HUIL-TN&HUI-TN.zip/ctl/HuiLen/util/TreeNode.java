package ctl.HuiLen.util;

import java.util.Vector;

/**
 * @author ssl
 *
 */
public class TreeNode {
	
	private String itemName;
	
	private TreeNode parent;
	private Vector<TreeNode> children;
	
	//index, utility, supcount;
	private AbstractItemValue info;
	
	
	public TreeNode(String name){
		this.itemName = name;
		this.parent = null;
		this.children = new Vector<TreeNode>();
		this.info = new AbstractItemValue();
	}
	
	public TreeNode(String name, TreeNode parent){
		this(name);
		if (parent != null){
			this.parent = parent;
			this.parent.children.add(this);
		}
	}
	
	public String getItemName() {
		return itemName;
	}

	public void addChild(TreeNode child){
		this.children.add(child);
	}
	
	public boolean isRoot(){
		return (null == this.parent);
	}
	
	public boolean isLeaf(){
		return (this.children.size() == 0);
	}

	public AbstractItemValue getInfo() {
		return info;
	}

	public void setInfo(AbstractItemValue info) {
		this.info = info;
	}

	public TreeNode getParent() {
		return parent;
	}

	public Vector<TreeNode> getChildren() {
		return children;
	}
	
	
}
