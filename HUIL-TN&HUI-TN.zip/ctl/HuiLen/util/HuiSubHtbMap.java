package ctl.HuiLen.util;

import java.util.TreeMap;


public class HuiSubHtbMap {

	private TreeMap<Integer, HuiHeadTbValue> subHtbMap;
	
}
