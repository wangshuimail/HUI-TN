package ctl.HuiLen.util;

public class PathNode {
	private int utility;

//	private HuiTreeNodeInfo inf;
	private int index;
	public PathNode(int index2, int utility2) {
		this.index=index2;
		this.utility =utility2;
		// TODO Auto-generated constructor stub
	}
	public PathNode() {
		// TODO Auto-generated constructor stub
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}

//	public HuiTreeNodeInfo getInf() {
//		return inf;
//	}
//	public void setInf(HuiTreeNodeInfo inf) {
//		this.inf = inf;
//	}
	public int getUtility() {
		return utility;
	}
	public void setUtility(int utility) {
		this.utility = utility;
	}


}
