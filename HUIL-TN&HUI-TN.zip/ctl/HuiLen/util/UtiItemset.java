package ctl.HuiLen.util;

import java.util.*;
public class UtiItemset {

	private Vector<String> itemset;
	private float utility;
	
	public UtiItemset(){
		itemset = new Vector<String>();
		utility = 0.0f;
	}

	public Vector<String> getItemset() {
		return itemset;
	}

	public void setItemset(Vector<String> itemset) {
		this.itemset = itemset;
	}

	public float getUtility() {
		return utility;
	}

	public void setUtility(float utility) {
		this.utility = utility;
	}
	
	public void print(){
		System.out.print("Itemset: ");
			Iterator it = itemset.iterator();
			while(it.hasNext()){
				System.out.print(it.next()+",");
			}
		System.out.println(" Utility: "+this.utility);
	}
}
