package ctl.HuiLen.util;

import java.util.Vector;

public class HuiHeadTbValue {
 
	private int twu;
	private int su;
	private int bu;
	private int count;
	private Vector<HuiTreeNode> link; 

	public HuiHeadTbValue() {
		// TODO Auto-generated constructor stub
		this.twu = 0;
		this.count = 0;
		this.su = 0;
		this.bu =0;
		this.link = new Vector<HuiTreeNode>();
	}

	public HuiHeadTbValue(HuiHeadTbValue ht) {
		this.twu = ht.twu;
		this.count=ht.count;
		this.link = new Vector<HuiTreeNode>(ht.link);
		// TODO Auto-generated constructor stub
	}

	public HuiHeadTbValue(HuiHeadTbValue ht, int i) {
		this.twu = ht.twu;
		this.count=ht.count;
		this.link = new Vector<HuiTreeNode>();
		// TODO Auto-generated constructor stub
	}

	public HuiHeadTbValue( int tu,int count2) {
		this.twu=tu;
		this.count=count2;
		this.link = new Vector<HuiTreeNode>();
		// TODO Auto-generated constructor stub
	}

	public int getTwu() {
		return twu;
	}

	public void setTwu(int twu1) {
		this.twu = twu1;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count1) {
		this.count = count1;
	}

	public Vector<HuiTreeNode> getLink() {
		return link;
	}
	
	public void addLink(HuiTreeNode nod){
		this.link.add(nod);
	}
	

}
