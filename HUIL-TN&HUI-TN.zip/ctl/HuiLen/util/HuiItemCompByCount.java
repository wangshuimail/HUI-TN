package ctl.HuiLen.util;
import java.util.Comparator;
import java.util.TreeMap;

import org.apache.commons.collections15.bidimap.TreeBidiMap;

public class HuiItemCompByCount implements Comparator<PathNode> {
	private TreeMap<Integer, HuiHeadTbValue> htlb;
//	private TreeBidiMap<Integer, HeaderCount> htlb;

	public HuiItemCompByCount(TreeMap<Integer, HuiHeadTbValue> htlb) {
		this.htlb = htlb;
	}
	

//	public HuiItemCompByCount(TreeBidiMap<Integer, HeaderCount> header) {
//		this.htlb=header;
//		// TODO Auto-generated constructor stub
//	}


	//��װtwu����
	@Override
	public int compare(PathNode o1, PathNode o2) { //����
//		HuiTreeNode item1 = (HuiTreeNode) o1.getNode();
//		HuiTreeNode item2 = (HuiTreeNode) o2.getNode();
		int index1 = o1.getIndex();
		int index2 = o2.getIndex();
		int count1,count2;
		if(htlb.get(index1)!=null)
		{count1 = htlb.get(index1).getTwu();}
		else
		{
			count1=0;
			o1.setUtility(0);
		}
		if(htlb.get(index2)!=null)
		{count2 = htlb.get(index2).getTwu();}
		else
		{   
			count2=0;
			o2.setUtility(0);
		}
		if (count1 < count2)
			return 1;
		else if (count1 > count2)
			return -1;
		else if(index1>index2)
			return 1;
		else
			return -1;

	}
}
