package ctl.HuiLen.util;

import java.util.Vector;

public class HeaderCountHashNode implements Comparable<HeaderCountHashNode> {
    private int index;
	private int twu;
	private int count;
	private Vector<HuiTreeNodeHash> link; 

	public HeaderCountHashNode(int key, int twu2, int count2) {
		this.index=key;
		this.twu=twu2;
		this.count=count2;
		this.link = new Vector<HuiTreeNodeHash>();
		// TODO Auto-generated constructor stub
	}

	public HeaderCountHashNode(int i, int twu2, int count2, Vector<HuiTreeNodeHash> link2) {
		this.index=i;
		this.twu=twu2;
		this.count=count2;
		this.link = new Vector<HuiTreeNodeHash>(link2);

		// TODO Auto-generated constructor stub
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public int getTwu() {
		return twu;
	}

	public void setTwu(int twu) {
		this.twu = twu;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public Vector<HuiTreeNodeHash> getLink() {
		return link;
	}

	public void setLink(Vector<HuiTreeNodeHash> link) {
		this.link = link;
	}

	@Override
	public int compareTo(HeaderCountHashNode o) { //����֧����С�ģ�index�������ǰ��
		// TODO Auto-generated method stub
		if(this==o) return 0;
		int index1 = this.getIndex();
		int index2 = o.getIndex();
		int count1 = this.getTwu();
		int count2 = o.getTwu();
		if (count1 > count2)
			return 1;
		else if (count1 < count2)
			return -1;
		else if(index1<index2)
			return 1;
		else
			return -1;

		
		
	}

}
