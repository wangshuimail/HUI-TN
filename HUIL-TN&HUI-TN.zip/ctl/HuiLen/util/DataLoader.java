package ctl.HuiLen.util;

/*
 * *
 * input: 		file path
 * procedure: 	read file line by line,and split one line by ',' to instruct vector<...>. 
 * output: 		vector<vector<...>>
 * 
 * author: 		ssl
 * data:		2011-3-29
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class DataLoader {
	private Vector dataSet;
	private String path;
	private int line;
	private boolean multiAttri;

	public DataLoader(String path) {
		this.path = path;
		dataSet = new Vector();
		line = 0;
		multiAttri = false;
	}
	
	public DataLoader(String path, boolean multiAttri){
		this.path = path;
		dataSet = new Vector();
		line = 0;
		this.multiAttri = multiAttri;	
	}

	public void reconstruct() {
		File file = new File(path);
		BufferedReader reader = null;
		java.util.Random r = new java.util.Random(258);
		try {
			reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(file), "UTF-8"));
			String tempString = null;
			line = 0;
			// һ�ζ���һ�У�ֱ������nullΪ�ļ�����
			while ((tempString = reader.readLine()) != null) {
				// ��ʾ�к�
				// System.out.println("line " + line + ": " + tempString);
				tempString=tempString.trim();
				if (tempString.equals(""))
					continue;

				String[] ss = tempString.split(" ");
				int length = ss.length;
				Vector instance = new Vector();
				for (int i = 0; i < length; i++) {
					if (this.multiAttri)
						instance.add("" + i + "-" + ss[i].trim());
					else
						instance.add(ss[i].trim());
					instance.add((r.nextInt(10)+ 1));
				}
				dataSet.add(instance);
				line++;
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e1) {
				}
			}
		}
	}

	public void construct() {
		File file = new File(path);
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(file), "UTF-8"));
			String tempString = null;
			line = 0;
			// һ�ζ���һ�У�ֱ������nullΪ�ļ�����
			while ((tempString = reader.readLine()) != null) {
				// ��ʾ�к�
				// System.out.println("line " + line + ": " + tempString);
				tempString.trim();

				if (tempString.equals(""))
					continue;
				String[] ss = tempString.split(",");
				int length = ss.length;
				Vector instance = new Vector();
				for (int i = 0; i < length; i++)
					instance.add(ss[i].trim());
				dataSet.add(instance);
				line++;
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e1) {
				}
			}
		}
	}

	public Vector getDataSet() {
		return dataSet;
	}

	public int getLine() {
		return line;
	}

	public static void main(String[] arg) {
		String path = "C:\\Documents and Settings\\Administrator\\����\\up-tree\\00up-ʵ�����ݼ�\\chess_dat.txt";

		DataLoader dl = new DataLoader(path);
		dl.construct();
		
		Vector dataset = dl.getDataSet();
		int line = dataset.size();
		for (int j = 0; j < line; j++) {
			System.out.println(((Vector) dataset.get(j)).toString());
		}

		System.out.println(dataset.size());
		
		
		
		
		
		
		


		
		
		
		
		
		
		
		
		
	}
}
