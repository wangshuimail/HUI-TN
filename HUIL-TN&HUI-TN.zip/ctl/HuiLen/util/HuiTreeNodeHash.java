package ctl.HuiLen.util;

import java.util.HashMap;
import java.util.Vector;


public class HuiTreeNodeHash {

	
	private int itemIndex;
	
	private HuiTreeNodeHash parent;
	private HashMap <Integer,HuiTreeNodeHash> children;
//	private Vector<HuiTreeNodeHash> children;
	
	//index, utility, supcount;
	private HuiTreeNodeInfo info;
	private HuiTreeNodeInfo[] infos; //�ñ�����Ϊһ��������ʹ�õ�
	
	
	public HuiTreeNodeInfo[] getInfos() {
		return infos;
	}

	public void setInfos(HuiTreeNodeInfo[] infos) {
		this.infos = infos;
	}

	public HuiTreeNodeHash(int index){
		this.itemIndex = index;
		this.parent = null;
		this.children = new HashMap <Integer,HuiTreeNodeHash>();
		this.info = null;
	}
	
	public HuiTreeNodeHash(int index, HuiTreeNodeHash parent){
		this(index);
		if (parent != null){
			this.parent = parent;
			this.parent.children.put(index,this);
		}
	}
	
	public HuiTreeNodeHash(HuiTreeNodeHash parent) {
		// TODO Auto-generated constructor stub
		this.parent = null;
		this.itemIndex = -1;
		this.children = new HashMap <Integer,HuiTreeNodeHash>();
		this.info = null;
	}

	public void setItemIndex(int itemIndex) {
		this.itemIndex = itemIndex;
	}

	public void setParent(HuiTreeNodeHash parent) {
		this.parent = parent;
		this.parent.children.put(this.getItemIndex(),this);
	}

	public void setChildren(HashMap <Integer,HuiTreeNodeHash> children) {
		this.children = children;
	}

	public HuiTreeNodeHash() {
		this.parent = null;
		this.itemIndex = -1;
		this.children = new HashMap <Integer,HuiTreeNodeHash>();
		this.info = null;

		// TODO Auto-generated constructor stub
	}

	public Integer getItemName() {
		return itemIndex;
	}

//	public void addChild(HuiTreeNodeHash child){
//		this.children.add(child);
//	}
	
	public boolean isRoot(){
		return (null == this.parent);
	}
	
	public boolean isLeaf(){
		return (this.children.size() == 0);
	}

	public HuiTreeNodeInfo getInfo() {
		return info;
	}

	public void setInfo(HuiTreeNodeInfo info) {
		this.info = info;
	}

	public HuiTreeNodeHash getParent() {
		return parent;
	}

	public HashMap <Integer,HuiTreeNodeHash> getChildren() {
		return children;
	}

	public int getItemIndex() {
		return itemIndex;
	}

}
