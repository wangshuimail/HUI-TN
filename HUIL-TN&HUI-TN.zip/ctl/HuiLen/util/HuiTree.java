package ctl.HuiLen.util;

import java.util.*;

import javax.sound.midi.MidiDevice.Info;

import org.apache.commons.collections15.bidimap.TreeBidiMap;

import ctl.HuiLen.Transaction;
import ctl.HuiLen.*;

public class HuiTree {
	private HuiTreeNode root;

	public HuiTreeNode getRoot() {
		return root;
	}

	public void setRoot(HuiTreeNode root) {
		this.root = root;
	}

	public HuiTree() {
		root = new HuiTreeNode(null);
	}

//	public Vector<HuiTreeNode> addInstance(Vector<AbstractItemValue> instance,
//			Vector<HuiTreeNode> tailnode) {
//		Vector<HuiTreeNode> link = new Vector<HuiTreeNode>();
//		HuiTreeNodeInfo tailInfo = new HuiTreeNodeInfo();
//		float su = 0.0f;
//
//		HuiTreeNode tem = root;
//		int i = 0;
//		int size = instance.size();
//		int j = 0;
//		int childsize;
//		Vector<HuiTreeNode> cv;
//
//		for (i = 0; i < size; i++) {
//			cv = tem.getChildren();
//			childsize = cv.size();
//
//			for (j = 0; j < childsize; j++) {
//				if (instance.get(i).getIndex() == cv.get(j).getItemIndex())
//					break;
//			}
//
//			if (j < childsize) {
//				// find.
//				tem = cv.get(j);
//				tailInfo.addUtility(instance.get(i).getUtility());
//				su += instance.get(i).getUtility();
//			} else
//				break;
//		}
//
//		// did not find exist child node.
//		for (; i < size; i++) {
//			HuiTreeNode n = new HuiTreeNode(instance.get(i).getIndex(), tem);
//
//			tailInfo.addUtility(instance.get(i).getUtility());
//			su += instance.get(i).getUtility();
//			link.add(n);
//			tem = n;
//		}
//
//		// ����tail info.
//		tailInfo.setSu(su);
//		tailInfo.setCount(1);
//
//		if (tem.getInfo() == null) {
//			tem.setInfo(tailInfo);
//			tailnode.add(tem);
//		} else {
//			HuiTreeNodeInfo info = tem.getInfo();
//			info.setCount(info.getCount() + 1);
//			info.setSu(info.getSu() + su);
//			info.addPathUtility(tailInfo.getPathUtility());
//		}
//
//		return link;
//	}

//	public Vector<HuiTreeNode> addInstance(Vector<AbstractItemValue> instance) {
//		Vector<HuiTreeNode> link = new Vector<HuiTreeNode>();
//		HuiTreeNodeInfo tailInfo = new HuiTreeNodeInfo();
//		float su = 0.0f;
//
//		HuiTreeNode tem = root;
//		int i = 0;
//		int size = instance.size();
//		int j = 0;
//		int childsize;
//		Vector<HuiTreeNode> cv;
//
//		for (i = 0; i < size; i++) {
//			cv = tem.getChildren();
//			childsize = cv.size();
//
//			for (j = 0; j < childsize; j++) {
//				if (instance.get(i).getIndex() == cv.get(j).getItemIndex())
//					break;
//			}
//
//			if (j < childsize) {
//				// find.
//				tem = cv.get(j);
//				tailInfo.addUtility(instance.get(i).getUtility());
//				su += instance.get(i).getUtility();
//			} else
//				break;
//		}
//
//		// did not find exist child node.
//		for (; i < size; i++) {
//			HuiTreeNode n = new HuiTreeNode(instance.get(i).getIndex(), tem);
//
//			tailInfo.addUtility(instance.get(i).getUtility());
//			su += instance.get(i).getUtility();
//			link.add(n);
//			tem = n;
//		}
//
//		// ����tail info.
//		tailInfo.setSu(su);
//		tailInfo.setCount(1);
//
//		if (tem.getInfo() == null) {
//			tem.setInfo(tailInfo);
//		} else {
//			HuiTreeNodeInfo info = tem.getInfo();
//			info.setCount(info.getCount() + 1);
//			info.setSu(info.getSu() + su);
//			info.addPathUtility(tailInfo.getPathUtility());
//		}
//
//		return link;
//	}

	// get all the tail node and the each distances between it and the ancestor
	// in the ancestor's sub-tree.
	public void getSubTails(HuiTreeNode ancestor, Vector<HuiTreeNode> tails, Vector<Integer> diss, int dis) {

		if (ancestor.getInfo() != null) {
			tails.add(ancestor);
			diss.add(dis);
		}
		dis++;

		Vector<HuiTreeNode> cv = ancestor.getChildren();
		int size = cv.size();
		if (size == 0)
			return;
		else {
			Iterator it = cv.iterator();
			while (it.hasNext()) {
				getSubTails((HuiTreeNode) it.next(), tails, diss, dis);

			}
		}
	}

	// get the path from nod to root.
	public Vector<HuiTreeNode> getPath(HuiTreeNode nod) {
		Vector<HuiTreeNode> path = new Vector<HuiTreeNode>();

		HuiTreeNode tem = nod;
		while (!tem.isRoot()) {
			path.add(tem);
			tem = tem.getParent();
		}
		return path;
	}

	public int nodCount(HuiTreeNode nod) {

		if (nod == null)
			nod = this.root;

		int num = 0;
		Iterator it = nod.getChildren().iterator();
		while (it.hasNext()) {
			num += nodCount((HuiTreeNode) it.next());
		}

		num++;
		return num;
	}

	public Vector<HuiTreeNode> getPathCopy(HuiTreeNode nod) {
		Vector<HuiTreeNode> path = new Vector<HuiTreeNode>();

		HuiTreeNode tem = nod;
		while (!tem.isRoot()) {
			HuiTreeNode newNode = new HuiTreeNode(tem.getItemIndex());
			path.add(newNode);
			tem = tem.getParent();
		}
		return path;

		// TODO Auto-generated method stub
	}

//	public void addInstance(Vector<HuiTreeNode> path,
//			TreeMap<Integer, HuiHeadTbValue> subHtb,Vector<HuiTreeNode> tailnode) {
//		// HuiTreeNodeInfo tailInfo = new HuiTreeNodeInfo();
//		// float su = 0.0f;
//		//	
//		HuiTreeNode tem = this.root;
//		int i = 0;
//		int size = path.size();
//		int j = 0;
//		int childsize;
//		Vector<HuiTreeNode> cv;
//		
//		HuiTreeNodeInfo htni = new HuiTreeNodeInfo(path.get(0).getInfo());
//		float bu = htni.getBu()
//				+ htni.getPathUtility().get(htni.getPathUtility().size() - 1);
//		float su = htni.getSu()
//				- htni.getPathUtility().get(htni.getPathUtility().size() - 1);
//		int count = htni.getCount();
//		htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
//		htni.setBu(bu);
//		htni.setSu(su);
//		for (i = size - 1; i > 0; i--) {
//
//			cv = tem.getChildren();
//			childsize = cv.size();
//
//			for (j = 0; j < childsize; j++) {
//				if (path.get(i).getItemIndex() == cv.get(j).getItemIndex()) {
//					HuiHeadTbValue htbv = subHtb
//							.get(path.get(i).getItemIndex());
//					htbv.setCount(htbv.getCount() + count);
//					htbv.setTwu(htbv.getTwu() + bu + su);
//
//					break;
//				}
//			}
//
//			if (j < childsize) {
//				// find.
//				tem = cv.get(j);
//			} else
//				break;
//		}
//
//		// did not find exist child node.
//		for (; i > 0; i--) {
//			HuiTreeNode n = new HuiTreeNode(path.get(i).getItemIndex(), tem);
//
//			HuiHeadTbValue htbv = subHtb.get(path.get(i).getItemIndex());
//			if (htbv != null) {
//				htbv.setCount(htbv.getCount() + count);
//				htbv.setTwu(htbv.getTwu() + bu + su);
//				htbv.getLink().add(n);
//			} else {
//				Integer key = new Integer(path.get(i).getItemIndex());
//				htbv = new HuiHeadTbValue();
//				htbv.setCount(count);
//				htbv.setTwu(bu + su);
//
//				htbv.getLink().add(n);
//				subHtb.put(key, htbv);
//			}
//
//			tem = n;
//		}
//
//		// ����tail info.
//		if (tem != this.root) {
//			tailnode.add(tem);
//			tem.setInfo(htni);
//
//		}
//	}

//	public void addInstance(Vector<HuiTreeNode> path,
//			TreeMap<Integer, HuiHeadTbValue> subHtb) {
//		// HuiTreeNodeInfo tailInfo = new HuiTreeNodeInfo();
//		// float su = 0.0f;
//		//	
//		HuiTreeNode tem = this.root;
//		int i = 0;
//		int size = path.size();
//		int j = 0;
//		int childsize;
//		Vector<HuiTreeNode> cv;
//		
//		HuiTreeNodeInfo htni = new HuiTreeNodeInfo(path.get(0).getInfo());
//		float bu = htni.getBu()
//				+ htni.getPathUtility().get(htni.getPathUtility().size() - 1);
//		float su = htni.getSu()
//				- htni.getPathUtility().get(htni.getPathUtility().size() - 1);
//		int count = htni.getCount();
//		htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
//		htni.setBu(bu);
//		htni.setSu(su);
//		for (i = size - 1; i > 0; i--) {
//
//			cv = tem.getChildren();
//			childsize = cv.size();
//
//			for (j = 0; j < childsize; j++) {
//				if (path.get(i).getItemIndex() == cv.get(j).getItemIndex()) {
//					HuiHeadTbValue htbv = subHtb
//							.get(path.get(i).getItemIndex());
//					htbv.setCount(htbv.getCount() + count);
//					htbv.setTwu(htbv.getTwu() + bu + su);
//
//					break;
//				}
//			}
//
//			if (j < childsize) {
//				// find.
//				tem = cv.get(j);
//			} else
//				break;
//		}
//
//		// did not find exist child node.
//		for (; i > 0; i--) {
//			HuiTreeNode n = new HuiTreeNode(path.get(i).getItemIndex(), tem);
//
//			HuiHeadTbValue htbv = subHtb.get(path.get(i).getItemIndex());
//			if (htbv != null) {
//				htbv.setCount(htbv.getCount() + count);
//				htbv.setTwu(htbv.getTwu() + bu + su);
//				htbv.getLink().add(n);
//			} else {
//				Integer key = new Integer(path.get(i).getItemIndex());
//				htbv = new HuiHeadTbValue();
//				htbv.setCount(count);
//				htbv.setTwu(bu + su);
//
//				htbv.getLink().add(n);
//				subHtb.put(key, htbv);
//			}
//
//			tem = n;
//		}
//
//		// ����tail info.
//		if (tem != this.root) {
////			tailnode.add(tem);
//			tem.setInfo(htni);
//
//		}
//	}

//	public void addInstance(Vector<PathNode> path,
//			TreeMap<Integer, HuiHeadTbValue> subHtb, HuiTreeNodeInfo hni) {
//		
//		HuiTreeNode tmp = this.root;
//		Vector<Float> utility = new Vector<Float>();
//		int i = 0;
//		int size = path.size();
//		int j = 0;
//		int childsize;
//		Vector<HuiTreeNode> cv;
//		float bu = hni.getBu();
//		float su = 0.0f;
//		int count = hni.getCount();
//		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
//		Vector<HuiTreeNode> ch = tmp.getChildren();
//		for (i = 0; i < size; i++) { // path������root
//
//			if (path.get(i).getUtility() < 0.0001)
//				break;
//			int chsize = ch.size();
//			for (j = 0; j < chsize; j++) {
//				if (path.get(i).getIndex() == ch.get(j)
//						.getItemIndex())
//					break;
//			}
//			if (j == chsize)
//				break;
//			else {
//				tmp = ch.get(j);
//				ch = tmp.getChildren();
//			}
//			float ut =path.get(i).getUtility();
//			utility.add(ut);
//			su=su+ut;
//
//		}
//		for (; i < size; i++) {
//			if (path.get(i).getUtility() < 0.0001)
//				break;
////			int itemindex =path.get(i).getNode().getItemIndex();
//			int itemindex =path.get(i).getIndex();
//			float ut =path.get(i).getUtility();
//			utility.add(ut);
//			su=su+ut;
//			HuiTreeNode initem = new HuiTreeNode();
//			initem.setItemIndex(itemindex);
//			initem.setParent(tmp);
//			tmp = initem;
//			subHtb.get(itemindex).getLink().add(initem);//add link
//		}
//		if(i==0) return;
//		
//				// ����tail info.
//		if(tmp.getInfo()!=null)
//		{
//			tmp.getInfo().setBu(tmp.getInfo().getBu()+bu );
//			tmp.getInfo().setCount(tmp.getInfo().getCount()+count);
//			tmp.getInfo().setSu(tmp.getInfo().getSu()+su);
//			tmp.getInfo().addPathUtility(utility);
//		}
//		else
//		{  
//			tmp.setInfo(new HuiTreeNodeInfo(count,bu,su,utility));
//		}	
//		// TODO Auto-generated method stub
//		
//	}


	public Vector<PathNode> getPath(HuiTreeNode nod, TreeMap<Integer, HuiHeadTbValue> subHtb) {
		Vector<PathNode> path = new Vector<PathNode>();

		HuiTreeNode tem = nod;
		HuiTreeNodeInfo NodeInf = nod.getInfo();
		if(NodeInf==null) {
			System.out.println("errrr.......................");
		}
		Vector<Integer> utility = NodeInf.getPathUtility();
//		int count=NodeInf.getCount();
		int tu = NodeInf.getPathSU().get(NodeInf.getPathSU().size() - 1) + nod.getInfo().getBu();
		if (tem.isRoot())
			return null;
		tem = tem.getParent();
		int i = 2;
		int len = utility.size();
		while (!tem.isRoot()) {
			int itemindex = tem.getItemIndex();
//			PathNode pn =new PathNode(itemindex,utility.get(len-i));
//			pn.setNode(tem);
//			pn.setIndex(itemindex);
//			pn.setUtility(utility.get(len-i));
			path.add(new PathNode(itemindex, utility.get(len - i)));
			i++;

//			subTreeSu[itemindex] +=tu;

			HuiHeadTbValue htbv = subHtb.get(itemindex);
			if (htbv != null) {
//				htbv.setCount(htbv.getCount() + count);
				htbv.setTwu(htbv.getTwu() + tu);
			} else {
				subHtb.put(new Integer(itemindex), new HuiHeadTbValue(tu, 0));
			}
			tem = tem.getParent();
		}

		return path;

		// TODO Auto-generated method stub
	}

	// β�ڵ��ϲ�����Su,Sn, ͷ���ϱ���rtwu
	public Vector<PathNode> getPath1(HuiTreeNode nod, TreeMap<Integer, HuiHeadTbValue> subHtb) {
		Vector<PathNode> path = new Vector<PathNode>();

		HuiTreeNode tem = nod;
		HuiTreeNodeInfo NodeInf = nod.getInfo();
		Vector<Integer> utility = NodeInf.getPathUtility();
//		int count=NodeInf.getCount();
		int tu = nod.getInfo().getBu();
		for (int i = 0; i < utility.size(); i++) {
			tu = tu + utility.get(i);
		}
		if (tem.isRoot())
			return null;
		tem = tem.getParent();
		int i = 2;
		int len = utility.size();
		while (!tem.isRoot()) {
			int itemindex = tem.getItemIndex();
//			PathNode pn =new PathNode(itemindex,utility.get(len-i));
//			pn.setNode(tem);
//			pn.setIndex(itemindex);
//			pn.setUtility(utility.get(len-i));
			path.add(new PathNode(itemindex, utility.get(len - i)));
			i++;

//			subTreeSu[itemindex] +=tu;

			HuiHeadTbValue htbv = subHtb.get(itemindex);
			if (htbv != null) {
//				htbv.setCount(htbv.getCount() + count);
				htbv.setTwu(htbv.getTwu() + tu);
			} else {
				subHtb.put(new Integer(itemindex), new HuiHeadTbValue(tu, 0));
			}
			tem = tem.getParent();
		}

		return path;

		// TODO Auto-generated method stub
	}

	public Vector<PathNode> getPathWithoutPathSu(HuiTreeNode nod, TreeMap<Integer, HuiHeadTbValue> subHtb) {
		Vector<PathNode> path = new Vector<PathNode>();

		HuiTreeNode tem = nod;
		HuiTreeNodeInfo NodeInf = nod.getInfo();
		Vector<Integer> utility = NodeInf.getPathUtility();
//		int count = NodeInf.getCount();
//		int tu = NodeInf.getSu() + NodeInf.getBu();
		
		int tu = NodeInf.getBu() ;
		for(int i=0;i<NodeInf.getPathUtility().size();i++)
		{
			tu = tu + NodeInf.getPathUtility().get(i);
		}
//		int tu = NodeInf.getPathSU().get(NodeInf.getPathSU().size()-1)+nod.getInfo().getBu();
		if (tem.isRoot())
			return null;
		tem = tem.getParent();
		int i = 2;
		int len = utility.size();
		while (!tem.isRoot()) {
			int itemindex = tem.getItemIndex();
//			PathNode pn =new PathNode(itemindex,utility.get(len-i));
//			pn.setNode(tem);
//			pn.setIndex(itemindex);
//			pn.setUtility(utility.get(len-i));
			path.add(new PathNode(itemindex, utility.get(len - i)));
			i++;

//			subTreeSu[itemindex] +=tu;

			HuiHeadTbValue htbv = subHtb.get(itemindex);
			if (htbv != null) {
//				htbv.setCount(htbv.getCount() + count);
				htbv.setTwu(htbv.getTwu() + tu);
			} else {
				subHtb.put(new Integer(itemindex), new HuiHeadTbValue(tu, 0));
			}
			tem = tem.getParent();
		}

		return path;

		// TODO Auto-generated method stub
	}

//	public Vector<PathNode> getPath(HuiTreeNode nod,
//			TreeMap<Integer, HuiHeadTbValue> subHtb) {
//		Vector<PathNode> path = new Vector<PathNode>();
//
//		HuiTreeNode tem = nod;
//		Vector <Integer> utility = nod.getInfo().getPathUtility();
//		int count=nod.getInfo().getCount();
//		int tu = nod.getInfo().getSu() +nod.getInfo().getBu();
//		if(tem.isRoot()) return null;
//		tem=tem.getParent();
//		int i=2;
//		int len=utility.size();
//		while (!tem.isRoot()) {
//			int itemindex = tem.getItemIndex();
////			PathNode pn =new PathNode(itemindex,utility.get(len-i));
////			pn.setNode(tem);
////			pn.setIndex(itemindex);
////			pn.setUtility(utility.get(len-i));
//			path.add(new PathNode(itemindex,utility.get(len-i)));
//			i++;
//
//			HuiHeadTbValue htbv = subHtb.get(itemindex);
//			if (htbv != null) {
//				htbv.setCount(htbv.getCount() + count);
//				htbv.setTwu(htbv.getTwu() + tu);
//				} else {
//				subHtb.put(new Integer(itemindex), new HuiHeadTbValue(tu,count));
//			}
//			tem = tem.getParent();
//		}
//
//		return path;
//
//		// TODO Auto-generated method stub
//	}

//	
//	public Vector<PathNode> getPathImp(HuiTreeNode nod,
//			TreeMap<Integer, HuiHeadTbValue> subHtb) {
//		Vector<PathNode> path = new Vector<PathNode>();
//
//		HuiTreeNode tem = nod;
//		Vector <Float> utility = nod.getInfo().getPathUtility();
//		int count=nod.getInfo().getCount();
//		float tu = nod.getInfo().getSu() +nod.getInfo().getBu() + utility.get(utility.size()-1);
//		if(tem.isRoot()) return null;
//		tem=tem.getParent();
//		int i=2;
//		int len=utility.size();
//		while (!tem.isRoot()) {
//			int itemindex = tem.getItemIndex();
////			PathNode pn =new PathNode(itemindex,utility.get(len-i));
////			pn.setNode(tem);
////			pn.setIndex(itemindex);
////			pn.setUtility(utility.get(len-i));
//			path.add(new PathNode(itemindex,utility.get(len-i)));
//		
//			HuiHeadTbValue htbv = subHtb.get(itemindex);
//			if (htbv != null) {
//				htbv.setCount(htbv.getCount() + count);
//				htbv.setTwu(htbv.getTwu() + tu + utility.get(len-i));
//				} else {
//				subHtb.put(new Integer(itemindex), new HuiHeadTbValue(tu + utility.get(len-i),count));
//			}
//			tem = tem.getParent();
//			i++;
//
//		}
//
//		return path;
//
//		// TODO Auto-generated method stub
//	}
//	public Vector<PathNode> getPathImp2(HuiTreeNode nod,
//			TreeMap<Integer, HuiHeadTbValue> subHtb) {
//		Vector<PathNode> path = new Vector<PathNode>();
//
//		HuiTreeNode tem = nod;
//		Vector <Float> utility = nod.getInfo().getPathUtility();
//		int count=nod.getInfo().getCount();
//		float tu = nod.getInfo().getSu() +nod.getInfo().getBu() ;
//		if(tem.isRoot()) return null;
//		tem=tem.getParent();
//		int i=2;
//		int len=utility.size();
//		while (!tem.isRoot()) {
//			int itemindex = tem.getItemIndex();
////			PathNode pn =new PathNode(itemindex,utility.get(len-i));
////			pn.setNode(tem);
////			pn.setIndex(itemindex);
////			pn.setUtility(utility.get(len-i));
//			path.add(new PathNode(itemindex,utility.get(len-i)));
//		
//			HuiHeadTbValue htbv = subHtb.get(itemindex);
//			if (htbv != null) {
//				htbv.setCount(htbv.getCount() + count);
//				htbv.setTwu(htbv.getTwu() + tu + utility.get(len-i));
//				} else {
//				subHtb.put(new Integer(itemindex), new HuiHeadTbValue(tu + utility.get(len-i),count));
//			}
//			tem = tem.getParent();
//			i++;
//
//		}
//
//		return path;
//
//		// TODO Auto-generated method stub
//	}

//	public Vector<PathNode> getPath(HuiTreeNode nod,
//			TreeMap<Integer, HuiHeadTbValue> subHtb, int maxlen) {
//		Vector<PathNode> path = new Vector<PathNode>();
//
//		HuiTreeNode tem = nod;
//		Vector <Float> utility = nod.getInfo().getPathUtility();
//		int count=nod.getInfo().getCount();
//		float tu = nod.getInfo().getSu() +nod.getInfo().getBu();
//		if(tem.isRoot()) return null;
//		tem=tem.getParent();
//		int i=2;
//		int len=utility.size();
//		while (!tem.isRoot()) {
//			int itemindex = tem.getItemIndex();
////			PathNode pn =new PathNode(itemindex,utility.get(len-i));
////			pn.setNode(tem);
////			pn.setIndex(itemindex);
////			pn.setUtility(utility.get(len-i));
//			path.add(new PathNode(itemindex,utility.get(len-i)));
//			i++;
//
//			HuiHeadTbValue htbv = subHtb.get(itemindex);
//			if (htbv != null) {
//				htbv.setCount(htbv.getCount() + count);
//				htbv.setTwu(htbv.getTwu() + tu);
//				} else {
//				subHtb.put(new Integer(itemindex), new HuiHeadTbValue(tu,count));
//			}
//			tem = tem.getParent();
//		}
//
//		return path;
//
//		// TODO Auto-generated method stub
//	}

//	public Vector<PathNode> getPath(HuiTreeNode nod,
//			TreeMap<Integer, HuiHeadTbValue> subHtb,int countLen) { 
//		Vector<PathNode> path = new Vector<PathNode>();
//
//		HuiTreeNode tem = nod;
//		Vector <Float> utility = nod.getInfo().getPathUtility();
//		int count=nod.getInfo().getCount();
//		float tuLen=0.0f;
//		tuLen = FindMaxLenTwu(utility,countLen);
//		// �����󳤶�L���������L1����countLen = L - L1 -1�� �������nod
//		
//		for(int i=0;i<utility.size()&&i<countLen;i++)
//		{
//			tuLen = tuLen + utility.get(i);
//		}
////		float tu = nod.getInfo().getSu() +nod.getInfo().getBu();
//		float tu = tuLen +nod.getInfo().getBu();
//		if(tem.isRoot()) return null;
//		tem=tem.getParent();
//		int i=2;
//		int len=utility.size();
//		while (!tem.isRoot()) {
//			int itemindex = tem.getItemIndex();
////			PathNode pn =new PathNode(itemindex,utility.get(len-i));
////			pn.setNode(tem);
////			pn.setIndex(itemindex);
////			pn.setUtility(utility.get(len-i));
//			float Cutility = utility.get(len-i);
//			path.add(new PathNode(itemindex,Cutility));
//			i++;
//
//			HuiHeadTbValue htbv = subHtb.get(itemindex);
//			if (htbv != null) {
//				htbv.setCount(htbv.getCount() + count);
//				htbv.setTwu(htbv.getTwu() + tu + Cutility);
//				} else {
//				subHtb.put(new Integer(itemindex), new HuiHeadTbValue((tu + Cutility),count));
//			}
//			tem = tem.getParent();
//		}
//		return path;
//
//		// TODO Auto-generated method stub
//	}
//	
//	private float FindMaxLenTwu(Vector <Float> arr, int len) {
//		float tempTwu=0.0f;
//		int l=arr.size();
////		float maxU = 0.0f;
//		int ind =0; //��ʼ��Ϊ0���λ��
//		Boolean [] booln = new Boolean[l]; //�����������ж���ǰ���ֵ���ݼ�¼�ҵ������λ��
//		for(int i=0;i<l;i++)
//		{
//			booln[i]= false;
//		}
//		for(int i=0;i<len;i++)
//		{
////			maxU = 0.0f;
//			for(int j=1;j<l;j++)
//			{
//				if(booln[j]) continue;
//				if(arr.get(j)>arr.get(ind))
//				{
//					ind =j;
////					maxU = arr[j]; //��¼���ֵ
//				}
//			}
//			
//			tempTwu = tempTwu + arr.get(ind);
//			booln[ind]=true;  //���������ֵ�޸�Ϊ0������Ӱ������һ�����
//		}
//		
//		return tempTwu;
//		
//	}
//	public Vector<PathNode> getPath(HuiTreeNode nod,
//			TreeBidiMap<Integer, HeaderCount> header) {
//		Vector<PathNode> path = new Vector<PathNode>();
//
//		HuiTreeNode tem = nod;
//		Vector <Float> utility = nod.getInfo().getPathUtility();
//		int count=nod.getInfo().getCount();
//		float tu = nod.getInfo().getSu() +nod.getInfo().getBu();
////		if(tem.isRoot()) return null;
//		tem=tem.getParent();
//		int i=2;
//		int len=utility.size();
//		int nodecount=0;
//		while (!tem.isRoot()) {
//			nodecount++;
//			int itemindex = tem.getItemIndex();
//			PathNode pn =new PathNode();
////			pn.setNode(tem);
//			pn.setIndex(itemindex);
//			pn.setUtility(utility.get(len-i));
//			i++;
//			path.add(pn);
//			
//			HeaderCount htbv = header.get(itemindex);
//			if (htbv != null) {
//				htbv.setCount(htbv.getCount() + count);
//				htbv.setTwu(htbv.getTwu() + tu);
//				} else {
//				header.put(new Integer(itemindex), new HeaderCount(itemindex, tu,
//						count));
//			}
//			tem = tem.getParent();
//		}
//		PathNode pn =new PathNode();
////		
////		pn.setInf(nod.getInfo());
////		pn.setIndex(nod.getItemIndex());
//		pn.setIndex(nodecount);
//		path.add(pn);
//		return path;
//		// TODO Auto-generated method stub
//	}

	// ������transaction���ӵ�����,������ȫ����
	public int addtransactionGlobal(Transaction path, int[] NodeRtwu, int[] NodeNu, Arrlist[] Nodelink) {

		HuiTreeNode tmp = this.root;
		Vector<Integer> utility = new Vector<Integer>();
		int i = 0;
		int size = path.getLen();
//		System.out.println("size0"+size);
		int j = 0;
		int childsize;
//		Vector<HuiTreeNode> cv;
		int bu = 0;
//		int su = path.tempUtilities[path.getLen()-1];
		int count = 1;
		int newcount = 0;

		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
		Vector<HuiTreeNode> ch = tmp.getChildren();
//		int test1=0;
		for (i = 0; i < size; i++) { // path������root
			if (path.getUtilities()[i] ==0)
				break;

			
			int item = path.getItems()[i];
			
//			if(test1==774 && item==774) System.out.println(" HUiTree errror............................");
			
			int chsize = ch.size();
			for (j = 0; j < chsize; j++) {
				if (item == ch.get(j).getItemIndex())
					break;
			}
			if (j == chsize)
				break;
			else {
				tmp = ch.get(j);
				ch = tmp.getChildren();
			}
//			int ut =path.get(i).getUtility();
			utility.add(path.getUtilities()[i]);
//			su=su+ut;
			NodeNu[item] += path.getUtilities()[i];
			NodeRtwu[item] += path.tempUtilities[i]; //
			
//			if(item==336) System.out.println(" HUiTree errror............................");

//test1 = item;
		}
		for (; i < size; i++) {
			if (path.getUtilities()[i] ==0)
				break;
			int item = path.getItems()[i];
			
//			if(item==336) System.out.println(" HUiTree errror............................");
//			System.out.println(item+"size"+size);
			NodeNu[item] += path.getUtilities()[i];
			NodeRtwu[item] += path.tempUtilities[i]; //
			utility.add(path.getUtilities()[i]);
//			su=su+ut;
			HuiTreeNode initem = new HuiTreeNode();
			initem.setItemIndex(item);
			initem.setParent(tmp);
			tmp = initem;
			if (Nodelink[item] == null)
				Nodelink[item] = new Arrlist();
			Nodelink[item].getArrList().add(initem);
			newcount++;
			
//			test1 = item;
		}
		if (i == 0)
			return newcount;
//		int su = path.tempUtilities[path.getLen()-1];
		// ����tail info.
		if (tmp.getInfo() != null) {
			tmp.getInfo().setBu(0);
//			tmp.getInfo().setCount(tmp.getInfo().getCount()+count);
//			tmp.getInfo().setSu(tmp.getInfo().getSu()+su);
			tmp.getInfo().addPathUtility(utility);
			tmp.getInfo().addPathSU(path.tempUtilities, size);
//			System.out.println("have one more times!!!!!!!!!!!!!!!");
		} else {
//			tmp.setInfo(new HuiTreeNodeInfo(count,bu,su,utility));
			tmp.setInfo(new HuiTreeNodeInfo(bu, utility, path.tempUtilities, size));
		}
		// TODO Auto-generated method stub

		return newcount;
		// TODO Auto-generated method stub

	}

	// ������transaction���ӵ�����,������ȫ����.û�г���Լ����
//	public int addtransactionGlobalNoLen1(Transaction path,int [] NodeSu, int [] NodeNu,int[] NodeBu,
//			Arrlist [] Nodelink ) {
//		
//		
//		HuiTreeNode tmp = this.root;
//		Vector<Integer> utility = new Vector<Integer>();
//		int i = 0;
//		int size = path.getLen();
//		int j = 0;
//		int childsize;
////		Vector<HuiTreeNode> cv;
//		int bu =0;
////		int su = path.tempUtilities[path.getLen()-1];
//		int count = 1;
//		int newcount=0;
//		
//		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
//		Vector<HuiTreeNode> ch = tmp.getChildren();
//		for (i = 0; i < size; i++) { // path������root
////			if (path.get(i).getUtility() < 0.0001)
////				break;
//			
//			int item = path.getItems()[i];
//			int chsize = ch.size();
//			for (j = 0; j < chsize; j++) {
//				if (item == ch.get(j).getItemIndex())
//					break;
//			}
//			if (j == chsize)
//				break;
//			else {
//				tmp = ch.get(j);
//				ch = tmp.getChildren();
//			}
////			int ut =path.get(i).getUtility();
//			utility.add(path.getUtilities()[i]);
////			su=su+ut;
//			NodeNu[item] += path.getUtilities()[i];
//			NodeSu[item] += path.tempUtilities[i]; //
//
//		}
//		for (; i < size; i++) {
////			if (path.get(i).getUtility() < 0.0001)
////				break;
//			int item = path.getItems()[i];
//			NodeNu[item] += path.getUtilities()[i];
//			NodeSu[item] += path.tempUtilities[i]; //
//			utility.add(path.getUtilities()[i]);
////			su=su+ut;
//			HuiTreeNode initem = new HuiTreeNode();
//			initem.setItemIndex(item);
//			initem.setParent(tmp);
//			tmp = initem;
//			if(Nodelink[item]==null)
//				Nodelink[item] = new Arrlist();
//			 Nodelink[item].getArrList().add(initem);
//			 newcount++;
//		}
//		if(i==0) return newcount;
//		int su = path.tempUtilities[path.getLen()-1];
//		// ����tail info.
//		if(tmp.getInfo()!=null)
//		{
//			tmp.getInfo().setBu(0);
//			tmp.getInfo().setCount(tmp.getInfo().getCount()+count);
//			tmp.getInfo().setSu(tmp.getInfo().getSu()+su);
//			tmp.getInfo().addPathUtility(utility);
//			tmp.getInfo().addPathSU(path.tempUtilities,size);
////			System.out.println("have one more times!!!!!!!!!!!!!!!");
//		}
//		else
//		{
////			tmp.setInfo(new HuiTreeNodeInfo(count,bu,su,utility));
//			tmp.setInfo(new HuiTreeNodeInfo(count,bu,su,utility,path.tempUtilities,size));
//		}	
//		// TODO Auto-generated method stub
//		
//		return newcount;
//		// TODO Auto-generated method stub
//		
//	}

	// ������transaction���ӵ�����,������ȫ����..û�г���Լ����
	public int addtransactionGlobalNoLen(Transaction path, int[] NodeRtwu, int[] NodeNu, Arrlist[] Nodelink) {

		HuiTreeNode tmp = this.root;
		Vector<Integer> utility = new Vector<Integer>();
		int i = 0;
		int size = path.getLen();
		int j = 0;
		int childsize;
//		Vector<HuiTreeNode> cv;
		int bu = 0;
		int rtwu = 0;
		int nu = 0;
		int count = 1;
		int newcount = 0;

		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
		Vector<HuiTreeNode> ch = tmp.getChildren();

		for (i = 0; i < size; i++) { // path������root
//			if (path.get(i).getUtility() < 0.0001)
//				break;

			int item = path.getItems()[i];
			int chsize = ch.size();
			for (j = 0; j < chsize; j++) {
				if (item == ch.get(j).getItemIndex())
					break;
			}
			if (j == chsize)
				break;
			else {
				tmp = ch.get(j);
				ch = tmp.getChildren();
			}
			nu = path.getUtilities()[i];
			utility.add(nu);
			rtwu = rtwu + nu;
			NodeNu[item] += nu;
			NodeRtwu[item] += rtwu; //

		}
		for (; i < size; i++) {
//			if (path.get(i).getUtility() < 0.0001)
//				break;
			int item = path.getItems()[i];
			nu = path.getUtilities()[i];
			rtwu = rtwu + nu;
			NodeNu[item] += nu;
			NodeRtwu[item] += rtwu; //
			utility.add(nu);
//			su=su+ut;
			HuiTreeNode initem = new HuiTreeNode();
			initem.setItemIndex(item);
			initem.setParent(tmp);
			tmp = initem;
			if (Nodelink[item] == null)
				Nodelink[item] = new Arrlist();
			Nodelink[item].getArrList().add(initem);
			newcount++;
		}
		if (i == 0)
			return newcount;
//		int su = path.tempUtilities[path.getLen()-1];
		// ����tail info.
		if (tmp.getInfo() != null) {
			tmp.getInfo().setBu(0);
//			tmp.getInfo().setCount(tmp.getInfo().getCount()+count);
//			tmp.getInfo().setSu(tmp.getInfo().getSu()+su);
			tmp.getInfo().addPathUtility(utility);
//			tmp.getInfo().addPathSU(path.tempUtilities,size);
//			System.out.println("have one more times!!!!!!!!!!!!!!!");
		} else {
//			tmp.setInfo(new HuiTreeNodeInfo(count,bu,su,utility));
			tmp.setInfo(new HuiTreeNodeInfo(bu, utility));
		}
		// TODO Auto-generated method stub

		return newcount;
		// TODO Auto-generated method stub

	}

//	public void addInstance(Vector<PathNode> path, TreeBidiMap<Integer, HeaderCount> subHtb, HuiTreeNodeInfo hni) {
//		// HuiTreeNodeInfo tailInfo = new HuiTreeNodeInfo();
//		// float su = 0.0f;
//		//
//		HuiTreeNode tmp = this.root;
//		Vector<Integer> utility = new Vector<Integer>();
////		Vector<Integer> pathSU = new Vector<Integer>();
//		int i = 0;
//		int size = path.size();
//		int j = 0;
////		int childsize;
////		Vector<HuiTreeNode> cv;
//		int bu = hni.getBu();
//		int su = 0;
//		int count = hni.getCount();
//		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
//		Vector<HuiTreeNode> ch = tmp.getChildren();
//		for (i = 0; i < size; i++) { // path������root
////             int itemindex = path.get(i).getIndex();
//			if (path.get(i).getUtility() < 0.0001)
//				break;
//			int chsize = ch.size();
//			for (j = 0; j < chsize; j++) {
//				if (path.get(i).getIndex() == ch.get(j).getItemIndex())
//					break;
//			}
//			if (j == chsize)
//				break;
//			else {
//				tmp = ch.get(j);
//				ch = tmp.getChildren();
//			}
//			utility.add(path.get(i).getUtility());
//			su = su + path.get(i).getUtility();
//
//		}
//		for (; i < size; i++) {
//			if (path.get(i).getUtility() < 0.0001)
//				break;
//			utility.add(path.get(i).getUtility());
//			su = su + path.get(i).getUtility();
//			HuiTreeNode initem = new HuiTreeNode();
//			int itemindex = path.get(i).getIndex();
//			initem.setItemIndex(itemindex);
//			initem.setParent(tmp);
//			tmp = initem;
//			if (subHtb.get(itemindex) != null) {
//				subHtb.get(itemindex).getLink().add(initem);
//			} // add link
//		}
//		if (i == 0)
//			return;
//
//		// ����tail info.
//		if (tmp.getInfo() != null) {
//			tmp.getInfo().setBu(tmp.getInfo().getBu() + bu);
//			tmp.getInfo().setCount(tmp.getInfo().getCount() + count);
//			tmp.getInfo().setSu(tmp.getInfo().getSu() + su);
//			tmp.getInfo().addPathUtility(utility);
////			System.out.println("have same node, tmp.getInfo()......"+tmp.getInfo().getCount());
//		} else {
//			tmp.setInfo(new HuiTreeNodeInfo(count, bu, su, utility));
////			System.out.println("tmp.getInfo()......"+tmp.getInfo().getCount());
//		}
//	}

	// ���ӵ�ʱ����Ҫ
	public void addInstance1(Vector<PathNode> path, TreeBidiMap<Integer, HeaderCount> subHtb, HuiTreeNodeInfo hni) {
		// HuiTreeNodeInfo tailInfo = new HuiTreeNodeInfo();
		// float su = 0.0f;
		//
		HuiTreeNode tmp = this.root;
		Vector<Integer> utility = new Vector<Integer>();
//		Vector<Integer> pathSU = new Vector<Integer>();
		int i = 0;
		int size = path.size();
		int j = 0;
//		int childsize;
//		Vector<HuiTreeNode> cv;
		int bu = hni.getBu();
		int rtwu = 0;
//		int count = hni.getCount();
		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
		Vector<HuiTreeNode> ch = tmp.getChildren();
		int itemindex;
		for (i = 0; i < size; i++) { // path������root
			itemindex = path.get(i).getIndex();
			if (path.get(i).getUtility() ==0)
				break;
			int chsize = ch.size();
			for (j = 0; j < chsize; j++) {
				if (itemindex == ch.get(j).getItemIndex())
					break;
			}
			if (j == chsize)
				break;
			else {
				tmp = ch.get(j);
				ch = tmp.getChildren();
			}
			utility.add(path.get(i).getUtility());
			rtwu = rtwu + path.get(i).getUtility();
			subHtb.get(itemindex).setCount(rtwu + bu+ subHtb.get(itemindex).getCount());
		}
		for (; i < size; i++) {
			if (path.get(i).getUtility() == 0)
				break;
			utility.add(path.get(i).getUtility());
			rtwu = rtwu + path.get(i).getUtility();
			HuiTreeNode initem = new HuiTreeNode();
			itemindex = path.get(i).getIndex();
			initem.setItemIndex(itemindex);
			initem.setParent(tmp);
			tmp = initem;
			if (subHtb.get(itemindex) != null) {
				subHtb.get(itemindex).getLink().add(initem);
				subHtb.get(itemindex).setCount(rtwu + bu+ subHtb.get(itemindex).getCount());
			} // add link
		}
		if (i == 0)
			return;

		// ����tail info.
		if (tmp.getInfo() != null) {
			tmp.getInfo().setBu(tmp.getInfo().getBu() + bu);
//			tmp.getInfo().setCount(tmp.getInfo().getCount()+count);
//			tmp.getInfo().setSu(tmp.getInfo().getSu()+su);
			tmp.getInfo().addPathUtility(utility);
//			System.out.println("have same node, tmp.getInfo()......"+tmp.getInfo().getCount());
		} else {
			tmp.setInfo(new HuiTreeNodeInfo(bu, utility));
//			System.out.println("tmp.getInfo()......"+tmp.getInfo().getCount());
		}
	}

	public void addInstance(Vector<PathNode> path, TreeBidiMap<Integer, HeaderCount> subHtb, HuiTreeNodeInfo hni,
			Vector<Integer> pathSU) {
		// HuiTreeNodeInfo tailInfo = new HuiTreeNodeInfo();
		// float su = 0.0f;
		//
		HuiTreeNode tmp = this.root;
		Vector<Integer> utility = new Vector<Integer>();
//		Vector<Integer> pathSU = new Vector<Integer>();
		int i = 0;
		int size = path.size();
		int j = 0;
//		int childsize;
//		Vector<HuiTreeNode> cv;
		int bu = hni.getBu();
//		int rtwu = 0;
//		int count = hni.getCount();
		int itemindex;
		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
		Vector<HuiTreeNode> ch = tmp.getChildren();
		for (i = 0; i < size; i++) { // path������root
//             int itemindex = path.get(i).getIndex();
			itemindex = path.get(i).getIndex();
			if (path.get(i).getUtility() == 0)
				break;
			int chsize = ch.size();
			for (j = 0; j < chsize; j++) {
				if (itemindex == ch.get(j).getItemIndex())
					break;
			}
			if (j == chsize)
				break;
			else {
				tmp = ch.get(j);
				ch = tmp.getChildren();
			}
			utility.add(path.get(i).getUtility());
//			r=su+path.get(i).getUtility();

			subHtb.get(itemindex).setCount(pathSU.get(i) + bu + subHtb.get(itemindex).getCount()); // rTwuk
//			subHtb.get(itemindex).set
//			System.out.println(itemindex+" add // "+(pathSU.get(i)+bu+subHtb.get(itemindex).getCount()));
		}
		for (; i < size; i++) {
			if (path.get(i).getUtility() == 0)
				break;
			utility.add(path.get(i).getUtility());
//			su=su+path.get(i).getUtility();
			HuiTreeNode initem = new HuiTreeNode();
			itemindex = path.get(i).getIndex();
			initem.setItemIndex(itemindex);
			initem.setParent(tmp);
			tmp = initem;
			if (subHtb.get(itemindex) != null) {
				subHtb.get(itemindex).getLink().add(initem);// add link
				subHtb.get(itemindex).setCount(pathSU.get(i) + bu + subHtb.get(itemindex).getCount()); // rTwuk
//				System.out.println(itemindex+" add// "+(pathSU.get(i)+bu+subHtb.get(itemindex).getCount()));
			}
		}
		if (i == 0)
			return;

		// ����tail info.
		if (tmp.getInfo() != null) {
			tmp.getInfo().setBu(tmp.getInfo().getBu() + bu);
//			tmp.getInfo().setCount(tmp.getInfo().getCount()+count);
//			tmp.getInfo().setSu(tmp.getInfo().getSu()+su);
			tmp.getInfo().addPathUtility(utility);
			tmp.getInfo().addPathSU(pathSU);
//			System.out.println("have same node, tmp.getInfo()......"+tmp.getInfo().getCount());
		} else {
//			tmp.setInfo(new HuiTreeNodeInfo(count,bu,su,utility));
//			System.out.println(pathSU.size()+"//"+size);
			tmp.setInfo(new HuiTreeNodeInfo(bu, utility, pathSU, i)); // i �������񳤶�
//			System.out.println("tmp.getInfo()......"+tmp.getInfo().getCount());
		}
	}

	public void addInstance1(Vector<PathNode> path, TreeBidiMap<Integer, HeaderCount> subHtb, HuiTreeNodeInfo hni,
			Vector<Integer> pathSU) {
		// HuiTreeNodeInfo tailInfo = new HuiTreeNodeInfo();
		// float su = 0.0f;
		//
		HuiTreeNode tmp = this.root;
		Vector<Integer> utility = new Vector<Integer>();
//		Vector<Integer> pathSU = new Vector<Integer>();
		int i = 0;
		int size = path.size();
		int j = 0;
//		int childsize;
//		Vector<HuiTreeNode> cv;
		int bu = hni.getBu();
//		int rtwu = 0;
//		int count = hni.getCount();
		int itemindex;
		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
		Vector<HuiTreeNode> ch = tmp.getChildren();
		HeaderCount subnode;
		for (i = 0; i < size; i++) { // path������root
//             int itemindex = path.get(i).getIndex();
			itemindex = path.get(i).getIndex();
			if (path.get(i).getUtility() == 0)
				break;
			int chsize = ch.size();
			for (j = 0; j < chsize; j++) {
				if (itemindex == ch.get(j).getItemIndex())
					break;
			}
			if (j == chsize)
				break;
			else {
				tmp = ch.get(j);
				ch = tmp.getChildren();
			}
			utility.add(path.get(i).getUtility());
//			r=su+path.get(i).getUtility();
			subnode = subHtb.get(itemindex);
			subnode.setTwu(pathSU.get(i) + bu + subHtb.get(itemindex).getTwu()); // rTwuk
			subnode.setCount(path.get(i).getUtility() + bu + subHtb.get(itemindex).getCount()); // node utility
			
//			System.out.println(itemindex+" add // "+(pathSU.get(i)+bu+subHtb.get(itemindex).getCount()));
		}
		for (; i < size; i++) {
			if (path.get(i).getUtility() == 0)
				break;
			utility.add(path.get(i).getUtility());
//			su=su+path.get(i).getUtility();
			HuiTreeNode initem = new HuiTreeNode();
			itemindex = path.get(i).getIndex();
			initem.setItemIndex(itemindex);
			initem.setParent(tmp);
			tmp = initem;
			subnode = subHtb.get(itemindex);
			if (subnode != null) {
				subnode.getLink().add(initem);// add link
				subnode.setTwu(pathSU.get(i) + bu + subHtb.get(itemindex).getTwu()); // rTwuk
				subnode.setCount(path.get(i).getUtility() + bu + subHtb.get(itemindex).getCount()); // node utility
//				System.out.println(itemindex+" add// "+(pathSU.get(i)+bu+subHtb.get(itemindex).getCount()));
			}
		}
		if (i == 0)
			return;

		// ����tail info.
		if (tmp.getInfo() != null) {
			tmp.getInfo().setBu(tmp.getInfo().getBu() + bu);
//			tmp.getInfo().setCount(tmp.getInfo().getCount()+count);
//			tmp.getInfo().setSu(tmp.getInfo().getSu()+su);
			tmp.getInfo().addPathUtility(utility);
			tmp.getInfo().addPathSU(pathSU);
//			System.out.println("have same node, tmp.getInfo()......"+tmp.getInfo().getCount());
		} else {
//			tmp.setInfo(new HuiTreeNodeInfo(count,bu,su,utility));
//			System.out.println(pathSU.size()+"//"+size);
			tmp.setInfo(new HuiTreeNodeInfo(bu, utility, pathSU, i)); // i �������񳤶�
//			System.out.println("tmp.getInfo()......"+tmp.getInfo().getCount());
		}
	}

	public void addInstance2(Vector<PathNode> path, TreeBidiMap<Integer, HeaderCount> subHtb, HuiTreeNodeInfo hni,
			Vector<Integer> pathSU) {
		// HuiTreeNodeInfo tailInfo = new HuiTreeNodeInfo();
		// float su = 0.0f;
		//
		HuiTreeNode tmp = this.root;
		Vector<Integer> utility = new Vector<Integer>();
//		Vector<Integer> pathSU = new Vector<Integer>();
		int i = 0;
		int size = pathSU.size();
		int j = 0;
//		int childsize;
//		Vector<HuiTreeNode> cv;
		int bu = hni.getBu();
//		int rtwu = 0;
//		int count = hni.getCount();
		int itemindex;
		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
		Vector<HuiTreeNode> ch = tmp.getChildren();
		HeaderCount subnode;
		for (i = 0; i < size; i++) { // path������root
//             int itemindex = path.get(i).getIndex();
			itemindex = path.get(i).getIndex();
			if (path.get(i).getUtility() == 0)
				break;
			int chsize = ch.size();
			for (j = 0; j < chsize; j++) {
				if (itemindex == ch.get(j).getItemIndex())
					break;
			}
			if (j == chsize)
				break;
			else {
				tmp = ch.get(j);
				ch = tmp.getChildren();
			}
			utility.add(path.get(i).getUtility());
//			r=su+path.get(i).getUtility();
			subnode = subHtb.get(itemindex);
			subnode.setTwu(pathSU.get(i) + bu + subHtb.get(itemindex).getTwu()); // rTwuk
			subnode.setCount(path.get(i).getUtility() + bu + subHtb.get(itemindex).getCount()); // node utility
			
//			System.out.println(itemindex+" add // "+(pathSU.get(i)+bu+subHtb.get(itemindex).getCount()));
		}
		for (; i < size; i++) {
			if (path.get(i).getUtility() == 0)
				break;
			utility.add(path.get(i).getUtility());
//			su=su+path.get(i).getUtility();
			HuiTreeNode initem = new HuiTreeNode();
			itemindex = path.get(i).getIndex();
			initem.setItemIndex(itemindex);
			initem.setParent(tmp);
			tmp = initem;
			subnode = subHtb.get(itemindex);
			if (subnode != null) {
				subnode.getLink().add(initem);// add link
				subnode.setTwu(pathSU.get(i) + bu + subHtb.get(itemindex).getTwu()); // rTwuk
				subnode.setCount(path.get(i).getUtility() + bu + subHtb.get(itemindex).getCount()); // node utility
//				System.out.println(itemindex+" add// "+(pathSU.get(i)+bu+subHtb.get(itemindex).getCount()));
			}
		}
		if (i == 0)
			return;

		// ����tail info.
		if (tmp.getInfo() != null) {
			tmp.getInfo().setBu(tmp.getInfo().getBu() + bu);
//			tmp.getInfo().setCount(tmp.getInfo().getCount()+count);
//			tmp.getInfo().setSu(tmp.getInfo().getSu()+su);
			tmp.getInfo().addPathUtility(utility);
			tmp.getInfo().addPathSU(pathSU);
//			System.out.println("have same node, tmp.getInfo()......"+tmp.getInfo().getCount());
		} else {
//			tmp.setInfo(new HuiTreeNodeInfo(count,bu,su,utility));
//			System.out.println(pathSU.size()+"//"+size);
			tmp.setInfo(new HuiTreeNodeInfo(bu, utility, pathSU, i)); // i �������񳤶�
//			System.out.println("tmp.getInfo()......"+tmp.getInfo().getCount());
		}
	}

//	public void addInstance(Vector<PathNode> path, TreeBidiMap<Integer, HeaderCount> subHtb, HuiTreeNodeInfo hni,
//			int len) {
//		// HuiTreeNodeInfo tailInfo = new HuiTreeNodeInfo();
//		// float su = 0.0f;
//		//
//		HuiTreeNode tmp = this.root;
//		Vector<Integer> utility = new Vector<Integer>();
//		Vector<Integer> pathSU = new Vector<Integer>();
//		int i = 0;
//		int size = path.size();
//		int j = 0;
//		int childsize;
//		Vector<HuiTreeNode> cv;
//		int bu = hni.getBu();
//		int su = 0;
//		int count = hni.getCount();
//		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
//		Vector<HuiTreeNode> ch = tmp.getChildren();
//		for (i = 0; i < size; i++) { // path������root
////             int itemindex = path.get(i).getIndex();
//			if (path.get(i).getUtility() < 0.0001)
//				break;
//			int chsize = ch.size();
//			for (j = 0; j < chsize; j++) {
//				if (path.get(i).getIndex() == ch.get(j).getItemIndex())
//					break;
//			}
//			if (j == chsize)
//				break;
//			else {
//				tmp = ch.get(j);
//				ch = tmp.getChildren();
//			}
//			utility.add(path.get(i).getUtility());
//			su = su + path.get(i).getUtility();
//
//		}
//		for (; i < size; i++) {
//			if (path.get(i).getUtility() < 0.0001)
//				break;
//			utility.add(path.get(i).getUtility());
//			su = su + path.get(i).getUtility();
//			HuiTreeNode initem = new HuiTreeNode();
//			int itemindex = path.get(i).getIndex();
//			initem.setItemIndex(itemindex);
//			initem.setParent(tmp);
//			tmp = initem;
//			if (subHtb.get(itemindex) != null) {
//				subHtb.get(itemindex).getLink().add(initem);
//			} // add link
//		}
//		if (i == 0)
//			return;
//
//		// ����tail info.
//		if (tmp.getInfo() != null) {
//			tmp.getInfo().setBu(tmp.getInfo().getBu() + bu);
//			tmp.getInfo().setCount(tmp.getInfo().getCount() + count);
//			tmp.getInfo().setSu(tmp.getInfo().getSu() + su);
//			tmp.getInfo().addPathUtility(utility);
////			System.out.println("have same node, tmp.getInfo()......"+tmp.getInfo().getCount());
//		} else {
//			tmp.setInfo(new HuiTreeNodeInfo(count, bu, su, utility));
////			System.out.println("tmp.getInfo()......"+tmp.getInfo().getCount());
//		}
//	}

//	//	���������ӵ�����
//	public void addInstance(Vector<PathNode> path,
//			TreeBidiMap<Integer, HeaderCount> header ) {
//		
//		
//		HuiTreeNode tmp = this.root;
//		Vector<Float> utility = new Vector<Float>();
//		int i = 0;
//		int size = path.size();
//		int j = 0;
//		int childsize;
//		Vector<HuiTreeNode> cv;
//		float bu =0.0f;
//		float su = 0.0f;
//		int count = 1;
//		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
//		Vector<HuiTreeNode> ch = tmp.getChildren();
//		for (i = 0; i < size; i++) { // path������root
//			if (path.get(i).getUtility() < 0.0001)
//				break;
//			int chsize = ch.size();
//			for (j = 0; j < chsize; j++) {
//				if (path.get(i).getIndex() == ch.get(j)
//						.getItemIndex())
//					break;
//			}
//			if (j == chsize)
//				break;
//			else {
//				tmp = ch.get(j);
//				ch = tmp.getChildren();
//			}
//			float ut =path.get(i).getUtility();
//			utility.add(ut);
//			su=su+ut;
//
//		}
//		for (; i < size; i++) {
//			if (path.get(i).getUtility() < 0.0001)
//				break;
//			int itemindex =path.get(i).getIndex();
//			float ut =path.get(i).getUtility();
//			utility.add(ut);
//			su=su+ut;
//			HuiTreeNode initem = new HuiTreeNode();
//			initem.setItemIndex(itemindex);
//			initem.setParent(tmp);
//			tmp = initem;
//			if(header.get(itemindex)!=null)
//			header.get(itemindex).getLink().add(initem);
//		}
//		if(i==0) return;
//		
//		// ����tail info.
//		if(tmp.getInfo()!=null)
//		{
//			tmp.getInfo().setBu(tmp.getInfo().getBu()+bu);
//			tmp.getInfo().setCount(tmp.getInfo().getCount()+count);
//			tmp.getInfo().setSu(tmp.getInfo().getSu()+su);
//			tmp.getInfo().addPathUtility(utility);
////			System.out.println("have one more times!!!!!!!!!!!!!!!");
//		}
//		else
//		{
//				tmp.setInfo(new HuiTreeNodeInfo(count,bu,su,utility));
//		}	
//		// TODO Auto-generated method stub
//		
//		
//		// TODO Auto-generated method stub
//		
//	}
//
//	public void addInstance(Vector<PathNode> path, TreeBidiMap<Integer, HeaderCount> header, int maxlen) {
//
//		HuiTreeNode tmp = this.root;
//		Vector<Float> utility = new Vector<Float>();
//		int i = 0;
//		int size = path.size();
//		int j = 0;
//		int childsize;
//		Vector<HuiTreeNode> cv;
//		float bu = 0.0f;
//		float su = 0.0f;
//		int count = 1;
//		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
//		Vector<HuiTreeNode> ch = tmp.getChildren();
//		for (i = 0; i < size; i++) { // path������root
//			if (path.get(i).getUtility() < 0.0001)
//				break;
//			int chsize = ch.size();
//			for (j = 0; j < chsize; j++) {
//				if (path.get(i).getIndex() == ch.get(j).getItemIndex())
//					break;
//			}
//			if (j == chsize)
//				break;
//			else {
//				tmp = ch.get(j);
//				ch = tmp.getChildren();
//			}
//			float ut = path.get(i).getUtility();
//			utility.add(ut);
//			su = su + ut;
//
//		}
//		for (; i < size; i++) {
//			if (path.get(i).getUtility() < 0.0001)
//				break;
//			int itemindex = path.get(i).getIndex();
//			float ut = path.get(i).getUtility();
//			utility.add(ut);
//			su = su + ut;
//			HuiTreeNode initem = new HuiTreeNode();
//			initem.setItemIndex(itemindex);
//			initem.setParent(tmp);
//			tmp = initem;
//			if (header.get(itemindex) != null)
//				header.get(itemindex).getLink().add(initem);
//		}
//		if (i == 0)
//			return;
//
//		if (utility.size() > maxlen) // ���񳤶�С��maxlen,����Ҫ������;���ڵĻ������¼���suֵ
//		{
//			float[] arr = new float[maxlen];
//			arr[0] = utility.get(0);
//			int minInd = 0;
//			for (i = 1; i < maxlen; i++) {
//				arr[i] = utility.get(i);
//				if (arr[i] < arr[minInd]) {
//					minInd = i;
//				}
//			}
//			for (; i < utility.size(); i++) {
//				if (utility.get(i) > arr[minInd]) {
//					arr[minInd] = utility.get(i);
//					minInd = FindMiniValueInd(arr);
//				}
//			}
//			su = 0.0f;
//			for (i = 0; i < maxlen; i++)
//				su = su + arr[i];
//		}
//
//		// ����tail info.
//		if (tmp.getInfo() != null) {
//			tmp.getInfo().setBu(tmp.getInfo().getBu() + bu);
//			tmp.getInfo().setCount(tmp.getInfo().getCount() + count);
//			tmp.getInfo().setSu(tmp.getInfo().getSu() + su);
//			tmp.getInfo().addPathUtility(utility);
////			System.out.println("have one more times!!!!!!!!!!!!!!!");
//		} else {
//			tmp.setInfo(new HuiTreeNodeInfo(count, bu, su, utility));
//		}
//		// TODO Auto-generated method stub
//
//		// TODO Auto-generated method stub
//
//	}
//	private int FindMiniValueInd(float[] arr) {
//		int min = 0;
//		for (int i = 1; i < arr.length; i++) {
//			if (arr[i] < arr[min])
//				min = i;
//		}
//		return min;
//	}

//	public void addInstance(Vector<PathNode> path,
//			Vector<HuiHeadTbValue> itemValue, HuiTreeNodeInfo hni) {
//		HuiTreeNode tmp = this.root;
//		Vector<Float> utility = new Vector<Float>();
//		int i = 0;
//		int size = path.size();
//		int j = 0;
//		int childsize;
//		Vector<HuiTreeNode> cv;
//		float bu = hni.getBu();
//		float su = 0.0f;
//		int count = hni.getCount();
//		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
//		Vector<HuiTreeNode> ch = tmp.getChildren();
//		for (i = size -1 ; i >=0; i--) { // path������root
//
//			if (path.get(i).getUtility() < 0.0001)
//				break;
//			int chsize = ch.size();
//			for (j = 0; j < chsize; j++) {
//				if (path.get(i).getNode().getItemIndex() == ch.get(j)
//						.getItemIndex())
//					break;
//			}
//			if (j == chsize)
//				break;
//			else {
//				tmp = ch.get(j);
//				ch = tmp.getChildren();
//			}
//			utility.add(path.get(i).getUtility());
//			System.out.println(i+"there is "+utility.get(utility.size()-1));
//			su=su+path.get(i).getUtility();
//
//		}
//			for (; i >=0; i--) {
//			if (path.get(i).getUtility() < 0.0001)
//				break;
//			HuiTreeNode initem = new HuiTreeNode();
//			initem.setItemIndex(path.get(i).getNode().getItemIndex());
//			initem.setParent(tmp);
//			tmp = initem;
//			itemValue.get(path.get(i).getNode().getItemIndex()).getLink().add(initem);
////			subHtb.get(path.get(i).getNode().getItemIndex()).getLink().add(initem);//add link
//			utility.add(path.get(i).getUtility());
//			System.out.println(i+"there is nnt"+utility.get(utility.size()-1));
//			su=su+path.get(i).getUtility();
//
//		}
//		if(i==size -1) return;
//		
//		HuiTreeNodeInfo htni = new HuiTreeNodeInfo();
//
//		htni.setBu(bu);
//		htni.setCount(count);
//		htni.setSu(su);
//		htni.addPathUtility(utility);
//
//
//		// ����tail info.
//		if(tmp.getInfo()!=null)
//		{
//			tmp.getInfo().setBu(tmp.getInfo().getBu()+htni.getBu() );
//			tmp.getInfo().setCount(tmp.getInfo().getCount()+htni.getCount() );
//			tmp.getInfo().setSu(tmp.getInfo().getSu()+htni.getSu());
//			tmp.getInfo().addPathUtility(utility);
//		}
//		else
//		{
//			tmp.setInfo(htni);
//		}	

	// TODO Auto-generated method stub

//	}
}
