package ctl.HuiLen.util;

import java.util.Vector;

public class HUItemset {
	private Vector<String> name = new Vector<String>();
	private long utility;
	
	public HUItemset(Vector<String>  clone, long float1) {
		this.utility=float1;
		for(int m=0;m<clone.size();m++)
		{
			this.name.add(clone.get(m));
		}
		// TODO Auto-generated constructor stub
	}

	public void HUItemset() {
		name= new Vector<String>();
		utility=0;
	}

	public Vector<String> getName() {
		return name;
	}
	public void setName(Vector<String> name) {
		this.name = name;
	}
	public long getUtility() {
		return utility;
	}
	public void setUtility(long utility) {
		this.utility = utility;
	}
	public void addname(String itemname) {
		this.name.add(itemname);
	}
}
