package ctl.HuiLen.util;

public class SimpleItem {
	
	private String name;
	private int index;
	
	
	public SimpleItem(){
		;
	}
	
	public SimpleItem(String name,int index){
		this.index = index;
		this.name= name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	
	public void print(){
		System.out.print(""+index+"-"+name);
	}
	
}
