package ctl.HuiLen.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Vector;

public class DataUpdate {

	private String path;
	public DataUpdate(String path){
		this.path = path;
	}
	
	public void reconstruct() {
		File file = new File(path);
		File fout = new File("c.txt");
		BufferedWriter writer = null;
		BufferedReader reader = null;
		java.util.Random r = new java.util.Random(258);
		try {
			reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(file), "UTF-8"));
			String tempString = null;
			
			writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fout)));
			
			String line = null;
			// һ�ζ���һ�У�ֱ������nullΪ�ļ�����
			while ((tempString = reader.readLine()) != null) {
				// ��ʾ�к�
				// System.out.println("line " + line + ": " + tempString);
				tempString.trim();
				if (tempString.equals(""))
					continue;
				String[] ss = tempString.split(" ");
				int length = ss.length;
				line = ss[0];
				line += (" " +(r.nextInt(10)+1));
				for (int i = 1; i < length; i++) {
					line += (" "+ss[i].trim());
					line += (" " +(r.nextInt(10)+1));
				}
				writer.write(line);
				writer.newLine();
			}
			reader.close();
			writer.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e1) {
				}
			}
		}
	}
	
	
	public static void main(String arg[]){
		DataUpdate du = new DataUpdate("C:\\1.txt");
		du.reconstruct();
	}
}
