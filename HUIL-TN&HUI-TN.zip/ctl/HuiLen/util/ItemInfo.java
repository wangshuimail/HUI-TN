package ctl.HuiLen.util;

public class ItemInfo extends SimpleItem{
	
	private float utility;
	private int num;
	private int order;

	public ItemInfo() {
		;
	}

	public ItemInfo(String name, int index, int num, float utility) {
		super(name, index);
		this.num = num;
		this.utility = utility;
	}


	public float getUtility() {
		return utility;
	}

	public void setUtility(float utility) {
		this.utility = utility;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}
	
	
	
	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public void print(){
		System.out.println("index:"+getIndex()+",name:"+getName()+",utility:"+utility);
	}

}
