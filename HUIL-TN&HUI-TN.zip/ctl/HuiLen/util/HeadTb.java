package ctl.HuiLen.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Vector;
import java.util.Map.Entry;

import java.util.Iterator;

public class HeadTb {

	// Transactions in tree.
	private Vector<Vector<TreeNode>> links;

	// <key, value> <Item, <index,Utility,SupCount>>
	private Map<String, AbstractItemValue> itemtb;

	public HeadTb() {
		links = new Vector<Vector<TreeNode>>();
		itemtb = new TreeMap<String, AbstractItemValue>();
	}

	//
	public boolean add(String name, int index) {
		if (itemtb.containsKey(name))
			return false;

		AbstractItemValue value = new AbstractItemValue();
		value.setIndex(index);
		itemtb.put(name, value);
		return true;
	}

	public boolean add(String name, int index, float utility) {
		if (itemtb.containsKey(name))
			return false;

		AbstractItemValue value = new AbstractItemValue();
		value.setIndex(index);
		value.setUtility(utility);

		itemtb.put(name, value);
		return true;
	}

	public boolean add(String name, int index, float utility, int supnum) {
		if (itemtb.containsKey(name))
			return false;

		AbstractItemValue value = new AbstractItemValue();
		value.setIndex(index);
		value.setSupnum(supnum);
		value.setUtility(utility);

		itemtb.put(name, value);
		return true;
	}

	public AbstractItemValue getValue(String key) {
		return itemtb.get(key);
	}

	public boolean setValue(String key, AbstractItemValue value) {

		if (itemtb.containsKey(key)) {

			itemtb.put(key, value);
			return true;
		}
		return false;
	}

	public Vector<TreeNode> getLinks(int index) {
		return links.get(index);
	}

	public Map<String, AbstractItemValue> getItemtb() {
		return itemtb;
	}

	public void addLink(int index, TreeNode nod) {
		
		for (int i=links.size();i<=index;i++){
			links.add(i, new Vector<TreeNode>());
		}
		
		Vector<TreeNode> tmp = links.get(index);
		tmp.add(nod);
		links.set(index, tmp);
	}

	public void initLinks(int index) {
		links.add(new Vector<TreeNode>());
	}

	// bigest.bigger.big.small.smaller.smallest...
	public List<Entry<String, AbstractItemValue>> getSortedByUtility() {
		List<Map.Entry<String, AbstractItemValue>> info = new ArrayList<Map.Entry<String, AbstractItemValue>>(
				itemtb.entrySet());
		Collections.sort(info,
				new Comparator<Map.Entry<String, AbstractItemValue>>() {

					@Override
					public int compare(Entry<String, AbstractItemValue> o1,
							Entry<String, AbstractItemValue> o2) {
						// TODO Auto-generated method stub
						float dis = o2.getValue().getUtility() - o1.getValue().getUtility();
						
						if (dis > 0.00)
							return 1;
						else if (dis == 0.00)
							return 0;
						else 
							return -1;
					}

				});
		return info;
	}


	public void print() {
		Iterator it = itemtb.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry ent = (Map.Entry) it.next();

			String name = ent.getKey().toString();
			AbstractItemValue value = (AbstractItemValue) ent.getValue();
			System.out.println("index:" + value.getIndex() +", name:"+ name + "-" + value.getUtility());
		}
	}
}
