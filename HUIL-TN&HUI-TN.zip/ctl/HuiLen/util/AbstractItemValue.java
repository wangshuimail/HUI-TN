package ctl.HuiLen.util;

//ͷ����Map�е�value��װ��

public class AbstractItemValue {
	int index;
	float utility;
	int supnum;
	
	public AbstractItemValue(){
		
	}
	
	public AbstractItemValue(int index, float utility, int supnum){
		this.index = index;
		this.utility = utility;
		this.supnum = supnum;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public float getUtility() {
		return utility;
	}

	public void setUtility(float utility) {
		this.utility = utility;
	}

	public int getSupnum() {
		return supnum;
	}

	public void setSupnum(int supnum) {
		this.supnum = supnum;
	}
	
	
}
