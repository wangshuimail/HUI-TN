package ctl.HuiLen.util;

import java.util.Vector;

public class HuiHeadTbValueHash {
 
	private int twu;
	private int su;
	private int bu;
	private int count;
	private Vector<HuiTreeNodeHash> link; 

	public HuiHeadTbValueHash() {
		// TODO Auto-generated constructor stub
		this.twu = 0;
		this.count = 0;
		this.su = 0;
		this.bu =0;
		this.link = new Vector<HuiTreeNodeHash>();
	}

	public HuiHeadTbValueHash(HuiHeadTbValueHash ht) {
		this.twu = ht.twu;
		this.count=ht.count;
		this.link = new Vector<HuiTreeNodeHash>(ht.link);
		// TODO Auto-generated constructor stub
	}

	public HuiHeadTbValueHash(HuiHeadTbValueHash ht, int i) {
		this.twu = ht.twu;
		this.count=ht.count;
		this.link = new Vector<HuiTreeNodeHash>();
		// TODO Auto-generated constructor stub
	}

	public HuiHeadTbValueHash( int tu,int count2) {
		this.twu=tu;
		this.count=count2;
		this.link = new Vector<HuiTreeNodeHash>();
		// TODO Auto-generated constructor stub
	}
	public HuiHeadTbValueHash( int tu,int count2,HuiTreeNodeHash node) {
		this.twu=tu;
		this.count=count2;
		this.link = new Vector<HuiTreeNodeHash>();
		this.link.add(node);
		// TODO Auto-generated constructor stub
	}

	public int getTwu() {
		return twu;
	}

	public void setTwu(int twu1) {
		this.twu = twu1;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count1) {
		this.count = count1;
	}

	public Vector<HuiTreeNodeHash> getLink() {
		return link;
	}
	
	public void addLink(HuiTreeNodeHash nod){
		this.link.add(nod);
	}
	

}
