package ctl.HuiLen.util;

import java.util.*;

public class HuiTreeNodeInfo {
	
	private Vector<Integer> pathUtility;
	private Vector<Integer> pathSU; //·����ÿ���su,Ӧ����rtwu
	
	public Vector<Integer> getPathSU() {
		return pathSU;
	}

	public void setPathSU(Vector<Integer> pathSU) {
		this.pathSU = pathSU;
	}

	public void setPathUtility(Vector<Integer> pathUtility) {
		this.pathUtility = pathUtility;
	}

//	private int count;
	private int bu; //�����utility�ĺ�
	private int su;//utility�ĺ�
	
	private int infoInd; // info��index, Ĭ����0���ñ�����רΪһ�����õ�
	
	public HuiTreeNodeInfo() {
//		count = 0;
		bu = 0;
//		su = 0;
		pathUtility = new Vector<Integer>(); 
	}

	public HuiTreeNodeInfo(HuiTreeNodeInfo info) {
//		count = info.count;
		bu=info.bu;
//		su=info.su;
		pathUtility= new Vector<Integer>(info.pathUtility);
		// TODO Auto-generated constructor stub
	}

//	public HuiTreeNodeInfo(int count2, int bu2, int su2,
//			Vector<Integer> utility) {
//		count = count2;
//		bu=bu2;
//		su=su2;
//		pathUtility= new Vector<Integer>(utility);
//		// TODO Auto-generated constructor stub
//	}

//	public HuiTreeNodeInfo(int count2, int bu2, int su2, Vector<Integer> utility, Vector<Integer> tempUtilities) {
//		// TODO Auto-generated constructor stub
//
//		count = count2;
//		bu = bu2;
//		su = su2;
//		pathUtility = new Vector<Integer>(utility);
//		pathSU = tempUtilities;
//
//	}

	public HuiTreeNodeInfo( int bu2,  Vector<Integer> utility, int[] tempUtilities, int size) {
		// TODO Auto-generated constructor stub

//		count = count2;
		bu = bu2;
//		su = su2;
		pathUtility = new Vector<Integer>(utility);
		pathSU = new Vector<Integer>();
		for (int i = 0; i < size; i++)
			pathSU.add(tempUtilities[i]);
	}
	public HuiTreeNodeInfo( int bu2,  Vector<Integer> utility, Vector<Integer> tempUtilities, int size) {
		// TODO Auto-generated constructor stub

//		count = count2;
		bu = bu2;
//		su = su2;
		pathUtility = new Vector<Integer>();
		pathSU = new Vector<Integer>();
		for (int i = 0; i < size; i++) {
			pathSU.add(tempUtilities.get(i));
			pathUtility.add(utility.get(i));
		}
	}

//	public HuiTreeNodeInfo(int bu2, Vector<Integer> utility) {
//		// TODO Auto-generated constructor stub
//
////		count = count2;
//		bu = bu2;
////		su = su2;
//		pathUtility = new Vector<Integer>(utility);
////		pathSU = new Vector<Integer>();
////		for (int i = 0; i < size; i++)
////			pathSU.add(tempUtilities[i]);
//	}

	//for no length constraint,just have bu and utility list of path item
	public HuiTreeNodeInfo( int bu2, Vector<Integer> utility) {
		// TODO Auto-generated constructor stub

//		count = count2;
		bu = bu2;
//		su = su2;
		pathUtility = new Vector<Integer>(utility);
//		pathSU = new Vector<Integer>();
//		for (int i = 0; i < size; i++)
//			pathSU.add(tempUtilities[i]);
	}
	
//	public int getCount() {
//		return count;
//	}
//
//	public void setCount(int count) {
//		this.count = count;
//	}

	public int getBu() {
		return bu;
	}

	public void setBu(int bu) {
		this.bu = bu;
	}

	public int getSu() {
		return su;
	}

	public void setSu(int su) {
		this.su = su;
	}

	public Vector<Integer> getPathUtility() {
		return pathUtility;
	}
	
	public void addUtility(int u){
		this.pathUtility.add(u);
	}
	
	public void addPathSU(int[] pu, int len) {

//		int size = pu.size();
//		if (size != pu.size())
//			return;
//		
		for (int i = 0; i < len; i++) {
			if (pathSU.size() < i + 1)
				pathSU.add(pu[i]);
			else
				pathSU.set(i, pathSU.get(i) + pu[i]);
		}
	}
	
	public void addPathSU(Vector<Integer> pu, int len) {

//		int size = pu.size();
//		if (size != pu.size())
//			return;
//		
		for (int i = 0; i < len; i++) {
			if (pathSU.size() < i + 1)
				pathSU.add(pu.get(i));
			else
				pathSU.set(i, pathSU.get(i) + pu.get(i));
		}
	}
	
	public void addPathUtility(Vector<Integer> pu){
		
		int size = pu.size();
//		if (size != pu.size())
//			return;
//		
		for (int i=0; i<size; i++){
			if(pathUtility.size()<i+1) 
				pathUtility.add(0);
			pathUtility.set(i, pathUtility.get(i) + pu.get(i));
		}
	}

	public void addPathUtility(Vector<Integer> pu,int size){
		
//		int size = pu.size();
//		if (size != pu.size())
//			return;
//		
		for (int i=0; i<size; i++){
			if(pathUtility.size()<i+1) 
				pathUtility.add(0);
			pathUtility.set(i, pathUtility.get(i) + pu.get(i));
		}
	}

	public void addPathSU(Vector<Integer> pu) {

		int size = pu.size();
//		if (size != pu.size())
//			return;
//		
		for (int i = 0; i < size; i++) {
			if (pathSU.size() < i + 1)
				pathSU.add(pu.get(i));
			else
				pathSU.set(i, pathSU.get(i) + pu.get(i));
		}
	}

}