package ctl.HuiLen.util;

import java.util.*;

public class Tree {

	private TreeNode root;

	public Tree() {
		root = new TreeNode(null);
	}

	
	//�ۼ�ЧӦ
	public Vector<TreeNode> addInstanceByAcmu(Vector<ItemInfo> instance) {
		TreeNode tem = root;
		int i = 0;
		int size = instance.size();
		int j = 0;
		int childsize;
		Vector<TreeNode> cv;
		Vector<TreeNode> nv = new Vector<TreeNode>();
		float tu = 0.0f;

		
			for (i = 0; i < size; i++) {

			cv = tem.getChildren();
			childsize = cv.size();

			for (j = 0; j < childsize; j++) {
				if (instance.get(i).getIndex() == cv.get(j).getInfo().getIndex())
					break;
			}

			if (j < childsize) {
				// find.
				ItemInfo item = instance.get(i);
				tu += item.getUtility();
				tem = cv.get(j);
				AbstractItemValue info = tem.getInfo();
				// utility.
				info.setUtility(info.getUtility()+tu);
				// sup num.
				info.setSupnum(info.getSupnum()+item.getNum());
//				System.out.println(i+" old node:  "+item.getName()+":"+info.getUtility()+":"+info.getSupnum());
			} else
				break;
		}
		// δ�ҵ���Ӧ�ӽڵ�
		for (; i < size; i++) {

			tu += instance.get(i).getUtility();
			ItemInfo item = instance.get(i);
			
			AbstractItemValue info = new AbstractItemValue(item.getIndex(),tu, item.getNum());

			TreeNode n = new TreeNode(item.getName(), tem);
			n.setInfo(info);
			nv.add(n);
			
			tem = n;
//			System.out.println(i+" new node:  "+item.getName()+":"+info.getUtility()+":"+info.getSupnum());
		}
		return nv;
	}

	
	// ���������ӽڵ㼯��
	public Vector<TreeNode> addInstance(Vector<ItemInfo> instance) {
		TreeNode tem = root;
		int i = 0;
		int size = instance.size();
		int j = 0;
		int childsize;
		Vector<TreeNode> cv;
		Vector<TreeNode> nv = new Vector<TreeNode>();

		for (i = 0; i < size; i++) {

			cv = tem.getChildren();
			childsize = cv.size();

			for (j = 0; j < childsize; j++) {
				if (instance.get(i).getIndex() == cv.get(j).getInfo().getIndex())
					break;
			}

			if (j < childsize) {
				// find.
				ItemInfo item = instance.get(i);
				
				tem = cv.get(j);
				AbstractItemValue info = tem.getInfo();
				// utility.
				info.setUtility(info.getUtility()+item.getUtility());
				// sup num.
				info.setSupnum(info.getSupnum()+item.getNum());
			} else
				break;
		}
		
		// δ�ҵ���Ӧ�ӽڵ�
		for (; i < size; i++) {

			ItemInfo item = instance.get(i);
			
			AbstractItemValue info = new AbstractItemValue(item.getIndex(),item.getUtility(),item.getNum());
			
			TreeNode n = new TreeNode(item.getName(), tem);
			n.setInfo(info);

			nv.add(n);
			tem = n;
		}
		return nv;
	}


	public int nodCount(TreeNode nod) {

		if (nod == null)
			nod = this.root;

		int num = 0;
		Iterator it = nod.getChildren().iterator();
		while (it.hasNext()) {
			num += nodCount((TreeNode) it.next());
		}

		num++;
		return num;
	}
	
	
}
