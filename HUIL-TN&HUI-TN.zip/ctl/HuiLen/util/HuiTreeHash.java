//\\���ӽڵ���Hash
package ctl.HuiLen.util;

import java.util.*;

import javax.sound.midi.MidiDevice.Info;

import org.apache.commons.collections15.bidimap.TreeBidiMap;

import ctl.HuiLen.Transaction;
import ctl.HuiLen.*;



public class HuiTreeHash {
	private HuiTreeNodeHash root;

	public HuiTreeNodeHash getRoot() {
		return root;
	}

	public void setRoot(HuiTreeNodeHash root) {
		this.root = root;
	}

	public HuiTreeHash() {
		root = new HuiTreeNodeHash(null);
	}

	// get all the tail node and the each distances between it and the ancestor
	// in the ancestor's sub-tree.
	public void getSubTails(HuiTreeNodeHash ancestor, Vector<HuiTreeNodeHash> tails, Vector<Integer> diss, int dis) {

//		if (ancestor.getInfo() != null) {
//			tails.add(ancestor);
//			diss.add(dis);
//		}
//		dis++;
//
//		HashMap <Integer,HuiTreeNodeHash> cv = ancestor.getChildren();
//		int size = cv.size();
//		if (size == 0)
//			return;
//		else {
//			Iterator it = cv.iterator();
//			while (it.hasNext()) {
//				getSubTails((HuiTreeNodeHash) it.next(), tails, diss, dis);
//
//			}
//		}
	}

	// get the path from nod to root.
	public Vector<HuiTreeNodeHash> getPath(HuiTreeNodeHash nod) {
		Vector<HuiTreeNodeHash> path = new Vector<HuiTreeNodeHash>();

		HuiTreeNodeHash tem = nod;
		while (!tem.isRoot()) {
			path.add(tem);
			tem = tem.getParent();
		}
		return path;
	}

	public int nodCount(HuiTreeNodeHash nod) {

		int num = 0;

//		if (nod == null)
//			nod = this.root;
//
//		Iterator it = nod.getChildren().iterator();
//		while (it.hasNext()) {
//			num += nodCount((HuiTreeNodeHash) it.next());
//		}
//		num++;
		
		return num;
	}

	public Vector<HuiTreeNodeHash> getPathCopy(HuiTreeNodeHash nod) {
		Vector<HuiTreeNodeHash> path = new Vector<HuiTreeNodeHash>();

		HuiTreeNodeHash tem = nod;
		while (!tem.isRoot()) {
			HuiTreeNodeHash newNode = new HuiTreeNodeHash(tem.getItemIndex());
			path.add(newNode);
			tem = tem.getParent();
		}
		return path;

		// TODO Auto-generated method stub
	}

	
//	public Vector<PathNode> getPath(HuiTreeNodeHash nod, TreeMap<Integer, HuiHeadTbValueHash> subHtb) {
//		Vector<PathNode> path = new Vector<PathNode>();
//
//		HuiTreeNodeHash tem = nod;
//		HuiTreeNodeInfo NodeInf = nod.getInfo();
//		if(NodeInf==null) {
//			System.out.println("errrr.......................");
//		}
//		Vector<Integer> utility = NodeInf.getPathUtility();
////		int count=NodeInf.getCount();
//		int tu = NodeInf.getPathSU().get(NodeInf.getPathSU().size() - 1) + nod.getInfo().getBu();
//		if (tem.isRoot())
//			return null;
//		tem = tem.getParent();
//		int i = 2;
//		int len = utility.size();
//		while (!tem.isRoot()) {
//			int itemindex = tem.getItemIndex();
////			PathNode pn =new PathNode(itemindex,utility.get(len-i));
////			pn.setNode(tem);
////			pn.setIndex(itemindex);
////			pn.setUtility(utility.get(len-i));
//			path.add(new PathNode(itemindex, utility.get(len - i)));
//			i++;
//
////			subTreeSu[itemindex] +=tu;
//
//			HuiHeadTbValue htbv = subHtb.get(itemindex);
//			if (htbv != null) {
////				htbv.setCount(htbv.getCount() + count);
//				htbv.setTwu(htbv.getTwu() + tu);
//			} else {
//				subHtb.put(new Integer(itemindex), new HuiHeadTbValue(tu, 0));
//			}
//			tem = tem.getParent();
//		}
//
//		return path;
//
//		// TODO Auto-generated method stub
//	}

	public Vector<PathNode> getPath(HuiTreeNodeHash nod, TreeMap<Integer, HuiHeadTbValueHash> subHtb,int mlen) {
		Vector<PathNode> path = new Vector<PathNode>();

		HuiTreeNodeHash tem = nod;
		HuiTreeNodeInfo NodeInf = nod.getInfo();
		if(NodeInf==null) {
			System.out.println("errrr.......................");
		}
		Vector<Integer> utility = NodeInf.getPathUtility();
//		int count=NodeInf.getCount();
		int tu = NodeInf.getPathSU().get(NodeInf.getPathSU().size() - 1) + nod.getInfo().getBu();
		if (tem.isRoot())
			return null;
		tem = tem.getParent();
		int i = 2;
		int len = utility.size();
		while (!tem.isRoot()) {
			int itemindex = tem.getItemIndex();
//			PathNode pn =new PathNode(itemindex,utility.get(len-i));
//			pn.setNode(tem);
//			pn.setIndex(itemindex);
//			pn.setUtility(utility.get(len-i));
			path.add(new PathNode(itemindex, utility.get(len - i)));
//			i++;

//			subTreeSu[itemindex] +=tu;

			HuiHeadTbValueHash htbv = subHtb.get(itemindex);
			if (htbv != null) {
				htbv.setCount(htbv.getCount() + nod.getInfo().getBu()+utility.get(len - i)); //���Ч��ֵ
				
//				count ��¼ʲô�� ��¼�������ǰ׺����utility
//				����һ���ڵ�����¼rtwu (��RMU)
				
				htbv.setTwu(htbv.getTwu() + tu);
				htbv.getLink().add(nod);
			} else {
				subHtb.put(new Integer(itemindex), new HuiHeadTbValueHash(tu, 0,nod));
			}
			tem = tem.getParent();
			i++;
		}
		
		

		
		

		return path;

		// TODO Auto-generated method stub
	}
	
	public Vector<PathNode> createHeader(HuiTreeNodeHash nod, TreeMap<Integer, HuiHeadTbValueHash> subHtb,int level) {
		Vector<PathNode> path = new Vector<PathNode>();
//��ô���ڵ�������ȥ
		HuiTreeNodeHash tem = nod;
		HuiTreeNodeInfo NodeInf = nod.getInfos()[level-1];
		if(NodeInf==null) {
			System.out.println("errrr.......................");
		}
		Vector<Integer> utility = NodeInf.getPathUtility();
//		int count=NodeInf.getCount();
		int len = utility.size();
		int tu = NodeInf.getPathSU().get(len - 1) + NodeInf.getBu();
		if (tem.isRoot())
			return null;
		tem = tem.getParent();
		int i = 2;
//		System.out.println();
//		System.out.println(nod+"    errrr.......................");
		while (!tem.isRoot()) {
			int itemindex = tem.getItemIndex();
			path.add(new PathNode(itemindex, utility.get(len - i)));
			HuiHeadTbValueHash htbv = subHtb.get(itemindex);
			if (htbv != null) {
				htbv.setCount(htbv.getCount() + NodeInf.getBu()+utility.get(len - i)); //���Ч��ֵ
				htbv.setTwu(htbv.getTwu() + tu);
				htbv.getLink().add(tem);
			} else {
				subHtb.put(new Integer(itemindex), new HuiHeadTbValueHash(tu, 0,tem));
			}
			if(tem.getItemIndex()==37) {
				htbv = subHtb.get(itemindex);
				System.out.println(i+" :"+htbv.getLink().size()+" :  "+tem+"/"+nod);
//				for(int k=0;k<tem.getChildren().size();k++)
				{
					System.out.println(tem.getChildren().keySet());
				}
			}

			tem = tem.getParent();
			i++;
		}

		//�ж�nod�ڵ�ĸ��ڵ���û��level��info���У��ۼ���ȥ��û�У������µ�info�ϴ����ڵ㡣
		tem = nod.getParent();
		if(!tem.isRoot()) //����Ǹ��ڵ㣬����Ҫ�����µ�info
		{
			if(tem.getInfos()[level]==null)
			{
				//��Ҫ�ϴ���info��Ϣ��bu;PathSU:��ǰ���Ӧ��ʣ��TU;utility:·������utility
				tem.getInfos()[level] = new HuiTreeNodeInfo(NodeInf.getBu()+utility.get(len - 1), utility, NodeInf.getPathSU(), len-1);
				
			}
			else
			{
				tem.getInfos()[level].setBu(tem.getInfos()[level].getBu()+ NodeInf.getBu()+utility.get(len - 1));
				tem.getInfos()[level].addPathUtility(utility,len-1);
				tem.getInfos()[level].addPathSU(NodeInf.getPathSU(), len-1);
				
			}
		}
		
		return path;
		
		// TODO Auto-generated method stub
	}
	

	public void createSubHeader(Vector<HuiTreeNodeHash> link, TreeMap<Integer, HuiHeadTbValueHash> subHtb,int level) {

		HuiTreeNodeHash nod = link.get(0);
		
//		Vector<PathNode> path = new Vector<PathNode>();
//��ô���ڵ�������ȥ
		HuiTreeNodeHash tem = nod;
		HuiTreeNodeInfo NodeInf = nod.getInfos()[level-1];
		if(NodeInf==null) {
			System.out.println("errrr.......................");
		}
		Vector<Integer> utility = NodeInf.getPathUtility();
//		int count=NodeInf.getCount();
		int len = utility.size();
//		System.out.println(len+"//"+NodeInf.getPathSU().size());
		int tu = NodeInf.getPathSU().get(len - 1) + NodeInf.getBu();
		if (tem.isRoot())
			return;
		tem = tem.getParent();
		int i = 2;
		while (!tem.isRoot()) {
			int itemindex = tem.getItemIndex();
//			path.add(new PathNode(itemindex, utility.get(len - i)));
			HuiHeadTbValueHash htbv = subHtb.get(itemindex);
			if (htbv != null) {
				htbv.setCount(htbv.getCount() + NodeInf.getBu()+utility.get(len - i)); //���Ч��ֵ
				htbv.setTwu(htbv.getTwu() + tu);
				htbv.getLink().add(tem);
			} else {
				subHtb.put(new Integer(itemindex), new HuiHeadTbValueHash(tu, 0,tem));
			}
			tem = tem.getParent();
			i++;
		}

		//�ж�nod�ڵ�ĸ��ڵ���û��level��info���У��ۼ���ȥ��û�У������µ�info�ϴ����ڵ㡣
		tem = nod.getParent();
		if(!tem.isRoot()) //����Ǹ��ڵ㣬����Ҫ�����µ�info
		{
			if(tem.getInfos()[level]==null)
			{
				//��Ҫ�ϴ���info��Ϣ��bu;PathSU:��ǰ���Ӧ��ʣ��TU;utility:·������utility
				tem.getInfos()[level] = new HuiTreeNodeInfo(NodeInf.getBu()+utility.get(len - 1), utility, NodeInf.getPathSU(), len-1);
				
			}
			else
			{
				tem.getInfos()[level].setBu(tem.getInfos()[level].getBu()+ NodeInf.getBu()+utility.get(len - 1));
				tem.getInfos()[level].addPathUtility(utility,len-1);
				tem.getInfos()[level].addPathSU(NodeInf.getPathSU(), len-1);
				
			}
		}
		
//		return path;
		return;
		
		// TODO Auto-generated method stub
	}
	

	// β�ڵ��ϲ�����Su,Sn, ͷ���ϱ���rtwu
	public Vector<PathNode> getPath1(HuiTreeNodeHash nod, TreeMap<Integer, HuiHeadTbValue> subHtb) {
		Vector<PathNode> path = new Vector<PathNode>();

		HuiTreeNodeHash tem = nod;
		HuiTreeNodeInfo NodeInf = nod.getInfo();
		Vector<Integer> utility = NodeInf.getPathUtility();
//		int count=NodeInf.getCount();
		int tu = nod.getInfo().getBu();
		for (int i = 0; i < utility.size(); i++) {
			tu = tu + utility.get(i);
		}
		if (tem.isRoot())
			return null;
		tem = tem.getParent();
		int i = 2;
		int len = utility.size();
		while (!tem.isRoot()) {
			int itemindex = tem.getItemIndex();
//			PathNode pn =new PathNode(itemindex,utility.get(len-i));
//			pn.setNode(tem);
//			pn.setIndex(itemindex);
//			pn.setUtility(utility.get(len-i));
			path.add(new PathNode(itemindex, utility.get(len - i)));
			i++;

//			subTreeSu[itemindex] +=tu;

			HuiHeadTbValue htbv = subHtb.get(itemindex);
			if (htbv != null) {
//				htbv.setCount(htbv.getCount() + count);
				htbv.setTwu(htbv.getTwu() + tu);
			} else {
				subHtb.put(new Integer(itemindex), new HuiHeadTbValue(tu, 0));
			}
			tem = tem.getParent();
		}

		return path;

		// TODO Auto-generated method stub
	}

	public Vector<PathNode> getPathWithoutPathSu(HuiTreeNodeHash nod, TreeMap<Integer, HuiHeadTbValue> subHtb) {
		Vector<PathNode> path = new Vector<PathNode>();

		HuiTreeNodeHash tem = nod;
		HuiTreeNodeInfo NodeInf = nod.getInfo();
		Vector<Integer> utility = NodeInf.getPathUtility();
//		int count = NodeInf.getCount();
//		int tu = NodeInf.getSu() + NodeInf.getBu();
		
		int tu = NodeInf.getBu() ;
		for(int i=0;i<NodeInf.getPathUtility().size();i++)
		{
			tu = tu + NodeInf.getPathUtility().get(i);
		}
//		int tu = NodeInf.getPathSU().get(NodeInf.getPathSU().size()-1)+nod.getInfo().getBu();
		if (tem.isRoot())
			return null;
		tem = tem.getParent();
		int i = 2;
		int len = utility.size();
		while (!tem.isRoot()) {
			int itemindex = tem.getItemIndex();
//			PathNode pn =new PathNode(itemindex,utility.get(len-i));
//			pn.setNode(tem);
//			pn.setIndex(itemindex);
//			pn.setUtility(utility.get(len-i));
			path.add(new PathNode(itemindex, utility.get(len - i)));
			i++;

//			subTreeSu[itemindex] +=tu;

			HuiHeadTbValue htbv = subHtb.get(itemindex);
			if (htbv != null) {
//				htbv.setCount(htbv.getCount() + count);
				htbv.setTwu(htbv.getTwu() + tu);
			} else {
				subHtb.put(new Integer(itemindex), new HuiHeadTbValue(tu, 0));
			}
			tem = tem.getParent();
		}

		return path;

		// TODO Auto-generated method stub
	}



	// ������transaction���ӵ�����,������ȫ����
	public int addtransactionGlobal(Transaction path, int[] NodeRtwu, int[] NodeNu, ArrlistHashNode[] Nodelink) {

		int newcount = 0;
		
		HuiTreeNodeHash tmp = this.root;
		Vector<Integer> utility = new Vector<Integer>();
		int i = 0;
		int size = path.getLen();
//		System.out.println("size0"+size);
		int j = 0;
		int childsize;
//		Vector<HuiTreeNodeHash> cv;
		int bu = 0;
//		int su = path.tempUtilities[path.getLen()-1];
		int count = 1;

		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
		HashMap<Integer, HuiTreeNodeHash> ch = tmp.getChildren();
//		int test1=0;
		HuiTreeNodeHash tmp1;
		for (i = 0; i < size; i++) { // path������root
			if (path.getUtilities()[i] ==0)
				break;

			
			int item = path.getItems()[i];
			
//			if(test1==774 && item==774) System.out.println(" HUiTree errror............................");

			
//start:children ����hash����
			tmp1 = ch.get(item);
			if(tmp1!=null) //�ҵ����ӽ��
			{
				tmp=tmp1;
				ch=tmp.getChildren();
			}
			else
			{
				break; //�����ں��ӽ��
			}
//start:children ����hash����	

			
//start:children ����arrlist����			
//			int chsize = ch.size();
//			for (j = 0; j < chsize; j++) {
//				if (item == ch.get(j).getItemIndex())
//					break;
//			}
//			if (j == chsize)
//				break;
//			else {
//				tmp = ch.get(j);
//				ch = tmp.getChildren();
//			}
//end:children ����arrlist����				
			
//			int ut =path.get(i).getUtility();
			utility.add(path.getUtilities()[i]);
//			su=su+ut;
			NodeNu[item] += path.getUtilities()[i];
			NodeRtwu[item] += path.tempUtilities[i]; //
			
//			if(item==336) System.out.println(" HUiTree errror............................");

//test1 = item;
		}
		for (; i < size; i++) {
			if (path.getUtilities()[i] ==0)
				break;
			int item = path.getItems()[i];
			
//			if(item==336) System.out.println(" HUiTree errror............................");
//			System.out.println(item+"size"+size);
			NodeNu[item] += path.getUtilities()[i];
			NodeRtwu[item] += path.tempUtilities[i]; //
			utility.add(path.getUtilities()[i]);
//			su=su+ut;
			HuiTreeNodeHash initem = new HuiTreeNodeHash();
			initem.setItemIndex(item);
			initem.setParent(tmp);
			tmp = initem;
			if (Nodelink[item] == null)
				Nodelink[item] = new ArrlistHashNode();
			Nodelink[item].getArrList().add(initem);
			newcount++;
			
//			test1 = item;
		}
		if (i == 0)
			return newcount;
//		int su = path.tempUtilities[path.getLen()-1];
		// ����tail info.
		if (tmp.getInfo() != null) {
			tmp.getInfo().setBu(0);
//			tmp.getInfo().setCount(tmp.getInfo().getCount()+count);
//			tmp.getInfo().setSu(tmp.getInfo().getSu()+su);
			tmp.getInfo().addPathUtility(utility);
			tmp.getInfo().addPathSU(path.tempUtilities, size);
//			System.out.println("have one more times!!!!!!!!!!!!!!!");
		} else {
//			tmp.setInfo(new HuiTreeNodeInfo(count,bu,su,utility));
			tmp.setInfo(new HuiTreeNodeInfo(bu, utility, path.tempUtilities, size));
		}
		// TODO Auto-generated method stub

		return newcount;
		// TODO Auto-generated method stub

	}




	// �㷨��������һ������������transaction���ӵ�����,������ȫ����
	public int addtransactionGlobal(Transaction path, int[] NodeRtwu, int[] NodeNu, ArrlistHashNode[] Nodelink,int maxlen) {
// maxlen: ģʽ��󳤶ȵģ�1+x��������ÿ���ڵ�洢�����β�ڵ���Ϣ
		int newcount = 0;
		
		HuiTreeNodeHash tmp = this.root;
		Vector<Integer> utility = new Vector<Integer>();
		int i = 0;
		int size = path.getLen();
//		System.out.println("size0"+size);
		int j = 0;
		int childsize;
//		Vector<HuiTreeNodeHash> cv;
		int bu = 0;
//		int su = path.tempUtilities[path.getLen()-1];
		int count = 1;

		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
		HashMap<Integer, HuiTreeNodeHash> ch = tmp.getChildren();
//		int test1=0;
		HuiTreeNodeHash tmp1;
		for (i = 0; i < size; i++) { // path������root
			if (path.getUtilities()[i] ==0)
				break;

			
			int item = path.getItems()[i];
			
//			if(test1==774 && item==774) System.out.println(" HUiTree errror............................");

			
//start:children ����hash����
			tmp1 = ch.get(item);
			if(tmp1!=null) //�ҵ����ӽ��
			{
				tmp=tmp1;
				ch=tmp.getChildren();
			}
			else
			{
				break; //�����ں��ӽ��
			}
//start:children ����hash����	

			
//start:children ����arrlist����			
//			int chsize = ch.size();
//			for (j = 0; j < chsize; j++) {
//				if (item == ch.get(j).getItemIndex())
//					break;
//			}
//			if (j == chsize)
//				break;
//			else {
//				tmp = ch.get(j);
//				ch = tmp.getChildren();
//			}
//end:children ����arrlist����				
			
//			int ut =path.get(i).getUtility();
			utility.add(path.getUtilities()[i]);
//			su=su+ut;
			NodeNu[item] += path.getUtilities()[i];
			NodeRtwu[item] += path.tempUtilities[i]; //
			
		}
		for (; i < size; i++) {
			if (path.getUtilities()[i] ==0)
				break;
			int item = path.getItems()[i];
			
//			if(item==336) System.out.println(" HUiTree errror............................");
//			System.out.println(item+"size"+size);
			NodeNu[item] += path.getUtilities()[i];
			NodeRtwu[item] += path.tempUtilities[i]; //
			utility.add(path.getUtilities()[i]);
//			su=su+ut;
			HuiTreeNodeHash initem = new HuiTreeNodeHash();
			initem.setItemIndex(item);
			initem.setParent(tmp);
			initem.setInfos(new HuiTreeNodeInfo[maxlen]);
			tmp = initem;
			if (Nodelink[item] == null)
				Nodelink[item] = new ArrlistHashNode();
			Nodelink[item].getArrList().add(initem);
			newcount++;
			
//			test1 = item;
		}
		if (i == 0)
			return newcount;
//		int su = path.tempUtilities[path.getLen()-1];
		// ����tail info.
		if(tmp.getInfos()[0]!=null)
		{
			tmp.getInfos()[0].setBu(0);
			tmp.getInfos()[0].addPathUtility(utility);
			tmp.getInfos()[0].addPathSU(path.tempUtilities, size);
			
		}
		else
		{
			tmp.getInfos()[0] = new HuiTreeNodeInfo(bu, utility, path.tempUtilities, size);
		}
		
//		if (tmp.getInfo() != null) {
//			tmp.getInfo().setBu(0);
////			tmp.getInfo().setCount(tmp.getInfo().getCount()+count);
////			tmp.getInfo().setSu(tmp.getInfo().getSu()+su);
//			tmp.getInfo().addPathUtility(utility);
//			tmp.getInfo().addPathSU(path.tempUtilities, size);
////			System.out.println("have one more times!!!!!!!!!!!!!!!");
//		} else {
////			tmp.setInfo(new HuiTreeNodeInfo(count,bu,su,utility));
//			tmp.setInfo(new HuiTreeNodeInfo(bu, utility, path.tempUtilities, size));
//		}
		// TODO Auto-generated method stub

		return newcount;
		// TODO Auto-generated method stub

	}



	// ������transaction���ӵ�����,������ȫ����..û�г���Լ����
	public int addtransactionGlobalNoLen(Transaction path, int[] NodeRtwu, int[] NodeNu, ArrlistHashNode[] Nodelink) {

		HuiTreeNodeHash tmp = this.root;
		Vector<Integer> utility = new Vector<Integer>();
		int i = 0;
		int size = path.getLen();
		int j = 0;
		int childsize;
//		Vector<HuiTreeNodeHash> cv;
		int bu = 0;
		int rtwu = 0;
		int nu = 0;
		int count = 1;
		int newcount = 0;

		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
		HashMap<Integer, HuiTreeNodeHash> ch = tmp.getChildren();

		for (i = 0; i < size; i++) { // path������root
//			if (path.get(i).getUtility() < 0.0001)
//				break;

			int item = path.getItems()[i];
			int chsize = ch.size();
			for (j = 0; j < chsize; j++) {
				if (item == ch.get(j).getItemIndex())
					break;
			}
			if (j == chsize)
				break;
			else {
				tmp = ch.get(j);
				ch = tmp.getChildren();
			}
			nu = path.getUtilities()[i];
			utility.add(nu);
			rtwu = rtwu + nu;
			NodeNu[item] += nu;
			NodeRtwu[item] += rtwu; //

		}
		for (; i < size; i++) {
//			if (path.get(i).getUtility() < 0.0001)
//				break;
			int item = path.getItems()[i];
			nu = path.getUtilities()[i];
			rtwu = rtwu + nu;
			NodeNu[item] += nu;
			NodeRtwu[item] += rtwu; //
			utility.add(nu);
//			su=su+ut;
			HuiTreeNodeHash initem = new HuiTreeNodeHash();
			initem.setItemIndex(item);
			initem.setParent(tmp);
			tmp = initem;
			if (Nodelink[item] == null)
				Nodelink[item] = new ArrlistHashNode();
			Nodelink[item].getArrList().add(initem);
			newcount++;
		}
		if (i == 0)
			return newcount;
//		int su = path.tempUtilities[path.getLen()-1];
		// ����tail info.
		if (tmp.getInfo() != null) {
			tmp.getInfo().setBu(0);
//			tmp.getInfo().setCount(tmp.getInfo().getCount()+count);
//			tmp.getInfo().setSu(tmp.getInfo().getSu()+su);
			tmp.getInfo().addPathUtility(utility);
//			tmp.getInfo().addPathSU(path.tempUtilities,size);
//			System.out.println("have one more times!!!!!!!!!!!!!!!");
		} else {
//			tmp.setInfo(new HuiTreeNodeInfo(count,bu,su,utility));
			tmp.setInfo(new HuiTreeNodeInfo(bu, utility));
		}
		// TODO Auto-generated method stub

		return newcount;
		// TODO Auto-generated method stub

	}



	// ���ӵ�ʱ����Ҫ
	public void addInstance1(Vector<PathNode> path, TreeBidiMap<Integer, HeaderCountHashNode> subHtb, HuiTreeNodeInfo hni) {
		// HuiTreeNodeInfo tailInfo = new HuiTreeNodeInfo();
		// float su = 0.0f;
		//
		HuiTreeNodeHash tmp = this.root;
		Vector<Integer> utility = new Vector<Integer>();
//		Vector<Integer> pathSU = new Vector<Integer>();
		int i = 0;
		int size = path.size();
		int j = 0;
//		int childsize;
//		Vector<HuiTreeNodeHash> cv;
		int bu = hni.getBu();
		int rtwu = 0;
//		int count = hni.getCount();
		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
		HashMap<Integer, HuiTreeNodeHash> ch = tmp.getChildren();
		int itemindex;
		for (i = 0; i < size; i++) { // path������root
			itemindex = path.get(i).getIndex();
			if (path.get(i).getUtility() ==0)
				break;
			int chsize = ch.size();
			for (j = 0; j < chsize; j++) {
				if (itemindex == ch.get(j).getItemIndex())
					break;
			}
			if (j == chsize)
				break;
			else {
				tmp = ch.get(j);
				ch = tmp.getChildren();
			}
			utility.add(path.get(i).getUtility());
			rtwu = rtwu + path.get(i).getUtility();
			subHtb.get(itemindex).setCount(rtwu + bu+ subHtb.get(itemindex).getCount());
		}
		for (; i < size; i++) {
			if (path.get(i).getUtility() == 0)
				break;
			utility.add(path.get(i).getUtility());
			rtwu = rtwu + path.get(i).getUtility();
			HuiTreeNodeHash initem = new HuiTreeNodeHash();
			itemindex = path.get(i).getIndex();
			initem.setItemIndex(itemindex);
			initem.setParent(tmp);
			tmp = initem;
			if (subHtb.get(itemindex) != null) {
				subHtb.get(itemindex).getLink().add(initem);
				subHtb.get(itemindex).setCount(rtwu + bu+ subHtb.get(itemindex).getCount());
			} // add link
		}
		if (i == 0)
			return;

		// ����tail info.
		if (tmp.getInfo() != null) {
			tmp.getInfo().setBu(tmp.getInfo().getBu() + bu);
//			tmp.getInfo().setCount(tmp.getInfo().getCount()+count);
//			tmp.getInfo().setSu(tmp.getInfo().getSu()+su);
			tmp.getInfo().addPathUtility(utility);
//			System.out.println("have same node, tmp.getInfo()......"+tmp.getInfo().getCount());
		} else {
			tmp.setInfo(new HuiTreeNodeInfo(bu, utility));
//			System.out.println("tmp.getInfo()......"+tmp.getInfo().getCount());
		}
	}

	public void addInstance(Vector<PathNode> path, TreeBidiMap<Integer, HeaderCountHashNode> subHtb, HuiTreeNodeInfo hni,
			Vector<Integer> pathSU) {
		// HuiTreeNodeInfo tailInfo = new HuiTreeNodeInfo();
		// float su = 0.0f;
		//
		HuiTreeNodeHash tmp = this.root;
		Vector<Integer> utility = new Vector<Integer>();
//		Vector<Integer> pathSU = new Vector<Integer>();
		int i = 0;
		int size = path.size();
		int j = 0;
//		int childsize;
//		Vector<HuiTreeNodeHash> cv;
		int bu = hni.getBu();
//		int rtwu = 0;
//		int count = hni.getCount();
		int itemindex;
		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
		HashMap<Integer, HuiTreeNodeHash> ch = tmp.getChildren();
		for (i = 0; i < size; i++) { // path������root
//             int itemindex = path.get(i).getIndex();
			itemindex = path.get(i).getIndex();
			if (path.get(i).getUtility() == 0)
				break;
			int chsize = ch.size();
			for (j = 0; j < chsize; j++) {
				if (itemindex == ch.get(j).getItemIndex())
					break;
			}
			if (j == chsize)
				break;
			else {
				tmp = ch.get(j);
				ch = tmp.getChildren();
			}
			utility.add(path.get(i).getUtility());
//			r=su+path.get(i).getUtility();

			subHtb.get(itemindex).setCount(pathSU.get(i) + bu + subHtb.get(itemindex).getCount()); // rTwuk
//			subHtb.get(itemindex).set
//			System.out.println(itemindex+" add // "+(pathSU.get(i)+bu+subHtb.get(itemindex).getCount()));
		}
		for (; i < size; i++) {
			if (path.get(i).getUtility() == 0)
				break;
			utility.add(path.get(i).getUtility());
//			su=su+path.get(i).getUtility();
			HuiTreeNodeHash initem = new HuiTreeNodeHash();
			itemindex = path.get(i).getIndex();
			initem.setItemIndex(itemindex);
			initem.setParent(tmp);
			tmp = initem;
			if (subHtb.get(itemindex) != null) {
				subHtb.get(itemindex).getLink().add(initem);// add link
				subHtb.get(itemindex).setCount(pathSU.get(i) + bu + subHtb.get(itemindex).getCount()); // rTwuk
//				System.out.println(itemindex+" add// "+(pathSU.get(i)+bu+subHtb.get(itemindex).getCount()));
			}
		}
		if (i == 0)
			return;

		// ����tail info.
		if (tmp.getInfo() != null) {
			tmp.getInfo().setBu(tmp.getInfo().getBu() + bu);
//			tmp.getInfo().setCount(tmp.getInfo().getCount()+count);
//			tmp.getInfo().setSu(tmp.getInfo().getSu()+su);
			tmp.getInfo().addPathUtility(utility);
			tmp.getInfo().addPathSU(pathSU);
//			System.out.println("have same node, tmp.getInfo()......"+tmp.getInfo().getCount());
		} else {
//			tmp.setInfo(new HuiTreeNodeInfo(count,bu,su,utility));
//			System.out.println(pathSU.size()+"//"+size);
			tmp.setInfo(new HuiTreeNodeInfo(bu, utility, pathSU, i)); // i �������񳤶�
//			System.out.println("tmp.getInfo()......"+tmp.getInfo().getCount());
		}
	}

	public void addInstance1(Vector<PathNode> path, TreeBidiMap<Integer, HeaderCountHashNode> subHtb, HuiTreeNodeInfo hni,
			Vector<Integer> pathSU) {
		// HuiTreeNodeInfo tailInfo = new HuiTreeNodeInfo();
		// float su = 0.0f;
		//
		HuiTreeNodeHash tmp = this.root;
		HuiTreeNodeHash tmp1;
		Vector<Integer> utility = new Vector<Integer>();
//		Vector<Integer> pathSU = new Vector<Integer>();
		int i = 0;
		int size = path.size();
		int j = 0;
//		int childsize;
//		Vector<HuiTreeNodeHash> cv;
		int bu = hni.getBu();
//		int rtwu = 0;
//		int count = hni.getCount();
		int itemindex;
		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
		HashMap<Integer, HuiTreeNodeHash> ch = tmp.getChildren();
		HeaderCountHashNode subnode;
		for (i = 0; i < size; i++) { // path������root
//             int itemindex = path.get(i).getIndex();
			itemindex = path.get(i).getIndex();
			if (path.get(i).getUtility() == 0)
				break;
			
//start:children ����hash����
			tmp1 = ch.get(itemindex);
			if(tmp1!=null) //�ҵ����ӽ��
			{
				tmp=tmp1;
				ch=tmp.getChildren();
			}
			else
			{
				break; //�����ں��ӽ��
			}
//start:children ����hash����				
			

			
//start:children ����arrlist����			
//			int chsize = ch.size();
//			for (j = 0; j < chsize; j++) {
//				if (itemindex == ch.get(j).getItemIndex())
//					break;
//			}
//			if (j == chsize)
//				break;
//			else {
//				tmp = ch.get(j);
//				ch = tmp.getChildren();
//			}
//end:children ����arrlist����			


			utility.add(path.get(i).getUtility());
//			r=su+path.get(i).getUtility();
			subnode = subHtb.get(itemindex);
			subnode.setTwu(pathSU.get(i) + bu + subHtb.get(itemindex).getTwu()); // rTwuk
			subnode.setCount(path.get(i).getUtility() + bu + subHtb.get(itemindex).getCount()); // node utility
			
//			System.out.println(itemindex+" add // "+(pathSU.get(i)+bu+subHtb.get(itemindex).getCount()));
		}
		for (; i < size; i++) {
			if (path.get(i).getUtility() == 0)
				break;
			utility.add(path.get(i).getUtility());
//			su=su+path.get(i).getUtility();
			HuiTreeNodeHash initem = new HuiTreeNodeHash();
			itemindex = path.get(i).getIndex();
			initem.setItemIndex(itemindex);
			initem.setParent(tmp);
			tmp = initem;
			subnode = subHtb.get(itemindex);
			if (subnode != null) {
				subnode.getLink().add(initem);// add link
				subnode.setTwu(pathSU.get(i) + bu + subHtb.get(itemindex).getTwu()); // rTwuk
				subnode.setCount(path.get(i).getUtility() + bu + subHtb.get(itemindex).getCount()); // node utility
//				System.out.println(itemindex+" add// "+(pathSU.get(i)+bu+subHtb.get(itemindex).getCount()));
			}
		}
		if (i == 0)
			return;

		// ����tail info.
		if (tmp.getInfo() != null) {
			tmp.getInfo().setBu(tmp.getInfo().getBu() + bu);
//			tmp.getInfo().setCount(tmp.getInfo().getCount()+count);
//			tmp.getInfo().setSu(tmp.getInfo().getSu()+su);
			tmp.getInfo().addPathUtility(utility);
			tmp.getInfo().addPathSU(pathSU);
//			System.out.println("have same node, tmp.getInfo()......"+tmp.getInfo().getCount());
		} else {
//			tmp.setInfo(new HuiTreeNodeInfo(count,bu,su,utility));
//			System.out.println(pathSU.size()+"//"+size);
			tmp.setInfo(new HuiTreeNodeInfo(bu, utility, pathSU, i)); // i �������񳤶�
//			System.out.println("tmp.getInfo()......"+tmp.getInfo().getCount());
		}
	}

	public void addInstance2(Vector<PathNode> path, TreeBidiMap<Integer, HeaderCountHashNode> subHtb, HuiTreeNodeInfo hni,
			Vector<Integer> pathSU) {
		// HuiTreeNodeInfo tailInfo = new HuiTreeNodeInfo();
		// float su = 0.0f;
		//
		HuiTreeNodeHash tmp = this.root;
		Vector<Integer> utility = new Vector<Integer>();
//		Vector<Integer> pathSU = new Vector<Integer>();
		int i = 0;
		int size = pathSU.size();
		int j = 0;
//		int childsize;
//		Vector<HuiTreeNodeHash> cv;
		int bu = hni.getBu();
//		int rtwu = 0;
//		int count = hni.getCount();
		int itemindex;
		// htni.getPathUtility().remove(htni.getPathUtility().size() - 1);
		HashMap<Integer, HuiTreeNodeHash> ch = tmp.getChildren();
		HeaderCountHashNode subnode;
		for (i = 0; i < size; i++) { // path������root
//             int itemindex = path.get(i).getIndex();
			itemindex = path.get(i).getIndex();
			if (path.get(i).getUtility() == 0)
				break;
			int chsize = ch.size();
			for (j = 0; j < chsize; j++) {
				if (itemindex == ch.get(j).getItemIndex())
					break;
			}
			if (j == chsize)
				break;
			else {
				tmp = ch.get(j);
				ch = tmp.getChildren();
			}
			utility.add(path.get(i).getUtility());
//			r=su+path.get(i).getUtility();
			subnode = subHtb.get(itemindex);
			subnode.setTwu(pathSU.get(i) + bu + subHtb.get(itemindex).getTwu()); // rTwuk
			subnode.setCount(path.get(i).getUtility() + bu + subHtb.get(itemindex).getCount()); // node utility
			
//			System.out.println(itemindex+" add // "+(pathSU.get(i)+bu+subHtb.get(itemindex).getCount()));
		}
		for (; i < size; i++) {
			if (path.get(i).getUtility() == 0)
				break;
			utility.add(path.get(i).getUtility());
//			su=su+path.get(i).getUtility();
			HuiTreeNodeHash initem = new HuiTreeNodeHash();
			itemindex = path.get(i).getIndex();
			initem.setItemIndex(itemindex);
			initem.setParent(tmp);
			tmp = initem;
			subnode = subHtb.get(itemindex);
			if (subnode != null) {
				subnode.getLink().add(initem);// add link
				subnode.setTwu(pathSU.get(i) + bu + subHtb.get(itemindex).getTwu()); // rTwuk
				subnode.setCount(path.get(i).getUtility() + bu + subHtb.get(itemindex).getCount()); // node utility
//				System.out.println(itemindex+" add// "+(pathSU.get(i)+bu+subHtb.get(itemindex).getCount()));
			}
		}
		if (i == 0)
			return;

		// ����tail info.
		if (tmp.getInfo() != null) {
			tmp.getInfo().setBu(tmp.getInfo().getBu() + bu);
//			tmp.getInfo().setCount(tmp.getInfo().getCount()+count);
//			tmp.getInfo().setSu(tmp.getInfo().getSu()+su);
			tmp.getInfo().addPathUtility(utility);
			tmp.getInfo().addPathSU(pathSU);
//			System.out.println("have same node, tmp.getInfo()......"+tmp.getInfo().getCount());
		} else {
//			tmp.setInfo(new HuiTreeNodeInfo(count,bu,su,utility));
//			System.out.println(pathSU.size()+"//"+size);
			tmp.setInfo(new HuiTreeNodeInfo(bu, utility, pathSU, i)); // i �������񳤶�
//			System.out.println("tmp.getInfo()......"+tmp.getInfo().getCount());
		}
	}


}
