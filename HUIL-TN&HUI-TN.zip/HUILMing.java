package face;
//-Xms15000m -Xmx15000m
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.*;

import ctl.ulbminer.AlgoULBMiner;
//import ctl.HuiGrowth;
//import ctl.HuiGrowthLen;
import ctl.efim.*;
import ctl.hminer.AlgoHMiner;
//import ctl.efimImp1.AlgoEFIMImp1;
import util.*;
import ctl.HuiLen.*;
import ctl.d2hup.AlgoD2HUP;

public class HUILMing  {
	public static void main(String[] a) {
		
		String datafile = "";
		datafile = "D:\\Documents\\0dataset\\onefile\\foodmart.txt";
//		datafile = "D:\\Documents\\0dataset\\onefile\\mushroom_utility_spmf.txt";
//		datafile = "D:\\Documents\\0dataset\\onefile\\connect.txt";
//		datafile = "D:\\Documents\\0dataset\\onefile\\chainstore.txt";
		
		String outfile = "D:\\Documents\\0dataset\\onefile\\outfile1.txt";
//		String outfile2 = "D:\\Documents\\0dataset\\onefile\\outfile2.txt";

		System.gc();
		float minU;
		long MinUtililty;
		int maxrunTime = 3600;// ����һ��Сʱֹͣ���У��������㷨�Ͽ죬ĳЩ�Ƚ���ʱ�������������
		
		
//		for (int k = 0; k < 1; k = k + 1) {
//System.out.println("k / 5 :"+k);
			for (int i = 0; i <1; i++) {
				System.out.println();
//			long MinUtililty=0;

//			long minU = 35000000 - i*2500000;
				minU = (float) (0.02 - 0.002 * i);
//				minU = (float) (0.0016 - 0.0001*i);
				minU=(200-50*i)*1000;
				MinUtililty = (650 - 50 * i) * 1000;

				float time1 = (float) 0.0, time2 = (float) 0.0, time3 = (float) 0.0, time4 = (float) 0.0,
						time5 = (float) 0.0, time6 = (float) 0.0, time7 = (float) 0.0, time_HUIMK = (float) 0.0, time_HUIMK1 = (float) 0.0;

				int j;				
				int maxLen = 0;
				String str1 = "", str2 = "", str = "",str3="";
				//�ظ����� j				
				for (j = 0; j < 1; j++) 
				{
					str1 = ""; str2 = ""; str = ""; str3="";
//				System.out.print(minU * 100.0+"  ::::i=" + i + "/10-- j=" + j + "/5 ::::");
					long start;

				//Algorithm 1: HUIL-TN   �㷨1������Ӳ�������������󳤶ȣ�Ȼ�������󳤶��ھ�ȫ�����ݵ�HUI
				System.gc();
				start = System.currentTimeMillis();
				try {
					int startP = 0;	int width = 1000;
					for (int k1 = 0; k1 < 2; k1++) {
						startP = (int) (0 + width * k1 * 3);
						HuiGrowthNoLen Hui = new HuiGrowthNoLen(minU, datafile, 0, startP, width);
						
						if (Hui.Mining().equals("")) {
//							System.out.println("false");
							break;
						}
						if (Hui.getMaxHUILen() > maxLen)
							maxLen = Hui.getMaxHUILen();
					}
//					str2 = " /" + (System.currentTimeMillis() - start) / 1000.0 + "/"+ maxLen;
					if (maxLen > 0) {
//					maxLen=10;
						HuiGrowthLen Hui2 = new HuiGrowthLen(minU, datafile, 0, maxLen);
						str1 = Hui2.Mining();
						if (str1.equals(""))  break;
					}
					else
					{
						str1="0/0";
					}
					time1 = (float) (time1 + (System.currentTimeMillis() - start) / 1000.0);
					str3 = "minU/HuiGLen Time/max memory/pattern count/part1 time/max length/";
					str = str + ""+(minU*100.0) +"/" + (time1 / (j + 1.0)) + "/" + str1 +str2;
//					System.out.println(str);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//End: Algorithm 1: HUIL-TN   ����Ӳ�������������󳤶ȣ�Ȼ�������󳤶��ھ�ȫ�����ݵ�HUI


					
				
				//Algorithm 2: HUI-TN  HuiGrowthTwu������TNT�㷨
				System.gc();
				start = System.currentTimeMillis();
				try {
					HuiGrowthTwu HuiGTwu = new HuiGrowthTwu(minU, datafile, 0);
					str1 = HuiGTwu.Mining();
					MinUtililty = HuiGTwu.minuti;
				} catch (IOException e) {
					// TODO Auto-generated catch block chainstore.txt connect.txt
					e.printStackTrace();
				}
				time6 = (float) (time6 + (System.currentTimeMillis() - start) / 1000.0);

				str3 = str3 +"HuiGrowthTwu Time/max memory/pattern count/";
//				str = str + "\n" +(minU*100.0) + "HuiGrowthTwu/" + (time6 / (j + 1.0)) + "/" + str1;
				str = str  +"/" +  (time6 / (j + 1.0)) + "/" + str1;
				//END Algorithm 2: HUI-TN������TNT�㷨

				
				
				
					//Algorithm 3: EFIM
					System.gc();
					start = System.currentTimeMillis();
					AlgoEFIM efim = new AlgoEFIM();
					try {
//					str1 = efim.runAlgorithm(minU, datafile, outfile, false, 0, true, maxrunTime);
						str1 = efim.runAlgorithm(MinUtililty, datafile, outfile+"1.txt", true, 0, true, maxrunTime);
						MinUtililty = efim.minUtil;
					} catch (IOException e) {
						// TODO Auto-generated catch block chainstore.txt connect.txt
						e.printStackTrace();
					}
					time2 = (float) (time2 + (System.currentTimeMillis() - start) / 1000.0);
					str3 = str3 +"efim Time/max memory/pattern count/Candidate count/";
					str = str +"/"+ (time2 / (j + 1.0)) + "/" + str1;
					//END Algorithm 3: EFIM

					
				//Algorithm 4: D2HUP
				System.gc();
				start = System.currentTimeMillis();
				AlgoD2HUP D2HUP = new AlgoD2HUP();
				try {
					str1 = D2HUP.runAlgorithm(datafile, outfile, MinUtililty, maxrunTime);
					// connect 17000000 -i*1000000,chainstore 4500000 -i*500000,kosarak 1900000
					MinUtililty = D2HUP.minUtility;
				} catch (IOException e) {
					// TODO Auto-generated catch block chainstore.txt connect.txt
					e.printStackTrace();
				}
				time4 = (float) (time4 + (System.currentTimeMillis() - start) / 1000.0);
				str = str + "/" + (time4 / (j + 1.0)) + "/" + str1;
				str3 = str3 +"D2HUP Time/max memory/pattern count";
				//END Algorithm 4: D2HUP

				
				
				

				
				//Algorithm 5: HMiner
				System.gc();
					start = System.currentTimeMillis();
					AlgoHMiner HMiner = new AlgoHMiner();
				try {
					str1 = HMiner.runAlgorithm(datafile, outfile, MinUtililty, true, true, maxrunTime);
				} catch (IOException e) {
					// TODO Auto-generated catch block chainstore.txt connect.txt
					e.printStackTrace();
				}
					time4 = (float) (time4 + (System.currentTimeMillis() - start) / 1000.0);
					str = str + "/" + (MinUtililty/1000)+  "/" + (time4 / (j + 1.0)) + "/" + str1;
					str3 = str3 +"/MinUtililty%1000/HMiner Time/max memory/pattern count/";
				//END Algorithm 5: HMiner


				//Algorithm 6: ULBMiner
				System.gc();
				start = System.currentTimeMillis();
				AlgoULBMiner ULBMiner = new AlgoULBMiner();
				try {
					str1 = ULBMiner.runAlgorithm(datafile, outfile, MinUtililty, maxrunTime);
				} catch (IOException e) {
					// TODO Auto-generated catch block chainstore.txt connect.txt
					e.printStackTrace();
				}
				time5 = (float) (time5 + (System.currentTimeMillis() - start) / 1000.0);
				str = str + "/"+ (time5 / (j + 1.0)) + "/" + str1;
				str3 = str3 +"ULBMiner Time/max memory/pattern count";
				//END Algorithm 6: ULBMiner				
				
				System.gc();
					
				}

				System.out.println(str3);
				System.out.println(str);
				
			}
//			System.out.println("--------------");
//		}
	
	}
	
	
}
